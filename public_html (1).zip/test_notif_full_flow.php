<?php
// test_notif_full_flow.php - Full notification flow test (insert + check + mark seen)
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connect.php';
require_once __DIR__ . '/notif_lib.php';

if (session_status() === PHP_SESSION_NONE) session_start();

$testClientId = (int)($_GET['client_id'] ?? 1);
$_SESSION['user_id'] = $testClientId;

$result = [
    'timestamp' => date('Y-m-d H:i:s'),
    'client_id' => $testClientId,
    'steps' => []
];

// ===== خطوة 1: إدراج إشعار اختباري =====
$result['steps']['insert'] = [
    'action' => 'إدراج إشعار جديد',
    'status' => 'جاري...'
];

$testTitle = 'إشعار اختبار من test_notif_full_flow';
$testMsg = 'هذا إشعار اختباري - ' . date('Y-m-d H:i:s');

$success = notifyClient($pdo, $testClientId, $testTitle, $testMsg, 'test_notif_full_flow.php', 'test');

if ($success) {
    $result['steps']['insert']['status'] = '✅ نجح';
    
    // جلب الإشعار الذي تم إدراجه
    $st = $pdo->prepare("SELECT * FROM notifications WHERE message LIKE ? AND client_id = ? ORDER BY id DESC LIMIT 1");
    $st->execute(['%test_notif_full_flow%', $testClientId]);
    $inserted = $st->fetch(PDO::FETCH_ASSOC);
    $result['steps']['insert']['inserted_id'] = $inserted['id'] ?? null;
    $result['steps']['insert']['details'] = $inserted;
} else {
    $result['steps']['insert']['status'] = '❌ فشل';
}

// ===== خطوة 2: محاكاة check_notif.php =====
$result['steps']['check'] = [
    'action' => 'جلب الإشعار من check_notif',
    'status' => 'جاري...'
];

try {
    // محاكاة منطق check_notif.php
    $last_seen = 0;
    $st = $pdo->prepare("SELECT last_seen_id FROM user_notification_state WHERE user_id=? LIMIT 1");
    $st->execute([$testClientId]);
    $last_seen = (int)($st->fetchColumn() ?: 0);
    
    // جلب الإشعار
    $st = $pdo->prepare("
        SELECT id, title, message, image, link
        FROM notifications
        WHERE client_id = ? AND id > ?
        ORDER BY id ASC
        LIMIT 1
    ");
    $st->execute([$testClientId, $last_seen]);
    $notif = $st->fetch(PDO::FETCH_ASSOC);
    
    if ($notif) {
        $result['steps']['check']['status'] = '✅ نجح - وجد إشعار';
        $result['steps']['check']['notification'] = $notif;
        $result['steps']['check']['last_seen_before'] = $last_seen;
    } else {
        $result['steps']['check']['status'] = '❌ فشل - لم يجد إشعار';
        $result['steps']['check']['last_seen_was'] = $last_seen;
    }
} catch (Exception $e) {
    $result['steps']['check']['status'] = '❌ خطأ في الاستعلام: ' . $e->getMessage();
}

// ===== خطوة 3: تحديث حالة القراءة (محاكاة mark_notif_seen) =====
if (isset($notif['id'])) {
    $result['steps']['mark_seen'] = [
        'action' => 'تحديث حالة القراءة',
        'status' => 'جاري...',
        'notif_id' => $notif['id']
    ];
    
    try {
        $st = $pdo->prepare("
            INSERT INTO user_notification_state (user_id, last_seen_id)
            VALUES (?, ?)
            ON DUPLICATE KEY UPDATE last_seen_id = GREATEST(last_seen_id, VALUES(last_seen_id))
        ");
        $st->execute([$testClientId, $notif['id']]);
        $result['steps']['mark_seen']['status'] = '✅ نجح';
        
        // تحقق من التحديث
        $st = $pdo->prepare("SELECT last_seen_id FROM user_notification_state WHERE user_id=?");
        $st->execute([$testClientId]);
        $lastSeen = $st->fetchColumn();
        $result['steps']['mark_seen']['last_seen_after'] = (int)$lastSeen;
    } catch (Exception $e) {
        $result['steps']['mark_seen']['status'] = '❌ خطأ: ' . $e->getMessage();
    }
}

// ===== خطوة 4: محاولة الجلب مرة أخرى (يجب أن يكون فارغ) =====
$result['steps']['check_again'] = [
    'action' => 'جلب الإشعار مرة أخرى (يجب أن يكون فارغ)',
    'status' => 'جاري...'
];

try {
    $last_seen_now = 0;
    $st = $pdo->prepare("SELECT last_seen_id FROM user_notification_state WHERE user_id=? LIMIT 1");
    $st->execute([$testClientId]);
    $last_seen_now = (int)($st->fetchColumn() ?: 0);
    
    $st = $pdo->prepare("
        SELECT id, title, message
        FROM notifications
        WHERE client_id = ? AND id > ?
        ORDER BY id ASC
        LIMIT 1
    ");
    $st->execute([$testClientId, $last_seen_now]);
    $notif_again = $st->fetch(PDO::FETCH_ASSOC);
    
    if (!$notif_again) {
        $result['steps']['check_again']['status'] = '✅ صحيح - لا توجد إشعارات جديدة';
        $result['steps']['check_again']['last_seen_id'] = $last_seen_now;
    } else {
        $result['steps']['check_again']['status'] = '⚠️ وجد إشعار جديد!';
        $result['steps']['check_again']['notification'] = $notif_again;
    }
} catch (Exception $e) {
    $result['steps']['check_again']['status'] = '❌ خطأ: ' . $e->getMessage();
}

// ===== ملخص =====
$result['summary'] = [
    'all_steps_success' => (
        strpos($result['steps']['insert']['status'], '✅') !== false &&
        strpos($result['steps']['check']['status'], '✅') !== false &&
        strpos($result['steps']['check_again']['status'], '✅') !== false
    ) ? '✅ YES - Flow works perfectly!' : '❌ Some steps failed'
];

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
