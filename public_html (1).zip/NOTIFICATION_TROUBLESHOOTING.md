# دليل تصحيح مشاكل الإشعارات

## الملفات الجديدة للتشخيص والاختبار

### 1. **diagnose_notif.php** - تشخيص شامل
```
http://yoursite.com/diagnose_notif.php
```
✅ يفحص:
- وجود جدول notifications
- وجود بيانات
- أعمدة الجدول
- محاكاة منطق check_notif.php
- اختبار إدراج إشعار

### 2. **test_notif_full_flow.php** - اختبار الدورة الكاملة
```
http://yoursite.com/test_notif_full_flow.php?client_id=1
```
✅ يختبر:
- إدراج إشعار
- جلب الإشعار
- تحديث حالة القراءة
- التحقق من عدم وجود نسخ مكررة

### 3. **view_notif_logs.php** - عرض السجلات
```
http://yoursite.com/view_notif_logs.php
```
✅ يعرض:
- سجل العمليات (notif_lib.log)
- الأخطاء والنجاحات
- زر لمسح السجلات

## خطوات الحل

### الخطوة 1️⃣: فحص شامل
```bash
زُر: http://yoursite.com/diagnose_notif.php
```
**اكتب النتائج هنا لمعرفة المشاكل**

### الخطوة 2️⃣: اختبر الدورة الكاملة
```bash
زُر: http://yoursite.com/test_notif_full_flow.php?client_id=1
```
تأكد من أن جميع الخطوات تظهر ✅

### الخطوة 3️⃣: تفقد السجلات
```bash
زُر: http://yoursite.com/view_notif_logs.php
```
ابحث عن رسائل ERROR وأخبرني بها

## التحسينات المطبقة الآن

### ✅ في `notif_lib.php`:
- إضافة تسجيل السجلات (`notif_log()`)
- تحسين معالجة الأخطاء
- رسائل وضوح في السجلات

### ✅ في `check_notif.php`:
- تحسين المنطق البحثي عن `client_id`
- معالجة أفضل للحالات الخاصة

## الملفات المحدثة

1. **notif_lib.php** - مع تسجيل السجلات
2. **check_notif.php** - منطق بحث محسّن
3. **handle_driver_action.php** - يستخدم notifyClient
4. **preparer_dashboard.php** - يستخدم notifyRoleFallback
5. **chef_receive_order.php** - يستخدم notifyClient

## الملفات الجديدة المضافة

1. **diagnose_notif.php** - تشخيص شامل
2. **test_notif_insert.php** - اختبار الإدراج
3. **test_notif_check.php** - اختبار الجلب
4. **test_notif_full_flow.php** - دورة كاملة
5. **check_db_keys.php** - فحص المفاتيح
6. **fix_db_keys.php** - إصلاح المفاتيح
7. **view_notif_logs.php** - عرض السجلات
8. **clear_notif_logs.php** - مسح السجلات

## الخطأ الشائع وحله

### المشكلة: الإشعارات تُدرج لكن لا تظهر
**السبب**: عدم توافق أعمدة الجدول

**الحل**: تأكد من:
1. جدول `notifications` يحتوي على `client_id`
2. الإشعارات تُدرج مع `client_id` صحيح
3. `check_notif.php` يبحث بـ `client_id = user_id`

### المشكلة: "last_seen_id" أعلى من آخر ID
**السبب**: حذف إشعارات قديمة

**الحل**: 
1. فحص تم - check_notif.php ينعيد آخر last_seen_id إلى 0 تلقائياً
