<?php
/**
 * handle_delete_client.php - معالج حذف العميل (آمن مع CSRF)
 */

require_once 'auth_admin.php';
require_once 'db_connect.php';
require_once 'csrf.php';

function tableExists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$table]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

function columnExists(PDO $pdo, string $table, string $column): bool {
    try {
        $st = $pdo->prepare("SHOW COLUMNS FROM `$table` LIKE ?");
        $st->execute([$column]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

// التحقق من أن الطلب هو POST
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header("Location: view_clients.php");
    exit;
}

// التحقق من CSRF Token
if (!verifyCSRFToken()) {
    header("Location: view_clients.php?error=csrf");
    exit;
}

// جلب ID العميل
$id = isset($_POST['delete_id']) ? (int)$_POST['delete_id'] : 0;

if ($id <= 0) {
    header("Location: view_clients.php?error=invalid");
    exit;
}

try {
    // التحقق من أن المستخدم عميل قبل الحذف
    $stmt = $pdo->prepare("SELECT id FROM users WHERE id = ? AND role = 'client' LIMIT 1");
    $stmt->execute([$id]);
    
    if (!$stmt->fetch()) {
        header("Location: view_clients.php?error=notfound");
        exit;
    }

    $pdo->beginTransaction();

    $deleteSpecs = [
        ['table' => 'daily_selections', 'columns' => ['client_id', 'user_id']],
        ['table' => 'delivery_log', 'columns' => ['client_id', 'user_id']],
        ['table' => 'notifications', 'columns' => ['client_id', 'user_id']],
        ['table' => 'subscription_pauses', 'columns' => ['client_id', 'user_id']],
        ['table' => 'plan_days', 'columns' => ['client_id', 'user_id']],
        ['table' => 'client_pauses', 'columns' => ['client_id', 'user_id']],
        ['table' => 'client_option_category_limits', 'columns' => ['user_id', 'client_id']],
        ['table' => 'client_option_category_visibility', 'columns' => ['user_id', 'client_id']],
        ['table' => 'client_category_limits', 'columns' => ['user_id', 'client_id']],
        ['table' => 'client_meal_category_limits', 'columns' => ['user_id', 'client_id']],
        ['table' => 'user_notification_state', 'columns' => ['user_id', 'client_id']],
        ['table' => 'client_details', 'columns' => ['user_id', 'client_id']],
    ];

    foreach ($deleteSpecs as $spec) {
        $table = $spec['table'];
        if (!tableExists($pdo, $table)) continue;
        $col = '';
        foreach ($spec['columns'] as $c) {
            if (columnExists($pdo, $table, $c)) { $col = $c; break; }
        }
        if ($col === '') continue;
        $sql = "DELETE FROM `$table` WHERE `$col` = ?";
        $pdo->prepare($sql)->execute([$id]);
    }

    $stmt = $pdo->prepare("DELETE FROM users WHERE id = ? AND role = 'client' LIMIT 1");
    $stmt->execute([$id]);

    $pdo->commit();
    
    header("Location: view_clients.php?success=deleted");
    exit;
    
} catch (PDOException $e) {
    if ($pdo->inTransaction()) $pdo->rollBack();
    error_log("Delete client error: " . $e->getMessage());
    header("Location: view_clients.php?error=server");
    exit;
}
