<?php
header('Content-Type: text/html; charset=utf-8');
require_once 'auth_admin.php'; 
require_once 'db_connect.php'; 

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

function h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function redirect_with_toast(string $type, string $title, string $text = ''): void {
    $q = http_build_query([
        'toast_type' => $type,
        'toast_title' => $title,
        'toast_text' => $text,
    ]);
    header("Location: manage_categories.php?$q");
    exit;
}

function table_exists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$table]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

function ensure_upload_dir(string $dir): void {
    if (!is_dir($dir)) {
        @mkdir($dir, 0755, true);
        @chmod($dir, 0755);
    }
}

function save_uploaded_image(string $field, string $prefix): string {
    if (!isset($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) !== UPLOAD_ERR_OK) return '';
    $tmp = $_FILES[$field]['tmp_name'] ?? '';
    $name = $_FILES[$field]['name'] ?? '';
    $size = (int)($_FILES[$field]['size'] ?? 0);
    if ($tmp === '' || $name === '' || $size <= 0 || $size > 5 * 1024 * 1024) return '';
    if (@getimagesize($tmp) === false) return '';
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg','jpeg','png','webp','gif'];
    if (!in_array($ext, $allowed, true)) return '';
    $upload_dir = 'uploads/';
    ensure_upload_dir($upload_dir);
    $file = $prefix . '_' . time() . '.' . $ext;
    $path = $upload_dir . $file;
    if (!move_uploaded_file($tmp, $path)) return '';
    return $file;
}

function safe_delete_category(PDO $pdo, int $id): void {
    $pdo->beginTransaction();

    if (table_exists($pdo, 'order_items') && table_exists($pdo, 'products')) {
        $st = $pdo->prepare("
            SELECT COUNT(*) 
            FROM order_items oi
            INNER JOIN products p ON p.id = oi.product_id
            WHERE p.category_id = ?
        ");
        $st->execute([$id]);
        $hasOrders = (int)$st->fetchColumn();
        if ($hasOrders > 0) {
            $pdo->rollBack();
            throw new Exception('CATEGORY_HAS_ORDERS');
        }
    }

    $toDelete = [
        ['client_category_limits', 'category_id'],
        ['client_category_usage', 'category_id'],
        ['client_meal_category_limits', 'category_id'],
        ['daily_selections', 'category_id'],
        ['package_category_limits', 'category_id'],
        ['package_allowed_categories', 'category_id'],
        ['product_categories', 'category_id'],
        ['products', 'category_id'],
    ];

    foreach ($toDelete as [$table, $col]) {
        if (!table_exists($pdo, $table)) continue;
        $pdo->prepare("DELETE FROM `$table` WHERE `$col`=?")->execute([$id]);
    }

    $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
    $pdo->commit();
}

// إضافة تصنيف
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
        redirect_with_toast('bad', 'خطأ أمني', 'انتهت صلاحية الجلسة، حدّث الصفحة وحاول مجددًا.');
    }

    $action = $_POST['action'] ?? '';

    if ($action === 'add') {
        $name = trim((string)($_POST['name'] ?? ''));
        if ($name === '') redirect_with_toast('bad', 'اسم التصنيف مطلوب');
        try {
            $pdo->beginTransaction();
            $pdo->prepare("INSERT INTO categories (name) VALUES (?)")->execute([$name]);
            $newId = (int)$pdo->lastInsertId();
            $img = save_uploaded_image('image', 'category_' . $newId);
            if ($img !== '') {
                $pdo->prepare("UPDATE categories SET image_url=? WHERE id=?")->execute([$img, $newId]);
            }
            $pdo->commit();
            redirect_with_toast('ok', 'تمت الإضافة', 'تم إنشاء التصنيف بنجاح.');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            redirect_with_toast('bad', 'فشل الإضافة', 'حدث خطأ أثناء إنشاء التصنيف.');
        }
    }

    if ($action === 'update') {
        $id = (int)($_POST['id'] ?? 0);
        $name = trim((string)($_POST['name'] ?? ''));
        if ($id <= 0) redirect_with_toast('bad', 'تصنيف غير صالح');
        if ($name === '') redirect_with_toast('bad', 'اسم التصنيف مطلوب');
        try {
            $pdo->beginTransaction();
            $old = $pdo->prepare("SELECT image_url FROM categories WHERE id=?");
            $old->execute([$id]);
            $oldImg = (string)($old->fetchColumn() ?: '');

            $pdo->prepare("UPDATE categories SET name=? WHERE id=?")->execute([$name, $id]);
            $img = save_uploaded_image('image', 'category_' . $id);
            if ($img !== '') {
                $pdo->prepare("UPDATE categories SET image_url=? WHERE id=?")->execute([$img, $id]);
                if ($oldImg !== '' && file_exists('uploads/' . $oldImg)) @unlink('uploads/' . $oldImg);
            }
            $pdo->commit();
            redirect_with_toast('ok', 'تم التعديل', 'تم تحديث بيانات التصنيف.');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            redirect_with_toast('bad', 'فشل التعديل', 'حدث خطأ أثناء تحديث التصنيف.');
        }
    }

    if ($action === 'delete') {
        $id = (int)($_POST['id'] ?? 0);
        if ($id <= 0) redirect_with_toast('bad', 'تصنيف غير صالح');
        try {
            safe_delete_category($pdo, $id);
            redirect_with_toast('ok', 'تم الحذف', 'تم حذف التصنيف وكل ما يتعلق به.');
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            if ($e->getMessage() === 'CATEGORY_HAS_ORDERS') {
                redirect_with_toast('bad', 'تعذر الحذف', 'لا يمكن حذف هذا التصنيف لأن بعض منتجاته موجودة في طلبات سابقة. الحل: انقل المنتجات لتصنيف آخر أو اترك التصنيف للأرشفة.');
            }
            redirect_with_toast('bad', 'تعذر الحذف', 'التصنيف مرتبط ببيانات أخرى. جرّب نقل المنتجات أولاً.');
        }
    }
}

$toast_type = $_GET['toast_type'] ?? '';
$toast_title = $_GET['toast_title'] ?? '';
$toast_text = $_GET['toast_text'] ?? '';

$cats = [];
try {
    $cats = $pdo->query("
        SELECT c.*,
               COUNT(p.id) AS products_count
        FROM categories c
        LEFT JOIN products p ON p.category_id = c.id
        GROUP BY c.id
        ORDER BY c.id DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $cats = $pdo->query("SELECT * FROM categories ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($cats as &$c) { $c['products_count'] = 0; }
    unset($c);
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة التصنيفات</title>
    <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
    <link rel="stylesheet" href="admin_colors.php?v=20260113">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
    <style>
        .catsHead{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin-bottom:14px}
        .catsHead .right{display:flex;flex-direction:column;gap:4px}
        .catsHead .right b{font-size:1.1rem}
        .catsHead .right small{color:var(--admin-text-muted);font-weight:800}
        .searchRow{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
        .searchRow .form-control{max-width:420px}
        .catThumb{width:44px;height:44px;border-radius:14px;object-fit:cover;border:1px solid var(--admin-border);box-shadow:var(--admin-shadow-sm)}
        .chip{display:inline-flex;align-items:center;gap:8px;padding:8px 10px;border-radius:999px;border:1px solid var(--admin-border);background:rgba(255,255,255,0.75);font-weight:900;color:var(--admin-text-secondary)}
        .modal-backdrop{position:fixed;inset:0;background:rgba(2,6,23,.55);display:none;align-items:center;justify-content:center;z-index:2000}
        .modal-backdrop.show{display:flex}
        .modal{width:min(640px,92vw);background:rgba(255,255,255,.96);backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);border-radius:var(--admin-radius-xl);border:1px solid var(--admin-border);box-shadow:var(--admin-shadow-hover);padding:18px;direction:rtl;text-align:right}
        .modalHead{display:flex;justify-content:space-between;align-items:center;gap:10px;margin-bottom:14px}
        .modalTitle{font-weight:1000;display:flex;align-items:center;gap:10px}
        .modalTitle i{width:38px;height:38px;border-radius:14px;display:inline-flex;align-items:center;justify-content:center;background:rgba(217,119,6,.12);color:var(--restaurant-primary);border:1px solid rgba(217,119,6,.18)}
        .modalClose{border:1px solid var(--admin-border);background:rgba(255,255,255,0.75);border-radius:14px;width:42px;height:42px;cursor:pointer;display:inline-flex;align-items:center;justify-content:center}
        .modalClose:hover{background:var(--admin-bg)}
        .modalActions{display:flex;gap:10px;justify-content:flex-end;flex-wrap:wrap;margin-top:14px}
        .modal .form-group{margin-bottom:12px}
        .modal .toastText{margin-top:6px}
    </style>
</head>
<body>
    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <header class="top-bar">
            <div class="user-info">إدارة التصنيفات</div>
            <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> خروج</a>
        </header>

        <main class="content-wrapper">
            <?php if ($toast_type && $toast_title): ?>
                <div class="toastStack" id="toastStack">
                    <div class="toast <?php echo $toast_type === 'ok' ? 'toastOk' : 'toastBad'; ?>">
                        <div class="toastIcon">
                            <i class="fas <?php echo $toast_type === 'ok' ? 'fa-check' : 'fa-triangle-exclamation'; ?>"></i>
                        </div>
                        <div class="toastBody">
                            <div class="toastTitle"><?php echo h($toast_title); ?></div>
                            <?php if ($toast_text): ?>
                                <div class="toastText"><?php echo h($toast_text); ?></div>
                            <?php endif; ?>
                        </div>
                        <button class="toastClose" type="button" onclick="this.closest('.toast').remove()"><i class="fas fa-xmark"></i></button>
                    </div>
                </div>
            <?php endif; ?>

            <div class="form-card">
                <div class="catsHead">
                    <div class="right">
                        <b><i class="fas fa-tags"></i> التصنيفات</b>
                        <small>إضافة/تعديل/حذف مع صورة وعدد المنتجات</small>
                    </div>
                    <div class="searchRow">
                        <input id="catSearch" type="text" class="form-control" placeholder="بحث سريع عن تصنيف...">
                        <span class="chip"><i class="fas fa-layer-group"></i> <?php echo count($cats); ?> تصنيف</span>
                    </div>
                </div>

                <form method="POST" enctype="multipart/form-data" style="display:grid; grid-template-columns: 1fr 1fr; gap:12px; align-items:end;">
                    <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>">
                    <input type="hidden" name="action" value="add">
                    <div>
                        <label>اسم التصنيف</label>
                        <input type="text" name="name" class="form-control" placeholder="مثال: دجاج، حلويات..." required>
                    </div>
                    <div>
                        <label>صورة (اختياري)</label>
                        <input type="file" name="image" class="form-control" accept="image/*">
                    </div>
                    <div style="grid-column: span 2;">
                        <button type="submit" class="btn btnPrimary" style="width:100%; justify-content:center;">
                            <i class="fas fa-plus"></i> إضافة التصنيف
                        </button>
                    </div>
                </form>
            </div>

            <div class="form-card" style="margin-top:16px;">
                <div class="section-title"><i class="fas fa-list"></i> قائمة التصنيفات</div>
                <div class="tableWrap">
                    <table id="catsTable">
                        <thead>
                            <tr>
                                <th>صورة</th>
                                <th>التصنيف</th>
                                <th>عدد المنتجات</th>
                                <th>تاريخ الإضافة</th>
                                <th>إجراءات</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach($cats as $cat): ?>
                            <tr data-name="<?php echo h(mb_strtolower((string)$cat['name'])); ?>">
                                <td>
                                    <?php if (!empty($cat['image_url'])): ?>
                                        <img class="catThumb" src="uploads/<?php echo h($cat['image_url']); ?>" alt="">
                                    <?php else: ?>
                                        <div class="catThumb" style="display:flex;align-items:center;justify-content:center;background:rgba(28,25,23,0.06);">
                                            <i class="fas fa-image" style="color:var(--admin-text-muted)"></i>
                                        </div>
                                    <?php endif; ?>
                                </td>
                                <td><b><?php echo h($cat['name']); ?></b></td>
                                <td><?php echo (int)($cat['products_count'] ?? 0); ?></td>
                                <td><?php echo h($cat['created_at'] ?? ''); ?></td>
                                <td>
                                    <button type="button"
                                        class="action-btn btn-edit"
                                        data-id="<?php echo (int)$cat['id']; ?>"
                                        data-name="<?php echo h($cat['name']); ?>"
                                        data-image="<?php echo h($cat['image_url'] ?? ''); ?>"
                                        onclick="openEdit(this)">
                                        <i class="fas fa-pen"></i> تعديل
                                    </button>
                                    <button type="button"
                                        class="action-btn btn-delete"
                                        data-id="<?php echo (int)$cat['id']; ?>"
                                        data-name="<?php echo h($cat['name']); ?>"
                                        data-products="<?php echo (int)($cat['products_count'] ?? 0); ?>"
                                        onclick="openDelete(this)">
                                        <i class="fas fa-trash"></i> حذف
                                    </button>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </main>
    </div>

    <div class="modal-backdrop" id="editModal">
        <div class="modal">
            <div class="modalHead">
                <div class="modalTitle"><i class="fas fa-pen"></i> تعديل التصنيف</div>
                <button class="modalClose" type="button" onclick="closeModal('editModal')"><i class="fas fa-xmark"></i></button>
            </div>
            <form method="POST" enctype="multipart/form-data">
                <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="update">
                <input type="hidden" name="id" id="editId" value="">
                <div class="form-group">
                    <label>اسم التصنيف</label>
                    <input type="text" name="name" id="editName" class="form-control" required>
                </div>
                <div class="form-group">
                    <label>صورة جديدة (اختياري)</label>
                    <input type="file" name="image" class="form-control" accept="image/*">
                    <div id="editPreviewWrap" style="margin-top:10px; display:none;">
                        <img id="editPreview" class="catThumb" style="width:64px;height:64px;border-radius:18px;" src="" alt="">
                    </div>
                </div>
                <div class="modalActions">
                    <button type="submit" class="btn btnPrimary"><i class="fas fa-check"></i> حفظ</button>
                    <button type="button" class="btn btnGhost" onclick="closeModal('editModal')">إلغاء</button>
                </div>
            </form>
        </div>
    </div>

    <div class="modal-backdrop" id="deleteModal">
        <div class="modal">
            <div class="modalHead">
                <div class="modalTitle"><i class="fas fa-trash"></i> حذف تصنيف</div>
                <button class="modalClose" type="button" onclick="closeModal('deleteModal')"><i class="fas fa-xmark"></i></button>
            </div>
            <div class="toastText" id="deleteText"></div>
            <form method="POST" style="margin-top:12px;">
                <input type="hidden" name="csrf_token" value="<?php echo h($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="action" value="delete">
                <input type="hidden" name="id" id="deleteId" value="">
                <div class="modalActions">
                    <button type="submit" class="btn btnDanger"><i class="fas fa-trash"></i> تأكيد الحذف</button>
                    <button type="button" class="btn btnGhost" onclick="closeModal('deleteModal')">إلغاء</button>
                </div>
            </form>
        </div>
    </div>

    <script>
        function openModal(id){ document.getElementById(id).classList.add('show'); }
        function closeModal(id){ document.getElementById(id).classList.remove('show'); }

        function openEdit(btn){
            const id = btn.getAttribute('data-id');
            const name = btn.getAttribute('data-name') || '';
            const img = btn.getAttribute('data-image') || '';
            document.getElementById('editId').value = id;
            document.getElementById('editName').value = name;
            const wrap = document.getElementById('editPreviewWrap');
            const prev = document.getElementById('editPreview');
            if (img) {
                prev.src = 'uploads/' + img;
                wrap.style.display = 'block';
            } else {
                prev.src = '';
                wrap.style.display = 'none';
            }
            openModal('editModal');
        }

        function openDelete(btn){
            const id = btn.getAttribute('data-id');
            const name = btn.getAttribute('data-name') || '';
            const products = parseInt(btn.getAttribute('data-products') || '0', 10);
            document.getElementById('deleteId').value = id;
            document.getElementById('deleteText').textContent =
                `سيتم حذف التصنيف "${name}"` + (products > 0 ? ` ومعه ${products} منتج مرتبط.` : '.') ;
            openModal('deleteModal');
        }

        const search = document.getElementById('catSearch');
        if (search) {
            search.addEventListener('input', function(){
                const q = (this.value || '').trim().toLowerCase();
                document.querySelectorAll('#catsTable tbody tr').forEach(tr => {
                    const name = tr.getAttribute('data-name') || '';
                    tr.style.display = name.includes(q) ? '' : 'none';
                });
            });
        }

        const toast = document.getElementById('toastStack');
        if (toast) {
            setTimeout(() => { toast.remove(); }, 4500);
        }
    </script>
</body>
</html>
