<?php
// notif_fcm.php - FCM push helpers for notifications.

if (!defined('FCM_SERVICE_ACCOUNT_PATH')) {
    define('FCM_SERVICE_ACCOUNT_PATH', __DIR__ . '/ca/service-account.json');
}
if (!defined('FCM_PROJECT_ID')) {
    define('FCM_PROJECT_ID', '');
}
if (!defined('FCM_BASE_URL')) {
    define('FCM_BASE_URL', 'https://carby.najd-almotatorh.com/');
}

function fcm_log(string $msg): void {
    $file = __DIR__ . '/notif_fcm.log';
    error_log('[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", 3, $file);
}

function fcm_base64url(string $data): string {
    return rtrim(strtr(base64_encode($data), '+/', '-_'), '=');
}

function fcm_load_service_account(): ?array {
    $path = FCM_SERVICE_ACCOUNT_PATH;
    if (!is_file($path)) {
        fcm_log('Service account file not found: ' . $path);
        return null;
    }
    $raw = file_get_contents($path);
    if ($raw === false) {
        fcm_log('Failed to read service account file');
        return null;
    }
    $data = json_decode($raw, true);
    if (!is_array($data)) {
        fcm_log('Invalid service account JSON');
        return null;
    }
    return $data;
}

function fcm_get_access_token(): ?string {
    static $cachedToken = null;
    static $expiresAt = 0;

    if ($cachedToken && time() < ($expiresAt - 60)) {
        return $cachedToken;
    }

    $sa = fcm_load_service_account();
    if (!$sa) return null;

    $now = time();
    $claims = [
        'iss' => $sa['client_email'] ?? '',
        'scope' => 'https://www.googleapis.com/auth/firebase.messaging',
        'aud' => 'https://oauth2.googleapis.com/token',
        'iat' => $now,
        'exp' => $now + 3600,
    ];

    $header = fcm_base64url(json_encode(['alg' => 'RS256', 'typ' => 'JWT']));
    $payload = fcm_base64url(json_encode($claims));
    $toSign = $header . '.' . $payload;

    $signature = '';
    if (!openssl_sign($toSign, $signature, $sa['private_key'] ?? '', 'SHA256')) {
        fcm_log('Failed to sign JWT');
        return null;
    }
    $jwt = $toSign . '.' . fcm_base64url($signature);

    $body = http_build_query([
        'grant_type' => 'urn:ietf:params:oauth:grant-type:jwt-bearer',
        'assertion' => $jwt,
    ]);

    $code = 0;
    $resp = fcm_http_post_json('https://oauth2.googleapis.com/token', [
        'Content-Type: application/x-www-form-urlencoded',
    ], $body, $code);

    if ($resp === null || $code !== 200) {
        fcm_log('Access token request failed: HTTP ' . (int)$code);
        return null;
    }

    $json = json_decode($resp, true);
    if (!is_array($json) || empty($json['access_token'])) {
        fcm_log('Access token response invalid');
        return null;
    }

    $cachedToken = $json['access_token'];
    $expiresAt = $now + (int)($json['expires_in'] ?? 3600);
    return $cachedToken;
}

function fcm_http_post_json(string $url, array $headers, string $payload, ?int &$httpCode = null): ?string {
    if (function_exists('curl_init')) {
        $ch = curl_init($url);
        curl_setopt_array($ch, [
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_POST => true,
            CURLOPT_HTTPHEADER => $headers,
            CURLOPT_POSTFIELDS => $payload,
            CURLOPT_TIMEOUT => 15,
        ]);
        $resp = curl_exec($ch);
        $httpCode = (int)curl_getinfo($ch, CURLINFO_HTTP_CODE);
        if ($resp === false) {
            fcm_log('cURL error: ' . curl_error($ch));
        }
        curl_close($ch);
        return $resp === false ? null : $resp;
    }

    $context = stream_context_create([
        'http' => [
            'method' => 'POST',
            'header' => implode("\r\n", $headers),
            'content' => $payload,
            'timeout' => 15,
        ],
    ]);
    $resp = @file_get_contents($url, false, $context);
    $httpCode = 0;
    if (isset($http_response_header[0]) && preg_match('/\s(\d{3})\s/', $http_response_header[0], $m)) {
        $httpCode = (int)$m[1];
    }
    return $resp === false ? null : $resp;
}

function fcm_extract_error_code(array $resp): string {
    if (isset($resp['error']['details']) && is_array($resp['error']['details'])) {
        foreach ($resp['error']['details'] as $detail) {
            if (isset($detail['errorCode'])) return (string)$detail['errorCode'];
        }
    }
    if (isset($resp['error']['status'])) return (string)$resp['error']['status'];
    return '';
}

function fcm_send_to_token(string $token, string $title, string $body, array $data, ?string $image, ?string &$errCode = null): bool {
    $accessToken = fcm_get_access_token();
    if (!$accessToken) return false;

    $sa = fcm_load_service_account();
    if (!$sa) return false;
    $projectId = FCM_PROJECT_ID !== '' ? FCM_PROJECT_ID : (string)($sa['project_id'] ?? '');
    if ($projectId === '') {
        fcm_log('Missing project_id');
        return false;
    }

    $payload = [
        'message' => [
            'token' => $token,
            'notification' => [
                'title' => $title,
                'body' => $body,
            ],
            'data' => $data,
            'android' => [
                'priority' => 'high',
                'notification' => [
                    'channel_id' => 'carby_default',
                    'sound' => 'default',
                ],
            ],
            'apns' => [
                'payload' => [
                    'aps' => [
                        'sound' => 'default',
                    ],
                ],
            ],
        ],
    ];

    if ($image) {
        $payload['message']['notification']['image'] = $image;
    }

    $resp = fcm_http_post_json(
        'https://fcm.googleapis.com/v1/projects/' . $projectId . '/messages:send',
        [
            'Content-Type: application/json',
            'Authorization: Bearer ' . $accessToken,
        ],
        json_encode($payload, JSON_UNESCAPED_UNICODE)
    );

    if ($resp === null) return false;
    $json = json_decode($resp, true);
    if (isset($json['name'])) return true;

    $errCode = fcm_extract_error_code($json ?? []);
    return false;
}

function fcm_ensure_token_table(PDO $pdo): void {
    $sql = "
        CREATE TABLE IF NOT EXISTS user_device_tokens (
            id INT AUTO_INCREMENT PRIMARY KEY,
            user_id INT NOT NULL,
            token VARCHAR(512) NOT NULL,
            platform VARCHAR(20) DEFAULT NULL,
            updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
            UNIQUE KEY uniq_token (token),
            INDEX idx_user_id (user_id)
        ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4
    ";
    try {
        $pdo->exec($sql);
    } catch (Exception $e) {
        fcm_log('Failed to ensure user_device_tokens table: ' . $e->getMessage());
    }
}

function fcm_get_user_tokens(PDO $pdo, int $userId): array {
    try {
        $st = $pdo->prepare("SELECT token FROM user_device_tokens WHERE user_id = ?");
        $st->execute([$userId]);
        return $st->fetchAll(PDO::FETCH_COLUMN);
    } catch (Exception $e) {
        fcm_log('Failed to fetch tokens: ' . $e->getMessage());
        return [];
    }
}

function fcm_delete_token(PDO $pdo, string $token): void {
    try {
        $st = $pdo->prepare("DELETE FROM user_device_tokens WHERE token = ?");
        $st->execute([$token]);
    } catch (Exception $e) {
        fcm_log('Failed to delete token: ' . $e->getMessage());
    }
}

function fcm_send_user_notification(PDO $pdo, int $userId, string $title, string $message, ?string $link = null, ?string $type = null, ?string $image = null): void {
    fcm_ensure_token_table($pdo);
    $tokens = fcm_get_user_tokens($pdo, $userId);
    if (empty($tokens)) return;

    $title = $title !== '' ? $title : 'Carby';
    $body = $message !== '' ? $message : 'New notification';

    if ($image && FCM_BASE_URL !== '' && !preg_match('#^https?://#i', $image)) {
        $image = rtrim(FCM_BASE_URL, '/') . '/' . ltrim($image, '/');
    }

    $data = [
        'user_id' => (string)$userId,
        'title' => $title,
        'msg' => $body,
    ];
    if ($link) $data['link'] = (string)$link;
    if ($type) $data['type'] = (string)$type;

    foreach ($tokens as $token) {
        $errCode = '';
        $ok = fcm_send_to_token((string)$token, $title, $body, $data, $image, $errCode);
        if (!$ok && $errCode !== '') {
            if (in_array($errCode, ['UNREGISTERED', 'INVALID_ARGUMENT', 'NOT_FOUND'], true)) {
                fcm_delete_token($pdo, (string)$token);
            }
        }
    }
}
