# 📱 تطبيق وجباتي - دليل الإعداد الكامل

## ✅ ما تم إنجازه

تم إنشاء تطبيق **Progressive Web App (PWA)** كامل يعمل على Android و iOS!

### 📄 الملفات المنشأة:

1. ✅ **manifest.json** - ملف التطبيق الأساسي
2. ✅ **sw.js** - Service Worker محسّن للإشعارات والتخزين المؤقت
3. ✅ **دليل_تثبيت_التطبيق.md** - دليل تفصيلي
4. ✅ **pwa-install-guide.html** - صفحة ويب للدليل
5. ✅ **add_pwa_meta.php** - سكريبت لإضافة meta tags

---

## 🚀 الخطوات السريعة

### 1. إنشاء الأيقونات (مطلوب)

أنشئ أيقونتين في المجلد الرئيسي:

- **icon-192.png** (192x192 بكسل)
- **icon-512.png** (512x512 بكسل)

**طريقة سريعة:**
1. استخدم `uploads/logo.png`
2. غيّر الحجم إلى 192x192 و 512x512
3. احفظهما كـ PNG

**أدوات مفيدة:**
- [PWA Asset Generator](https://www.pwabuilder.com/imageGenerator)
- [RealFaviconGenerator](https://realfavicongenerator.net/)
- Photoshop / GIMP / أي محرر صور

### 2. إضافة PWA Meta Tags لجميع الصفحات

**الطريقة الأسهل:**
1. ارفع `add_pwa_meta.php` للمجلد الرئيسي
2. افتحه في المتصفح: `https://yoursite.com/add_pwa_meta.php`
3. سيتم إضافة meta tags تلقائياً
4. **احذف الملف بعد الاستخدام** للأمان

**الطريقة اليدوية (إذا أردت):**
أضف هذه الأسطر في `<head>` لكل صفحة:

```html
<link rel="manifest" href="manifest.json">
<meta name="theme-color" content="#6c5ce7">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="black-translucent">
<meta name="apple-mobile-web-app-title" content="وجباتي">
<link rel="apple-touch-icon" href="uploads/logo.png">
```

**الصفحات المطلوبة:**
- ✅ client_dashboard.php (موجود بالفعل)
- ⚠️ client_browse_packages.php
- ⚠️ client_select_meals.php
- ⚠️ menu.php
- ⚠️ my_orders.php
- ⚠️ client_profile.php
- ⚠️ cart.php
- ⚠️ login.php
- ⚠️ register_client.php
- ⚠️ packages_public.php

### 3. التأكد من HTTPS

⚠️ **مهم جداً:** PWA لا يعمل إلا على:
- ✅ **HTTPS** (في الإنتاج)
- ✅ **localhost** (للتطوير)

### 4. اختبار التطبيق

**في Chrome/Edge:**
1. افتح الموقع
2. F12 > Application > Manifest
3. تحقق من أن Manifest يتم تحميله
4. Application > Service Workers
5. تحقق من تسجيل Service Worker

**اختبار PWA:**
- [PWA Builder](https://www.pwabuilder.com/)
- [Lighthouse](https://developers.google.com/web/tools/lighthouse)

---

## 📱 تثبيت التطبيق على الأجهزة

### Android (Chrome/Edge)

1. افتح الموقع
2. ستظهر رسالة "تثبيت التطبيق"
3. اضغط "تثبيت"
4. أو: القائمة (⋮) > "تثبيت التطبيق"

### iPhone/iPad (Safari فقط)

1. افتح الموقع في **Safari** (مهم!)
2. اضغط زر المشاركة (☐↑)
3. اختر "إضافة إلى الشاشة الرئيسية"
4. اكتب الاسم
5. اضغط "إضافة"

### الكمبيوتر

1. افتح الموقع في Chrome/Edge
2. ابحث عن أيقونة "تثبيت" في شريط العنوان
3. اضغط "تثبيت"

---

## 🔔 الإشعارات

### للعملاء:

1. عند فتح التطبيق لأول مرة
2. سيطلب الإذن للإشعارات
3. اضغط "السماح"
4. ستصل الإشعارات حتى عندما يكون التطبيق مغلقاً

### للإدارة (إرسال):

استخدم `marketing_center.php` لإرسال إشعارات للعملاء.

**ملاحظة iOS:** الإشعارات على iOS تعمل فقط عندما يكون التطبيق مفتوحاً (قيد Safari).

---

## 🎯 الميزات المتاحة

- ✅ **يعمل كتطبيق مستقل** (بدون شريط المتصفح)
- ✅ **إشعارات فورية** (Android كامل، iOS محدود)
- ✅ **يعمل بدون إنترنت** (الصفحات المخزنة)
- ✅ **سريع الاستجابة**
- ✅ **يمكن تثبيته** على الشاشة الرئيسية
- ✅ **يبدو كتطبيق أصلي**

---

## 📋 قائمة التحقق

### قبل النشر:

- [ ] إنشاء icon-192.png و icon-512.png
- [ ] رفع manifest.json
- [ ] رفع sw.js
- [ ] إضافة PWA meta tags لجميع الصفحات
- [ ] التأكد من HTTPS
- [ ] اختبار على Android
- [ ] اختبار على iOS
- [ ] اختبار الإشعارات

### بعد النشر:

- [ ] اختبر التثبيت على Android
- [ ] اختبر التثبيت على iOS
- [ ] اختبر الإشعارات
- [ ] تأكد من عمل Service Worker
- [ ] اختبر العمل بدون إنترنت

---

## 🛠️ استكشاف الأخطاء

### المشكلة: لا يظهر خيار التثبيت

**الحل:**
- تأكد من HTTPS
- تأكد من manifest.json موجود
- تحقق من Console للأخطاء
- تأكد من Service Worker مسجل

### المشكلة: Service Worker لا يعمل

**الحل:**
- تحقق من HTTPS
- امسح Cache (Ctrl+Shift+R)
- افتح DevTools > Application > Service Workers > Unregister
- أعد تحميل الصفحة

### المشكلة: الإشعارات لا تعمل

**الحل:**
- تحقق من إذن المتصفح
- Android: Settings > Apps > Your App > Notifications
- iOS: Settings > Safari > Notifications

### المشكلة: الأيقونات لا تظهر

**الحل:**
- تأكد من وجود icon-192.png و icon-512.png
- تحقق من مسارات الأيقونات في manifest.json
- تأكد من نوع الملف PNG

---

## 📞 الدعم

للحصول على المساعدة:

1. تحقق من Console (F12)
2. تحقق من Application > Manifest
3. تحقق من Application > Service Workers
4. راجع `دليل_تثبيت_التطبيق.md`

---

## 🎉 مبروك!

التطبيق جاهز للاستخدام. العملاء يمكنهم الآن:
- ✅ تثبيت التطبيق على هواتفهم
- ✅ استلام الإشعارات
- ✅ استخدام التطبيق بدون إنترنت
- ✅ تجربة أفضل وأسرع

---

**تم إنشاء:** 2025  
**الإصدار:** 1.0.0  
**الحالة:** ✅ جاهز للاستخدام

