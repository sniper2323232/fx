<?php
header("Cache-Control: no-cache, no-store, must-revalidate");
header('Content-Type: application/json; charset=utf-8');

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) {
    echo json_encode(['ok' => false, 'error' => 'not_logged_in']);
    exit;
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    echo json_encode(['ok' => false, 'error' => 'method_not_allowed']);
    exit;
}

$token = trim((string)($_POST['token'] ?? ''));
$platform = trim((string)($_POST['platform'] ?? ''));

if ($token === '') {
    echo json_encode(['ok' => false, 'error' => 'missing_token']);
    exit;
}

if ($platform === '') $platform = 'unknown';

require_once __DIR__ . '/db_connect.php';
require_once __DIR__ . '/notif_fcm.php';

fcm_ensure_token_table($pdo);

$userId = (int)$_SESSION['user_id'];

try {
    $st = $pdo->prepare("
        INSERT INTO user_device_tokens (user_id, token, platform, updated_at)
        VALUES (?, ?, ?, NOW())
        ON DUPLICATE KEY UPDATE
            user_id = VALUES(user_id),
            platform = VALUES(platform),
            updated_at = VALUES(updated_at)
    ");
    $st->execute([$userId, $token, $platform]);
} catch (Exception $e) {
    echo json_encode(['ok' => false, 'error' => 'db_error']);
    exit;
}

echo json_encode(['ok' => true]);
