<div class="sidebar">
    <div class="sidebar-header">
        <?php
            $restaurant_logo = '';
            $site_favicon = '';
            $admin_assets_version = '';
            try {
                if (!isset($pdo)) {
                    require_once 'db_connect.php';
                }
                if (isset($pdo)) {
                    $st = $pdo->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key IN ('restaurant_logo','site_favicon','admin_assets_version')");
                    $rows = $st ? $st->fetchAll(PDO::FETCH_KEY_PAIR) : [];
                    if (is_array($rows)) {
                        $restaurant_logo = (string)($rows['restaurant_logo'] ?? '');
                        $site_favicon = (string)($rows['site_favicon'] ?? '');
                        $admin_assets_version = (string)($rows['admin_assets_version'] ?? '');
                    }
                }
            } catch(Exception $e) {
                $restaurant_logo = '';
                $site_favicon = '';
                $admin_assets_version = '';
            }
        ?>
        <?php 
            $logo_path = 'uploads/logo.png';
            if (!empty($restaurant_logo) && file_exists('uploads/' . $restaurant_logo)) {
                $logo_path = 'uploads/' . $restaurant_logo;
            }
            
            $favicon_path = '';
            if (!empty($site_favicon) && file_exists('uploads/' . $site_favicon)) {
                $favicon_path = 'uploads/' . $site_favicon;
            } elseif (!empty($restaurant_logo) && file_exists('uploads/' . $restaurant_logo)) {
                $favicon_path = 'uploads/' . $restaurant_logo;
            }
            
            $favicon_type = '';
            if (!empty($favicon_path)) {
                $ext = strtolower(pathinfo($favicon_path, PATHINFO_EXTENSION));
                $favicon_type = ($ext === 'ico') ? 'image/x-icon' : 'image/png';
            }
        ?>
        <?php if(!empty($favicon_path)): ?>
        <script>
        (function(){
            var href = <?php echo json_encode($favicon_path, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
            var type = <?php echo json_encode($favicon_type, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
            var head = document.head || document.getElementsByTagName('head')[0];
            if(!head) return;
            function up(rel){
                var q = 'link[rel="' + rel + '"]';
                var link = head.querySelector(q);
                if(!link){
                    link = document.createElement('link');
                    link.rel = rel;
                    head.appendChild(link);
                }
                link.href = href;
                if(type) link.type = type;
            }
            up('icon');
            up('shortcut icon');
            up('apple-touch-icon');
        })();
        </script>
        <?php endif; ?>
        <?php if(!empty($admin_assets_version)): ?>
        <script>
        (function(){
            var v = <?php echo json_encode($admin_assets_version, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE); ?>;
            if(!v) return;
            var links = document.querySelectorAll('link[rel="stylesheet"][href*="admin_colors.php"], link[rel="stylesheet"][href*="admin-unified-style-v2.css"]');
            links.forEach(function(link){
                try{
                    var url = new URL(link.href, window.location.href);
                    var base = url.pathname.split('/').pop();
                    if (!/admin_colors\.php$/i.test(base) && !/admin-unified-style-v2\.css$/i.test(base)) return;
                    url.searchParams.set('v', v);
                    link.href = url.toString();
                }catch(e){}
            });
        })();
        </script>
        <?php endif; ?>
        <img class="sidebar-logo" src="<?php echo htmlspecialchars($logo_path); ?>" alt="">
        <h3><i class="fas fa-layer-group"></i> <span>لوحة الإدارة</span></h3>
    </div>
    
    <nav class="sidebar-nav">
        <?php 
            // 1. جلب اسم الصفحة الحالية
            $currentPage = basename($_SERVER['PHP_SELF']); 
            
            // 2. تحديد المجموعات (لإبقاء القائمة نشطة عند دخول الصفحات الفرعية)
            $isPackageSection = in_array($currentPage, ['view_packages.php', 'edit_package.php']);
            $isBranchSection = in_array($currentPage, ['view_branches.php', 'edit_branch.php']);
            
            // مجموعة المنتجات (الجديدة)
            $isProductSection = in_array($currentPage, ['manage_products.php', 'add_product.php', 'edit_product.php']);
            
            // مجموعة التصنيفات (الجديدة)
            $isCatSection = in_array($currentPage, ['manage_categories.php', 'edit_category.php']);
            
            $isClientSection = in_array($currentPage, ['view_clients.php', 'add_client.php', 'edit_client.php']);
            $isStaffSection = in_array($currentPage, ['view_staff.php', 'add_staff.php', 'edit_staff.php']);
            $isSubscriptionsSection = in_array($currentPage, ['subscriptions_center.php', 'subscription_edit.php']);
            $isOrdersSection = in_array($currentPage, ['admin_orders.php', 'admin_order_details.php']);
        ?>
        
        <a href="admin_dashboard.php" title="الرئيسية" class="<?php echo ($currentPage == 'admin_dashboard.php') ? 'active' : ''; ?>">
            <i class="fas fa-tachometer-alt"></i> <span class="navText">الرئيسية</span>
        </a>
        
        <?php
        // التحقق من إعداد قسم الطلبات
        $orders_enabled = true;
        try {
            if (!isset($pdo)) {
                require_once 'db_connect.php';
            }
            if (isset($pdo)) {
                $st = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key='orders_section_enabled' LIMIT 1");
                $st->execute();
                $val = $st->fetchColumn();
                $orders_enabled = ($val === false || $val === null || $val === '') ? true : ($val === '1');
            }
        } catch(Exception $e) {
            $orders_enabled = true;
        }
        if ($orders_enabled):
        ?>
        <a href="admin_orders.php" title="الطلبات" class="<?php echo ($isOrdersSection) ? 'active' : ''; ?>">
            <i class="fas fa-clipboard-list"></i> <span class="navText">الطلبات</span>
        </a>
        <?php endif; ?>
        
        <hr>
        
        <a href="manage_categories.php" title="التصنيفات" class="<?php echo ($isCatSection) ? 'active' : ''; ?>">
            <i class="fas fa-tags"></i> <span class="navText">التصنيفات</span>
        </a>
        
        <a href="manage_products.php" title="قائمة المنتجات" class="<?php echo ($isProductSection && $currentPage != 'add_product.php') ? 'active' : ''; ?>">
            <i class="fas fa-boxes"></i> <span class="navText">قائمة المنتجات</span>
        </a>
        
        <a href="add_product.php" title="إضافة منتج جديد" class="<?php echo ($currentPage == 'add_product.php') ? 'active' : ''; ?>">
            <i class="fas fa-plus-circle"></i> <span class="navText">إضافة منتج جديد</span>
        </a>
        <a href="manage_options.php" title="الخيارات" class="<?php echo ($currentPage == 'manage_options.php' || $currentPage == 'edit_option.php') ? 'active' : ''; ?>">
            <i class="fas fa-cubes"></i> <span class="navText">الخيارات</span>
        </a>
        <hr>
        <a href="subscriptions_center.php" title="الاشتراكات" class="<?php echo ($isSubscriptionsSection) ? 'active' : ''; ?>">
            <i class="fas fa-id-card"></i> <span class="navText">الاشتراكات</span>
        </a>
        <a href="view_packages.php" title="الباقات" class="<?php echo ($isPackageSection) ? 'active' : ''; ?>">
            <i class="fas fa-box-open"></i> <span class="navText">الباقات</span>
        </a>
        <a href="marketing_center.php" title="التسويق" class="<?php echo ($currentPage == 'marketing_center.php') ? 'active' : ''; ?>">
            <i class="fas fa-bullhorn"></i> <span class="navText">التسويق</span>
        </a>
        <hr>

        <a href="payment_settings.php" title="إعدادات الدفع" class="<?php echo ($currentPage == 'payment_settings.php') ? 'active' : ''; ?>">
            <i class="fas fa-credit-card"></i> <span class="navText">إعدادات الدفع</span>
        </a>
        <a href="view_branches.php" title="إدارة الفروع" class="<?php echo ($isBranchSection) ? 'active' : ''; ?>">
            <i class="fas fa-store"></i> <span class="navText">إدارة الفروع</span>
        </a>
        
        <hr>
        
        <a href="view_clients.php" title="العملاء" class="<?php echo ($isClientSection) ? 'active' : ''; ?>">
            <i class="fas fa-users"></i> <span class="navText">العملاء</span>
        </a> 
        
        <a href="view_staff.php" title="الموظفين" class="<?php echo ($isStaffSection) ? 'active' : ''; ?>">
            <i class="fas fa-user-shield"></i> <span class="navText">الموظفين</span>
        </a>
   
        <hr>
        
        <a href="system_settings.php" title="إعدادات النظام" class="<?php echo ($currentPage == 'system_settings.php') ? 'active' : ''; ?>">
            <i class="fas fa-tools"></i> <span class="navText">إعدادات النظام</span>
        </a>
   
    </nav>
    
</div>

<script>
(function(){
    function ensure(){
        var mq = window.matchMedia ? window.matchMedia('(max-width: 1024px)') : null;
        var isTablet = mq ? mq.matches : (window.innerWidth <= 1024);
        var sidebar = document.querySelector('.sidebar');
        var topbar = document.querySelector('.top-bar');
        if (!sidebar) return;

        var overlay = document.querySelector('.sidebarOverlay');
        if (!overlay) {
            overlay = document.createElement('div');
            overlay.className = 'sidebarOverlay';
            document.body.appendChild(overlay);
        }

        var btn = document.querySelector('.sidebarToggle');
        if (!btn) {
            btn = document.createElement('button');
            btn.type = 'button';
            btn.className = 'sidebarToggle';
            btn.setAttribute('aria-label', 'القائمة');
            btn.innerHTML = '<i class="fa-solid fa-bars"></i>';
            if (topbar) {
                topbar.insertBefore(btn, topbar.firstChild);
            } else {
                btn.classList.add('floating');
                document.body.appendChild(btn);
            }
        }

        function close(){
            sidebar.classList.remove('show');
            overlay.classList.remove('show');
            document.body.classList.remove('sidebarOpen');
        }
        function open(){
            sidebar.classList.add('show');
            overlay.classList.add('show');
            document.body.classList.add('sidebarOpen');
        }
        function toggle(){
            if (sidebar.classList.contains('show')) close();
            else open();
        }

        var closeBtn = document.querySelector('.sidebarClose');
        if (!closeBtn) {
            closeBtn = document.createElement('button');
            closeBtn.type = 'button';
            closeBtn.className = 'sidebarClose';
            closeBtn.setAttribute('aria-label', 'إغلاق القائمة');
            closeBtn.innerHTML = '<i class="fa-solid fa-xmark"></i>';
            var head = sidebar.querySelector('.sidebar-header');
            if (head) head.appendChild(closeBtn);
        }
        closeBtn.onclick = function(e){
            if (!isTablet) return;
            e.preventDefault();
            close();
        };

        btn.onclick = function(e){
            if (!isTablet) return;
            e.preventDefault();
            toggle();
        };
        overlay.onclick = function(){
            close();
        };

        document.addEventListener('pointerdown', function(ev){
            if (!isTablet) return;
            if (!sidebar.classList.contains('show')) return;
            var t = ev.target;
            if (btn && (t === btn || btn.contains(t))) return;
            if (sidebar.contains(t)) return;
            close();
        }, true);

        document.addEventListener('keydown', function(ev){
            if (!isTablet) return;
            if (!sidebar.classList.contains('show')) return;
            if (ev.key === 'Escape') close();
        });

        if (!isTablet) {
            btn.style.display = 'none';
            close();
        } else {
            btn.style.display = '';
        }

        if (mq && !mq.__bound) {
            mq.addEventListener('change', function(){ ensure(); });
            mq.__bound = true;
        }
    }
    if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', ensure);
    else ensure();
})();
</script>
