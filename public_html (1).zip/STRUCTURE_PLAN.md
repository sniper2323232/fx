# خطة إعادة تنظيم المشروع (بدون كسر الروابط)

## الهدف
تقليل الملفات في الجذر، توحيد الإعدادات/الجلسات/CSRF، وفصل المنطق عن العرض تدريجيًا.

## تم تطبيقه في هذه النسخة
- إضافة `includes/bootstrap.php` كنقطة دخول موحدة للجلسة و CSRF.
- توحيد ملفات `auth_*.php` لتستخدم `auth.php` + `requireRole(...)`.
- إضافة حقول CSRF تلقائيًا لعدة صفحات نموذجية، وفرض CSRF على معالجات حساسة.
- إضافة `src/` و `templates/` كبداية (بدون نقل جذري).

## المرحلة القادمة المقترحة
1. نقل ملفات البنية (غير الصفحات) إلى `includes/`:
   - config.php, db_connect.php, csrf.php, Payment*.php
   - ثم إنشاء ملفات Stub في الجذر تستدعي النسخ الجديدة للحفاظ على التوافق.

2. إنشاء Router تدريجي:
   - `public/index.php` + rewrite في .htaccess
   - البدء بأكثر الصفحات استخدامًا (login, dashboard, cart, checkout).

3. فصل HTML إلى `templates/`:
   - head/footer موحد
   - views لكل صفحة بدل تكرار markup

4. فصل منطق الأعمال إلى `src/Services/`:
   - OrdersService, CartService, PaymentService
   - ثم استدعائها من controllers

## ملاحظة
إذا رغبت، أجهز لك PR-style نقل تدريجي: كل خطوة (10-20 ملف) مع اختبار سريع.
