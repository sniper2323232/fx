(function () {
  if (document.getElementById('notifPanel')) return;

  var POLL_MS = 15000;
  var lastId = parseInt(localStorage.getItem('client_last_notif_id') || '0', 10);
  var audioCtx = null;
  var permHooked = false;

  function warmAudio() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtx) audioCtx = new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume().catch(function () {});
    } catch (e) {}
  }

  function hookPermissionOnUserGesture() {
    if (permHooked) return;
    permHooked = true;
    document.addEventListener('click', function once() {
      document.removeEventListener('click', once);
      warmAudio();
      if (!('Notification' in window)) return;
      if (Notification.permission !== 'default') return;
      Notification.requestPermission().catch(function () {});
    }, { once: true, capture: true });
  }

  function playSound() {
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtx) audioCtx = new Ctx();
      if (audioCtx.state === 'suspended') audioCtx.resume().catch(function () {});

      var osc = audioCtx.createOscillator();
      var gain = audioCtx.createGain();
      osc.type = 'sine';
      osc.frequency.value = 880;
      gain.gain.value = 0.0001;
      osc.connect(gain);
      gain.connect(audioCtx.destination);

      var now = audioCtx.currentTime;
      gain.gain.setValueAtTime(0.0001, now);
      gain.gain.exponentialRampToValueAtTime(0.12, now + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.0001, now + 0.28);
      osc.start(now);
      osc.stop(now + 0.30);
    } catch (e) {}
  }

  function markSeen(id) {
    if (!id) return;
    fetch('mark_notif_seen.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: 'id=' + encodeURIComponent(id)
    }).catch(function () {});
  }

  function ensureToast() {
    var existing = document.getElementById('clientNotifToast');
    if (existing) return existing;

    var toast = document.createElement('div');
    toast.id = 'clientNotifToast';
    toast.style.cssText = 'position:fixed;top:16px;left:16px;right:16px;max-width:520px;margin:0 auto;padding:14px 16px;border-radius:16px;background:#111827;color:#fff;box-shadow:0 18px 45px rgba(0,0,0,0.2);z-index:9999;display:none;gap:12px;align-items:center;font-family:Tahoma,Arial,sans-serif;';

    var img = document.createElement('img');
    img.id = 'clientNotifToastImg';
    img.style.cssText = 'width:52px;height:52px;border-radius:12px;object-fit:cover;display:none;';

    var textWrap = document.createElement('div');
    textWrap.style.flex = '1';

    var title = document.createElement('div');
    title.id = 'clientNotifToastTitle';
    title.style.cssText = 'font-weight:700;margin-bottom:4px;';

    var body = document.createElement('div');
    body.id = 'clientNotifToastBody';
    body.style.cssText = 'font-size:0.9rem;opacity:0.9;line-height:1.4;';

    textWrap.appendChild(title);
    textWrap.appendChild(body);

    toast.appendChild(img);
    toast.appendChild(textWrap);
    document.body.appendChild(toast);

    return toast;
  }

  function showToast(data) {
    var toast = ensureToast();
    var img = document.getElementById('clientNotifToastImg');
    var title = document.getElementById('clientNotifToastTitle');
    var body = document.getElementById('clientNotifToastBody');

    title.textContent = data.title || '\u0625\u0634\u0639\u0627\u0631 \u062c\u062f\u064a\u062f';
    body.textContent = data.msg || '';

    if (data.img) {
      img.src = data.img;
      img.style.display = 'block';
    } else {
      img.style.display = 'none';
    }

    toast.style.display = 'flex';
    setTimeout(function () { toast.style.display = 'none'; }, 9000);
  }

  function notifySystem(data) {
    if (!('Notification' in window)) return;

    function show() {
      if ('serviceWorker' in navigator) {
        navigator.serviceWorker.ready.then(function (reg) {
          reg.showNotification(data.title || '\u0625\u0634\u0639\u0627\u0631 \u062c\u062f\u064a\u062f', {
            body: data.msg || '',
            icon: data.img || 'icon.png',
            badge: data.img || 'icon.png',
            data: { url: data.link || 'client_dashboard.php' }
          });
        }).catch(function () {});
      } else {
        try {
          new Notification(data.title || '\u0625\u0634\u0639\u0627\u0631 \u062c\u062f\u064a\u062f', { body: data.msg || '', icon: data.img || 'icon.png' });
        } catch (e) {}
      }
    }

    if (Notification.permission === 'granted') {
      show();
    } else {
      hookPermissionOnUserGesture();
    }
  }

  function check() {
    fetch('check_notif.php', { cache: 'no-store' })
      .then(function (r) { return r.json(); })
      .then(function (data) {
        if (!data || !data.id) return;
        var id = parseInt(data.id, 10);
        if (!id || id === lastId) return;

        lastId = id;
        localStorage.setItem('client_last_notif_id', String(id));
        markSeen(id);

        showToast(data);
        playSound();
        notifySystem(data);
      })
      .catch(function () {});
  }

  if ('serviceWorker' in navigator) {
    navigator.serviceWorker.register('sw.js').catch(function () {});
  }

  hookPermissionOnUserGesture();
  check();
  setInterval(check, POLL_MS);
})();
