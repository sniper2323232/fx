<?php
// subscriptions_center.php - Subscriptions List (Improved UI + Per-Client Summary + External Edit Page)
// ===============================================================================================
// يجب استدعاء lang_handler.php قبل أي header() أو output
require_once 'lang_handler.php';

header('Content-Type: text/html; charset=utf-8');
require_once 'auth_admin.php';
require_once 'db_connect.php';

ini_set('display_errors', 0);
error_reporting(E_ALL);

function safeInt($v): int { return (is_numeric($v) ? (int)$v : 0); }
function safeStr($v): string { return trim((string)$v); }

function getSetting(PDO $pdo, string $key, $default=null) {
    try {
        $st = $pdo->prepare("SELECT setting_value FROM system_settings WHERE setting_key=? LIMIT 1");
        $st->execute([$key]);
        $v = $st->fetchColumn();
        return ($v === false || $v === null || $v === '') ? $default : $v;
    } catch(Exception $e) {
        return $default;
    }
}

function columnExists(PDO $pdo, string $table, string $column): bool {
    try {
        $st = $pdo->prepare("
            SELECT COUNT(*)
            FROM information_schema.COLUMNS
            WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?
        ");
        $st->execute([$table, $column]);
        return (int)$st->fetchColumn() > 0;
    } catch(Exception $e){
        return false;
    }
}

function ensureTables(PDO $pdo){
    // Per-client option categories
    $pdo->exec("CREATE TABLE IF NOT EXISTS client_option_category_limits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        option_category_id INT NOT NULL,
        allowed_count INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_client_optcat (user_id, option_category_id),
        KEY idx_user (user_id),
        KEY idx_optcat (option_category_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    $pdo->exec("CREATE TABLE IF NOT EXISTS client_option_category_visibility (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        option_category_id INT NOT NULL,
        is_enabled TINYINT(1) NOT NULL DEFAULT 1,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_client_optcat_vis (user_id, option_category_id),
        KEY idx_user (user_id),
        KEY idx_optcat (option_category_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // Per-client meal category limits (using client_category_limits - same table as subscription_edit.php)
    $pdo->exec("CREATE TABLE IF NOT EXISTS client_category_limits (
        id INT AUTO_INCREMENT PRIMARY KEY,
        user_id INT NOT NULL,
        category_id INT NOT NULL,
        allowed_count INT NOT NULL DEFAULT 0,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
        UNIQUE KEY uq_client_cat (user_id, category_id),
        KEY idx_user (user_id),
        KEY idx_cat (category_id)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

    // client_details overrides
    try {
        if (!columnExists($pdo, 'client_details', 'duration_days_override')) {
            $pdo->exec("ALTER TABLE client_details ADD COLUMN duration_days_override INT NULL DEFAULT NULL AFTER subscription_start_date");
        }
    } catch(Exception $e) {}
    try {
        if (!columnExists($pdo, 'client_details', 'subscription_end_date')) {
            $pdo->exec("ALTER TABLE client_details ADD COLUMN subscription_end_date DATE NULL DEFAULT NULL AFTER duration_days_override");
        }
    } catch(Exception $e) {}
    try {
        if (!columnExists($pdo, 'client_details', 'grace_period_days_override')) {
            $pdo->exec("ALTER TABLE client_details ADD COLUMN grace_period_days_override INT NULL DEFAULT NULL AFTER order_no");
        }
    } catch(Exception $e) {}
}

function computeEndDate(?string $startYmd, ?int $days): ?string {
    $startYmd = $startYmd ? trim($startYmd) : '';
    if ($startYmd === '' || !$days || $days <= 0) return null;
    try {
        $dt = new DateTime($startYmd);
        $dt->modify('+' . (int)$days . ' days');
        return $dt->format('Y-m-d');
    } catch(Exception $e){
        return null;
    }
}

function pkgById(array $all, int $id): ?array {
    foreach ($all as $p) { if ((int)$p['id'] === $id) return $p; }
    return null;
}

function effectiveDurationDays(array $cdRow, ?array $pkgRow): int {
    $ov = safeInt($cdRow['duration_days_override'] ?? 0);
    if ($ov > 0) return $ov;
    return safeInt($pkgRow['duration_days'] ?? 0);
}

function effectiveEndDate(array $cdRow, ?array $pkgRow): string {
    $end = safeStr($cdRow['subscription_end_date'] ?? '');
    if ($end !== '') return $end;
    $start = safeStr($cdRow['subscription_start_date'] ?? '');
    $days  = effectiveDurationDays($cdRow, $pkgRow);
    return computeEndDate($start, $days) ?: '';
}

function computeRemainingDays(?string $endYmd): int {
    if (!$endYmd) return 0;
    try {
        $now = new DateTime(date('Y-m-d'));
        $end = new DateTime($endYmd);
        if ($now > $end) return 0;
        return (int)$now->diff($end)->days;
    } catch(Exception $e){
        return 0;
    }
}

function computeUsedMeals(PDO $pdo, int $clientId, ?string $startYmd): int {
    if (!$startYmd) return 0;
    try {
        $st = $pdo->prepare("SELECT COUNT(*) FROM daily_selections WHERE client_id=? AND delivery_date >= ?");
        $st->execute([$clientId, $startYmd]);
        return (int)$st->fetchColumn();
    } catch(Exception $e){
        return 0;
    }
}

/**
 * Total allowed meals for client:
 * - base from package_category_limits (sum)
 * - if client has overrides in client_category_limits => replace per category (only for categories that exist in package limits)
 * - if client override includes category not in package limits => add it (as extra supply)
 * - add meals_credit_extra from client_details
 */
function computeTotalAllowedMeals(PDO $pdo, int $clientId, int $packageId, int $mealsCreditExtra = 0): int {
    $pkgCats = [];
    try {
        $st = $pdo->prepare("SELECT category_id, allowed_count FROM package_category_limits WHERE package_id=?");
        $st->execute([$packageId]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $pkgCats[(int)$r['category_id']] = (int)$r['allowed_count'];
        }
    } catch(Exception $e){}

    $clientCats = [];
    try {
        $st = $pdo->prepare("SELECT category_id, allowed_count FROM client_category_limits WHERE user_id=?");
        $st->execute([$clientId]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $clientCats[(int)$r['category_id']] = (int)$r['allowed_count'];
        }
    } catch(Exception $e){}

    // Merge: client overrides replace or add
    foreach ($clientCats as $cid => $cnt) {
        $pkgCats[$cid] = $cnt; // replace or add
    }

    $sum = 0;
    foreach ($pkgCats as $cnt) $sum += max(0, (int)$cnt);
    
    // Add meals_credit_extra
    $sum += max(0, (int)$mealsCreditExtra);
    
    return (int)$sum;
}

ensureTables($pdo);

// Base data
$allPackages = $pdo->query("SELECT id, name, duration_days, meals_per_day, allowed_weight FROM packages ORDER BY id DESC")
    ->fetchAll(PDO::FETCH_ASSOC);

// Search
$q = safeStr($_GET['q'] ?? '');
$where = "u.role='client'";
$params = [];
if ($q !== '') {
    $where .= " AND (u.name LIKE ? OR u.email LIKE ? OR cd.phone LIKE ? OR cd.order_no LIKE ? OR u.id = ?)";
    $like = "%{$q}%";
    $params = [$like, $like, $like, $like, safeInt($q)];
}

// Fetch clients
$st = $pdo->prepare("
    SELECT
        u.id, u.name, u.email,
        cd.package_id, cd.subscription_start_date, cd.duration_days_override, cd.subscription_end_date,
        cd.meals_per_day_extra, cd.meals_credit_extra, cd.options_per_day_override,
        cd.order_no
    FROM users u
    LEFT JOIN client_details cd ON cd.user_id = u.id
    WHERE $where
    ORDER BY u.id DESC
    LIMIT 300
");
$st->execute($params);
$clients = $st->fetchAll(PDO::FETCH_ASSOC);

// Summary counters (simple)
$totalClients = count($clients);
$activeCount = 0;
$today = date('Y-m-d');

foreach ($clients as $c) {
    $pid = safeInt($c['package_id'] ?? 0);
    if ($pid <= 0) continue;
    $pkg = pkgById($allPackages, $pid);
    $end = effectiveEndDate($c, $pkg);
    if ($end && $today <= $end) $activeCount++;
}

$reportRows = [];
foreach ($clients as $c) {
    $cid = safeInt($c['id'] ?? 0);
    $pid = safeInt($c['package_id'] ?? 0);
    $pkg = ($pid > 0) ? pkgById($allPackages, $pid) : null;

    $pkgName = $pkg ? safeStr($pkg['name'] ?? '—') : '—';
    $start = safeStr($c['subscription_start_date'] ?? '');
    $end = ($pkg && $pid > 0) ? safeStr(effectiveEndDate($c, $pkg)) : '';

    $daysRem = ($end !== '') ? computeRemainingDays($end) : 0;

    $mealsCreditExtra = safeInt($c['meals_credit_extra'] ?? 0);
    $totalAllowed = ($pid > 0) ? computeTotalAllowedMeals($pdo, $cid, $pid, $mealsCreditExtra) : 0;
    $usedMeals = ($pid > 0) ? computeUsedMeals($pdo, $cid, $start) : 0;
    $mealsRem = max(0, $totalAllowed - $usedMeals);

    $statusText = 'غير نشط';
    if ($pid > 0 && $end !== '') {
        $statusText = (date('Y-m-d') <= $end) ? 'نشط' : 'منتهي';
    }

    $reportRows[] = [
        'id' => (int)$cid,
        'name' => safeStr($c['name'] ?? ''),
        'email' => safeStr($c['email'] ?? ''),
        'order_no' => safeStr($c['order_no'] ?? ''),
        'package' => $pkgName,
        'start' => $start,
        'end' => $end,
        'status' => $statusText,
        'total_allowed' => (int)$totalAllowed,
        'used_meals' => (int)$usedMeals,
        'remaining_meals' => (int)$mealsRem,
        'remaining_days' => (int)$daysRem,
    ];
}

$export = safeStr($_GET['export'] ?? '');
if ($export === 'csv') {
    header('Content-Type: text/csv; charset=utf-8');
    $filename = 'subscriptions_report_' . date('Y-m-d') . '.csv';
    header("Content-Disposition: attachment; filename={$filename}");
    $out = fopen('php://output', 'w');
    fwrite($out, "\xEF\xBB\xBF");
    fputcsv($out, [
        'ID',
        'العميل',
        'البريد',
        'رقم الطلب',
        'الباقة',
        'بداية الاشتراك',
        'نهاية الاشتراك (فعلي)',
        'الحالة',
        'إجمالي الوجبات',
        'الوجبات المستخدمة',
        'الوجبات المتبقية',
        'الأيام المتبقية',
    ]);
    foreach ($reportRows as $r) {
        fputcsv($out, [
            $r['id'],
            $r['name'],
            $r['email'],
            $r['order_no'],
            $r['package'],
            $r['start'],
            $r['end'],
            $r['status'],
            $r['total_allowed'],
            $r['used_meals'],
            $r['remaining_meals'],
            $r['remaining_days'],
        ]);
    }
    fclose($out);
    exit;
}
if ($export === 'print') {
    header('Content-Type: text/html; charset=utf-8');
    $qTitle = ($q !== '') ? (' — بحث: ' . htmlspecialchars($q, ENT_QUOTES, 'UTF-8')) : '';
    ?>
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width,initial-scale=1">
        <title>تقرير الاشتراكات<?php echo $qTitle; ?></title>
        <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
        <link rel="stylesheet" href="admin_colors.php?v=20260113">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
        <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
        <style>
            body { background: #fff; }
            .printWrap { max-width: 1100px; margin: 0 auto; padding: 18px; }
            .printTop { display:flex; align-items:center; justify-content:space-between; gap:12px; flex-wrap:wrap; margin-bottom: 12px; }
            .printTop .t { font-weight: 1000; font-size: 1.2rem; color: var(--admin-text-main); }
            .printTop .m { color: var(--admin-text-muted); font-weight: 900; }
            table { min-width: 0; width: 100%; }
            th, td { white-space: normal; }
            .btns { display:flex; gap:10px; flex-wrap:wrap; }
            @media print {
                .btns { display:none !important; }
                .card { box-shadow: none !important; border: 0 !important; }
                .wrap { padding: 0 !important; }
                body { background: #fff !important; }
                thead { position: static !important; }
            }
        </style>
    </head>
    <body>
        <div class="printWrap">
            <div class="printTop">
                <div>
                    <div class="t"><i class="fa-solid fa-file-lines" style="color:var(--restaurant-primary)"></i> تقرير الاشتراكات</div>
                    <div class="m">
                        تاريخ: <?php echo htmlspecialchars(date('Y-m-d H:i'), ENT_QUOTES, 'UTF-8'); ?>
                        <?php if ($q !== ''): ?> — بحث: <?php echo htmlspecialchars($q, ENT_QUOTES, 'UTF-8'); ?><?php endif; ?>
                    </div>
                </div>
                <div class="btns">
                    <button class="btn btnPrimary" onclick="window.print()"><i class="fa-solid fa-print"></i> طباعة / حفظ PDF</button>
                    <a class="btn btnGhost" href="subscriptions_center.php<?php echo $q !== '' ? ('?q=' . urlencode($q)) : ''; ?>"><i class="fa-solid fa-arrow-right"></i> رجوع</a>
                </div>
            </div>

            <div class="card">
                <div class="tableWrap" style="overflow:visible">
                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>العميل</th>
                                <th>رقم الطلب</th>
                                <th>الباقة</th>
                                <th>بداية</th>
                                <th>نهاية</th>
                                <th>الحالة</th>
                                <th>إجمالي</th>
                                <th>مستخدم</th>
                                <th>متبقي</th>
                            </tr>
                        </thead>
                        <tbody>
                        <?php foreach ($reportRows as $r): ?>
                            <tr>
                                <td><?php echo (int)$r['id']; ?></td>
                                <td>
                                    <b><?php echo htmlspecialchars($r['name'], ENT_QUOTES, 'UTF-8'); ?></b><br>
                                    <small><?php echo htmlspecialchars($r['email'], ENT_QUOTES, 'UTF-8'); ?></small>
                                </td>
                                <td><?php echo htmlspecialchars($r['order_no'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($r['package'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($r['start'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($r['end'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo htmlspecialchars($r['status'], ENT_QUOTES, 'UTF-8'); ?></td>
                                <td><?php echo (int)$r['total_allowed']; ?></td>
                                <td><?php echo (int)$r['used_meals']; ?></td>
                                <td><?php echo (int)$r['remaining_meals']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                        <?php if (empty($reportRows)): ?>
                            <tr><td colspan="10" style="text-align:center;color:var(--admin-text-muted);padding:18px;font-weight:1000;">لا توجد نتائج</td></tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </body>
    </html>
    <?php
    exit;
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>إدارة الاشتراكات</title>
  <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
  <link rel="stylesheet" href="admin_colors.php?v=20260113">
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
  <style>
    .subPageTitle{display:flex;align-items:flex-start;justify-content:space-between;gap:14px;flex-wrap:wrap}
    .subPageTitle h1{margin:0;font-size:1.35rem;font-weight:1100;color:var(--admin-text-main);display:flex;align-items:center;gap:10px}
    .subPageTitle h1 i{color:var(--restaurant-primary)}
    .subPageTitle p{margin:6px 0 0;color:var(--admin-text-secondary);font-weight:900;line-height:1.7}
    .subActions{display:flex;gap:10px;flex-wrap:wrap}

    .searchCard{padding:16px 18px}
    .searchGrid{display:grid;grid-template-columns:1fr auto;gap:10px;align-items:center}
    .searchGrid .inp{min-width:320px}
    .searchBtns{display:flex;gap:10px;flex-wrap:wrap;justify-content:flex-end}
    .searchHint{margin-top:10px;color:var(--admin-text-secondary);font-weight:900;font-size:.92rem}
    .searchHint b{color:var(--admin-text-main)}

    .tableWrap{overflow:visible;border-radius:16px;border:1px solid var(--admin-border);background:var(--admin-surface)}
    .tableWrap table{min-width:0;width:100%;table-layout:fixed;border-collapse:separate;border-spacing:0}
    .tableWrap thead th{background:linear-gradient(135deg, rgba(217, 119, 6, 0.10) 0%, rgba(245, 158, 11, 0.06) 100%);color:var(--admin-text-main);font-weight:1100}
    .tableWrap th,.tableWrap td{padding:12px 14px}
    .tableWrap th{white-space:nowrap}
    .tableWrap td{white-space:normal;word-break:normal;overflow-wrap:normal;vertical-align:middle;line-height:1.5}
    .tableWrap tbody tr{transition:background .15s}
    .tableWrap tbody tr:hover{background:rgba(217, 119, 6, 0.04)}
    .tableWrap td:last-child{text-align:center}
    .subMono{font-family:ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace;letter-spacing:.2px}
    .subName{font-weight:1100;color:var(--admin-text-main);font-size:1.02rem;line-height:1.3}
    .subEmail{margin-top:4px;color:var(--admin-text-muted);font-weight:800;font-size:.86rem;direction:ltr;text-align:right;line-height:1.3;overflow-wrap:anywhere}
    .subMeta{margin-top:8px;display:flex;gap:8px;flex-wrap:wrap;align-items:center}
    .pill{padding:6px 10px;font-size:.82rem}
    .pill i{font-size:.78rem}
    .ctlBtn{padding:10px 12px;border-radius:14px;white-space:nowrap}
    .subSubTitle{color:var(--admin-text-secondary);font-weight:1000;font-size:.82rem;margin-bottom:4px}
    .subStrong{color:var(--admin-text-main);font-weight:1100}
    .nowrap{white-space:nowrap}
    .subMono{overflow-wrap:anywhere}

    @media (max-width: 980px) {
      .tableWrap { background: transparent; }
      .tableWrap table,
      .tableWrap thead,
      .tableWrap tbody,
      .tableWrap th,
      .tableWrap td,
      .tableWrap tr { display: block; }
      .tableWrap thead { display: none; }
      .tableWrap tr {
        background: var(--admin-surface);
        border: 1px solid var(--admin-border);
        border-radius: 18px;
        box-shadow: var(--admin-shadow-sm);
        padding: 12px 14px;
        margin-bottom: 12px;
      }
      .tableWrap td {
        display: flex;
        align-items: flex-start;
        justify-content: space-between;
        gap: 12px;
        padding: 10px 0;
        border-bottom: 1px dashed rgba(28, 25, 23, 0.10);
      }
      .tableWrap td:last-child { border-bottom: 0; padding-bottom: 0; }
      .tableWrap td::before {
        content: attr(data-label);
        color: var(--admin-text-secondary);
        font-weight: 1000;
        flex: 0 0 104px;
        max-width: 104px;
      }
      .tableWrap td > * { max-width: calc(100% - 114px); }
      .tableWrap td[data-label="تحكم"] a { width: 100%; justify-content: center; }
      .searchGrid{grid-template-columns:1fr}
      .searchGrid .inp{min-width:0}
      .searchBtns{justify-content:stretch}
      .searchBtns .btn{flex:1}
    }
  </style>
</head>
<body>

  <?php include 'sidebar.php'; ?>

  <div class="main-content">
    <header class="top-bar">
      <div class="user-info"><i class="fa-solid fa-cubes-stacked"></i> إدارة الاشتراكات</div>
      <div style="display:flex; gap:10px; align-items:center;">
        <?php echo langSwitcher(); ?>
        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> خروج</a>
      </div>
    </header>

    <main class="content-wrapper">
    <div class="wrap">

      <div class="pageHead">
        <div class="subPageTitle">
          <div>
            <h1><i class="fa-solid fa-id-badge"></i> مركز الاشتراكات</h1>
            <p>ابحث سريعاً وادخل لصفحة التعديل لكل عميل. العرض هنا للمتابعة والملخص.</p>
          </div>
          <div class="subActions">
            <a class="btn btnGhost" href="subscriptions_center.php?<?php echo htmlspecialchars(http_build_query(['q' => $q, 'export' => 'csv'])); ?>">
              <i class="fa-solid fa-file-excel"></i> تصدير Excel
            </a>
            <a class="btn btnGhost" target="_blank" href="subscriptions_center.php?<?php echo htmlspecialchars(http_build_query(['q' => $q, 'export' => 'print'])); ?>">
              <i class="fa-solid fa-file-pdf"></i> تقرير PDF
            </a>
          </div>
        </div>
      </div>

      <div class="statsRow">
        <div class="statCard">
          <div class="statIcon"><i class="fa-solid fa-users"></i></div>
          <div class="statInfo">
            <b><?php echo (int)$totalClients; ?></b>
            <small>عملاء ضمن نتائج البحث</small>
          </div>
        </div>

        <div class="statCard">
          <div class="statIcon"><i class="fa-solid fa-bolt"></i></div>
          <div class="statInfo">
            <b><?php echo (int)$activeCount; ?></b>
            <small>اشتراكات “فعّالة” حسب نهاية الاشتراك</small>
          </div>
        </div>

        <div class="statCard">
          <div class="statIcon"><i class="fa-solid fa-magnifying-glass"></i></div>
          <div class="statInfo">
            <b><?php echo ($q !== '' ? 'مفعّل' : 'غير مفعّل'); ?></b>
            <small>فلتر البحث</small>
          </div>
        </div>
      </div>

      <div class="card searchCard">
        <form method="GET">
          <div class="searchGrid">
            <input class="inp" name="q" value="<?php echo htmlspecialchars($q); ?>"
                   placeholder="ابحث بالاسم / البريد / الهاتف / رقم الطلب / ID" aria-label="بحث">
            <div class="searchBtns">
              <button class="btn btnPrimary" type="submit"><i class="fa-solid fa-magnifying-glass"></i> بحث</button>
              <a class="btn btnGhost" href="subscriptions_center.php"><i class="fa-solid fa-rotate-left"></i> مسح</a>
            </div>
          </div>
          <div class="searchHint">
            نتائج: <b><?php echo (int)$totalClients; ?></b> — اشتراكات فعّالة: <b><?php echo (int)$activeCount; ?></b>
            <?php if ($q !== ''): ?> — كلمة البحث: <b><?php echo htmlspecialchars($q); ?></b><?php endif; ?>
          </div>
        </form>
      </div>

      <div class="card">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;">
          <div style="font-weight:1000;font-size:1.05rem;"><i class="fa-solid fa-table-list" style="color:var(--restaurant-primary)"></i> قائمة العملاء</div>
          <div style="color:var(--admin-text-secondary);font-weight:900;font-size:.9rem;">عرض مختصر وواضح لكل عميل</div>
        </div>

        <div class="tableWrap">
          <table>
            <colgroup>
              <col style="width:7%">
              <col style="width:28%">
              <col style="width:22%">
              <col style="width:18%">
              <col style="width:17%">
              <col style="width:8%">
            </colgroup>
            <thead>
              <tr>
                <th>ID</th>
                <th>العميل</th>
                <th>الاشتراك</th>
                <th>الفترة</th>
                <th>المتبقي</th>
                <th>تحكم</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach($clients as $c):
                $cid = safeInt($c['id'] ?? 0);
                $pid = safeInt($c['package_id'] ?? 0);
                $pkg = ($pid>0) ? pkgById($allPackages, $pid) : null;

                $pkgName = $pkg ? ($pkg['name'] ?? '—') : '—';
                $start = safeStr($c['subscription_start_date'] ?? '');
                $end   = $pkg ? effectiveEndDate($c, $pkg) : '';

                $daysRem = ($end !== '') ? computeRemainingDays($end) : 0;

                $mealsCreditExtra = safeInt($c['meals_credit_extra'] ?? 0);
                $totalAllowed = ($pid>0) ? computeTotalAllowedMeals($pdo, $cid, $pid, $mealsCreditExtra) : 0;
                $usedMeals = ($pid>0) ? computeUsedMeals($pdo, $cid, $start) : 0;
                $mealsRem = max(0, $totalAllowed - $usedMeals);

                $statusPill = 'bad';
                $statusText = 'غير نشط';
                if ($pid > 0 && $end !== '') {
                  if (date('Y-m-d') <= $end) { $statusPill='ok'; $statusText='نشط'; }
                  else { $statusPill='warn'; $statusText='منتهي'; }
                }

                $daysPill = 'muted';
                if ($statusText === 'نشط') {
                  if ($daysRem <= 3) $daysPill = 'warn';
                  else $daysPill = 'ok';
                } elseif ($statusText === 'منتهي') {
                  $daysPill = 'bad';
                }

                $mealsPill = 'muted';
                if ($statusText === 'نشط') {
                  if ($mealsRem <= 3) $mealsPill = 'warn';
                  else $mealsPill = 'ok';
                } elseif ($statusText === 'منتهي') {
                  $mealsPill = 'bad';
                }
              ?>
                <tr>
                  <td data-label="ID"><span class="subMono">#<?php echo (int)$cid; ?></span></td>
                  <td data-label="العميل">
                    <div class="subName"><?php echo htmlspecialchars($c['name'] ?? ''); ?></div>
                    <div class="subEmail"><?php echo htmlspecialchars($c['email'] ?? ''); ?></div>
                    <div class="subMeta">
                      <span class="pill <?php echo $statusPill; ?>"><i class="fa-solid fa-circle"></i> <?php echo $statusText; ?></span>
                    </div>
                  </td>
                  <td data-label="الاشتراك">
                    <div class="subStrong"><?php echo htmlspecialchars($pkgName); ?></div>
                    <div style="margin-top:6px">
                      <div class="subSubTitle">رقم الطلب</div>
                      <div class="subMono"><?php echo htmlspecialchars($c['order_no'] ?? '—'); ?></div>
                    </div>
                  </td>
                  <td data-label="الفترة">
                    <div class="subSubTitle">بداية</div>
                    <div class="subMono nowrap"><?php echo htmlspecialchars($start ?: '—'); ?></div>
                    <div style="height:8px"></div>
                    <div class="subSubTitle">نهاية (فعلي)</div>
                    <div class="subMono nowrap"><?php echo htmlspecialchars($end ?: '—'); ?></div>
                  </td>
                  <td data-label="المتبقي">
                    <div class="subMeta">
                      <span class="pill <?php echo $daysPill; ?> nowrap"><i class="fa-regular fa-calendar"></i> <?php echo (int)$daysRem; ?> يوم</span>
                      <span class="pill <?php echo $mealsPill; ?> nowrap"><i class="fa-solid fa-bowl-food"></i> <?php echo (int)$mealsRem; ?> وجبة</span>
                    </div>
                  </td>
                  <td data-label="تحكم">
                    <a class="btn btnPrimary ctlBtn"
                       href="subscription_edit.php?id=<?php echo (int)$cid; ?>&q=<?php echo urlencode($q); ?>">
                      <i class="fa-solid fa-sliders"></i> إدارة
                    </a>
                  </td>
                </tr>
              <?php endforeach; ?>

              <?php if (!$clients): ?>
                <tr><td colspan="6" style="text-align:center;color:var(--admin-text-muted);padding:18px;font-weight:1000;">لا توجد نتائج</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>
      </div>

    </div>
    </main>
  </div>

</body>
</html>
