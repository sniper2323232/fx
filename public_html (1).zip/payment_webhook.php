<?php
// payment_webhook.php - Unified Payment Webhook Receiver (Secure + Crash-Proof + Multi-Gateway)
// ============================================================================================

header("Cache-Control: no-cache, no-store, must-revalidate");
header("Content-Type: text/plain; charset=utf-8");

ini_set('display_errors', 0);
ini_set('log_errors', 1);
ini_set('error_log', __DIR__ . '/payment_webhook_error.log');
error_reporting(E_ALL);

// Debug mode: ?debug=1
$DEBUG = (isset($_GET['debug']) && $_GET['debug'] === '1');
if ($DEBUG) {
    ini_set('display_errors', 1);
    ini_set('display_startup_errors', 1);
    register_shutdown_function(function () {
        $err = error_get_last();
        if ($err && in_array($err['type'], [E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR], true)) {
            header('Content-Type: text/plain; charset=utf-8');
            echo "FATAL ERROR\n";
            echo $err['message'] . "\n";
            echo "FILE: " . $err['file'] . "\n";
            echo "LINE: " . $err['line'] . "\n";
        }
    });
}

// -----------------------------------------------------------------------------
// Includes (must exist)
// -----------------------------------------------------------------------------
require_once 'db_connect.php';
require_once 'PaymentConfig.php';

// Optional (page must not crash if missing)
$WH_HAS_ENGINE = false;
if (file_exists(__DIR__ . '/PaymentEngine.php')) {
    require_once 'PaymentEngine.php';
    $WH_HAS_ENGINE = class_exists('PaymentEngine');
}

// -----------------------------------------------------------------------------
// Helpers (namespaced to avoid collisions)
// -----------------------------------------------------------------------------
function wh_log(string $msg): void { error_log("[payment_webhook] " . $msg); }

function wh_get_ip(): string {
    $ip = $_SERVER['REMOTE_ADDR'] ?? '';
    // if behind proxy and you trust it, adjust here
    return (string)$ip;
}

function wh_table_exists(PDO $pdo, string $t): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$t]);
        return (bool)$st->fetchColumn();
    } catch (Throwable $e) {
        return false;
    }
}

function wh_json_encode($v): string {
    $j = json_encode($v, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return $j === false ? '' : $j;
}


// HyperPay result-code mapping (conservative allowlist)
function wh_hyperpay_code_to_status(string $code, string $paymentType = ''): string {
    $code = trim($code);
    $pt   = strtoupper(trim($paymentType));
    if ($code === '') return 'pending';

    if (preg_match('/^000\.(200|300)\./', $code)) return 'pending';

    $isSuccess =
        preg_match('/^000\.000\./', $code) ||
        preg_match('/^000\.100\.(1|11|110|111|112|113|114|115|116|117|118|119|200|201|202)\./', $code);

    if ($isSuccess) {
        if ($pt === 'PA') return 'pending';
        return 'paid';
    }

    return 'failed';
}

function wh_read_body(): array {
    $raw = file_get_contents('php://input');
    $ct  = strtolower($_SERVER['CONTENT_TYPE'] ?? '');

    // JSON
    if (strpos($ct, 'application/json') !== false) {
        $data = json_decode($raw, true);
        if (is_array($data)) return [$raw, $data];
        return [$raw, []];
    }

    // x-www-form-urlencoded or unknown -> try parse
    $data = [];
    if ($raw !== '') {
        parse_str($raw, $data);
        if (!is_array($data)) $data = [];
    }

    // fallback: if PHP already parsed POST
    if (!$data && !empty($_POST) && is_array($_POST)) $data = $_POST;

    return [$raw, $data];
}


function wh_get_header(string $name): string {
    // Try common PHP server vars first (HTTP_*). Normalize name.
    $key = 'HTTP_' . strtoupper(str_replace('-', '_', $name));
    if (isset($_SERVER[$key])) return (string)$_SERVER[$key];

    // Fallback to getallheaders (if available)
    if (function_exists('getallheaders')) {
        $h = getallheaders();
        if (is_array($h)) {
            foreach ($h as $k => $v) {
                if (strcasecmp((string)$k, $name) === 0) return (string)$v;
            }
        }
    }
    return '';
}

/**
 * Extra gateway-level verification on top of URL token / IP allowlist.
 * - PayTabs: verify HMAC signature header (Signature) using server_key and raw body
 * - Moyasar: verify secret_token field matches configured webhook token (if set)
 */
function wh_verify_gateway_request(string $gateway, string $rawBody, array $payload): array {
    // returns [bool $ok, string $reason]
    $gateway = strtolower(trim($gateway));

    // PayTabs signature verification (callbacks/IPN): Signature header = HMAC-SHA256(raw body, serverKey)
    if ($gateway === 'paytabs') {
        $env = ps_getPaymentEnv();
        $serverKey = trim((string)pg_getSetting('paytabs', $env, 'server_key', ''));
        $sig = trim((string)wh_get_header('Signature'));
        if ($serverKey === '' || $sig === '') {
            return [false, 'PAYTABS_SIGNATURE_MISSING'];
        }
        $calc = hash_hmac('sha256', $rawBody, $serverKey);
        if (!hash_equals($calc, $sig)) {
            return [false, 'PAYTABS_SIGNATURE_INVALID'];
        }
        return [true, 'OK'];
    }

    // Moyasar: webhook object includes secret_token (set by you) - validate if webhook token is configured
    if ($gateway === 'moyasar') {
        $tokenRequired = ps_getSystemSetting('payment_webhook_token', '');
        if ($tokenRequired !== '') {
            $st = (string)($payload['secret_token'] ?? '');
            if ($st === '' || !hash_equals($tokenRequired, $st)) {
                return [false, 'MOYASAR_SECRET_TOKEN_INVALID'];
            }
        }
        return [true, 'OK'];
    }

    // HyperPay: no standardized signature in this codebase yet, rely on token + allowlist + server-to-server verification (if added)
    return [true, 'OK'];
}

function wh_extract_amount_currency(string $gateway, array $payload): array {
    // returns [float|null $amount, string|null $currency]
    $g = strtolower(trim($gateway));

    if ($g === 'moyasar') {
        $p = is_array($payload['data'] ?? null) ? $payload['data'] : $payload;
        $amountMinor = $p['amount'] ?? null; // usually in halalas
        $currency = $p['currency'] ?? null;
        if (is_numeric($amountMinor)) {
            return [((float)$amountMinor)/100.0, is_string($currency) ? strtoupper($currency) : null];
        }
    }

    if ($g === 'paytabs') {
        $amount = wh_pick($payload, ['cart_amount','tran_total','amount'], null);
        $currency = wh_pick($payload, ['cart_currency','currency'], null);
        if (is_numeric($amount)) {
            return [(float)$amount, is_string($currency) ? strtoupper((string)$currency) : null];
        }
    }

    if ($g === 'hyperpay') {
        $amount = wh_pick($payload, ['amount','payment.amount','order.amount'], null);
        $currency = wh_pick($payload, ['currency','payment.currency','order.currency'], null);
        if (is_numeric($amount)) {
            return [(float)$amount, is_string($currency) ? strtoupper((string)$currency) : null];
        }
    }

    return [null, null];
}

function wh_ip_allowlist_ok(string $ip, string $allowCsv): bool {
    $allowCsv = trim((string)$allowCsv);
    if ($allowCsv === '') return true; // not enforced
    $allowCsv = str_replace(' ', '', $allowCsv);
    $list = array_filter(explode(',', $allowCsv), fn($x) => $x !== '');
    // exact match (simple + safe). If you need CIDR later, we add it.
    return in_array($ip, $list, true);
}

function wh_pick(array $arr, array $keys, $default = null) {
    foreach ($keys as $k) {
        if (array_key_exists($k, $arr) && $arr[$k] !== '' && $arr[$k] !== null) return $arr[$k];
    }
    return $default;
}

function wh_find_txn_id(array $payload): int {
    // common patterns (you can extend anytime)
    $candidates = [
        $payload['txn_id'] ?? null,
        $payload['transaction_id'] ?? null,
        $payload['metadata']['txn_id'] ?? null,
        $payload['metadata']['txn'] ?? null,
        $payload['meta']['txn_id'] ?? null,
        $payload['meta']['txn'] ?? null,
        $payload['order']['metadata']['txn_id'] ?? null,
    ];

    foreach ($candidates as $c) {
        if (is_numeric($c)) return (int)$c;
        if (is_string($c) && preg_match('/^\d+$/', $c)) return (int)$c;
    }

    // Sometimes providers send "reference" like "TXN-123"
    $ref = (string)wh_pick($payload, ['reference','ref','merchant_reference','merchant_ref','order_reference','order_ref'], '');
    if ($ref && preg_match('/(\d+)/', $ref, $m)) return (int)$m[1];

    return 0;
}

function wh_map_status(string $gateway, array $payload): string {
    $g = strtolower(trim($gateway));

    // generic fields
    $s1 = strtolower((string)wh_pick($payload, ['status','payment_status','event','type','result','state'], ''));
    $s2 = strtolower((string)wh_pick($payload, ['transaction_status','transaction.state','data.status'], ''));

    $s = $s1 ?: $s2;

    // Common normalization
    $paidWords   = ['paid','succeeded','success','captured','approved','completed'];
    $failWords   = ['failed','fail','declined','rejected','error','void','canceled','cancelled','expired'];
    $pendWords   = ['pending','processing','in_progress','created','initiated','authorized','authorised'];

    foreach ($paidWords as $w)  if (strpos($s, $w) !== false) return 'paid';
    foreach ($failWords as $w)  if (strpos($s, $w) !== false) return (strpos($s, 'cancel') !== false ? 'canceled' : 'failed');
    foreach ($pendWords as $w)  if (strpos($s, $w) !== false) return (strpos($s, 'created') !== false ? 'created' : 'pending');

    // gateway specific hooks (placeholders you can expand)
    if ($g === 'paytabs') {
        // PayTabs often has: payment_result->response_status / response_message, tran_ref, tran_type
        $resp = strtolower((string)($payload['payment_result']['response_status'] ?? ''));
        if ($resp === 'a' || $resp === 'approved' || $resp === 'success') return 'paid';
        if ($resp === 'd' || $resp === 'declined') return 'failed';
    }

    
if ($g === 'hyperpay') {
        $code = (string)($payload['result']['code'] ?? '');
        $paymentType = (string)($payload['paymentType'] ?? '');
        if ($code !== '') {
            return wh_hyperpay_code_to_status($code, $paymentType);
        }
    }


    // default safest
    return 'pending';
}

// -----------------------------------------------------------------------------
// Security: Token + IP Allowlist
// -----------------------------------------------------------------------------
$tokenRequired = ps_getSystemSetting('payment_webhook_token', '');
$allowlistCsv  = ps_getSystemSetting('payment_webhook_ip_allowlist', '');

$reqToken = $_SERVER['HTTP_X_WEBHOOK_TOKEN'] ?? ($_GET['token'] ?? ($_POST['token'] ?? ''));
$gateway  = $_GET['gateway'] ?? ($_POST['gateway'] ?? ''); // expected: paytabs / hyperpay / moyasar / etc
$gateway  = strtolower(trim((string)$gateway));

$ip = wh_get_ip();

// token check (only if configured)
if ($tokenRequired !== '') {
    if (!$reqToken || !hash_equals($tokenRequired, (string)$reqToken)) {
        wh_log("BLOCKED: bad token | ip=$ip | gateway=$gateway");
        http_response_code(403);
        echo "FORBIDDEN\n";
        exit;
    }
}

// allowlist check (optional)
if (!wh_ip_allowlist_ok($ip, $allowlistCsv)) {
    wh_log("BLOCKED: ip not allowed | ip=$ip | gateway=$gateway");
    http_response_code(403);
    echo "FORBIDDEN\n";
    exit;
}

// -----------------------------------------------------------------------------
// Read payload
// -----------------------------------------------------------------------------
[$rawBody, $payload] = wh_read_body();
if (!is_array($payload)) $payload = [];
if ($gateway === '') {
    // try infer from payload if possible
    $gateway = strtolower((string)wh_pick($payload, ['gateway','provider','source'], ''));
}
// -----------------------------------------------------------------------------
// Gateway-level verification (signature / secret_token) - before trusting payload
// -----------------------------------------------------------------------------
[$sigOk, $sigReason] = wh_verify_gateway_request($gateway, (string)$rawBody, $payload);
if (!$sigOk) {
    wh_log("VERIFY_FAIL gateway=$gateway reason=$sigReason ip=" . wh_get_ip());
    http_response_code(403);
    echo "FORBIDDEN: " . $sigReason;
    exit;
}


if ($DEBUG) {
    wh_log("DEBUG incoming | ip=$ip | gateway=$gateway | ct=".($_SERVER['CONTENT_TYPE'] ?? ''));
}

// -----------------------------------------------------------------------------
// DB Checks
// -----------------------------------------------------------------------------
$needTables = ['payment_transactions','payment_events'];
foreach ($needTables as $t) {
    if (!wh_table_exists($pdo, $t)) {
        wh_log("MISSING TABLE: $t");
        http_response_code(500);
        echo "DB_NOT_READY\n";
        exit;
    }
}

// -----------------------------------------------------------------------------
// Find txn + decide env
// -----------------------------------------------------------------------------
$txnId = wh_find_txn_id($payload);

// env: from payload OR system default
$env = strtolower((string)wh_pick($payload, ['env','mode','test_mode'], ''));
$env = ($env === 'live' || $env === 'production') ? 'live' : (($env === 'test' || $env === 'sandbox') ? 'test' : ps_getSystemSetting('payment_env', 'test'));
if (!in_array($env, ['test','live'], true)) $env = 'test';

// provider_ref: keep for admin tracking
$providerRef = (string)wh_pick($payload, [
    'provider_ref','reference','ref','tran_ref','transaction_reference','transaction_id',
    'id','payment_id','checkout_id'
], '');

// decide status

// -----------------------------------------------------------------------------
// HyperPay: prefer server-to-server verification (resourcePath) before trusting webhook body
// -----------------------------------------------------------------------------
if (strtolower($gateway) === 'hyperpay' && $txnExists) {
    $resourcePath = (string)wh_pick($payload, ['resourcePath','resource_path','resourcepath','data.resourcePath'], '');
    if ($resourcePath !== '') {
        $baseUrl     = rtrim(pg_getSetting('hyperpay', $env, 'base_url', ''), '/');
        $entityId    = pg_getSetting('hyperpay', $env, 'entity_id', '');
        $accessToken = pg_getSetting('hyperpay', $env, 'access_token', '');

        if ($baseUrl !== '' && $entityId !== '' && $accessToken !== '') {
            $rp = ltrim($resourcePath, '/');
            $verifyUrl = $baseUrl . "/" . $rp . "?entityId=" . rawurlencode($entityId);

            $r = PaymentEngine::httpJson("GET", $verifyUrl, [
                "Authorization: Bearer ".$accessToken,
                "Accept: application/json",
            ]);

            $v = json_decode_safe($r['body'] ?? '') ?? ['raw'=>$r['body'] ?? null];

            if (empty($r['error']) && (int)($r['code'] ?? 0) < 400) {
                // Replace payload with verified response (stronger)
                $payload = $v;

                // Map status from verified result.code
                $rc = (string)($v['result']['code'] ?? '');
                $isPaid = (strpos($rc, '000.000.') === 0) || (strpos($rc, '000.100.') === 0);
                $isPending = (strpos($rc, '000.200.') === 0) || (strpos($rc, '000.300.') === 0);

                if ($isPaid) $payload['__verified_mapped_status'] = 'paid';
                elseif ($isPending) $payload['__verified_mapped_status'] = 'pending';
                else $payload['__verified_mapped_status'] = 'failed';

                // Provider reference is the payment id when available
                if (!empty($v['id'])) {
                    $payload['__provider_ref_override'] = (string)$v['id'];
                }
            } else {
                wh_log("HYPERPAY_VERIFY_FAIL txn=$txnId http=" . wh_json_encode($r));
            }
        } else {
            wh_log("HYPERPAY_VERIFY_SKIP missing_keys env=$env txn=$txnId");
        }
    }
}

$newStatus = wh_map_status($gateway, $payload);

if (isset($payload['__verified_mapped_status'])) {
    $newStatus = (string)$payload['__verified_mapped_status'];
}

if (isset($payload['__provider_ref_override']) && $payload['__provider_ref_override'] !== '') {
    $providerRef = (string)$payload['__provider_ref_override'];
}

// -----------------------------------------------------------------------------
// Store event (always)
// -----------------------------------------------------------------------------
try {
    $stE = $pdo->prepare("
        INSERT INTO payment_events (txn_id, gateway_code, env, event_type, payload, created_at)
        VALUES (?, ?, ?, ?, ?, NOW())
    ");
    $eventType = (string)wh_pick($payload, ['event','type','action'], 'webhook');
    $payloadJson = $rawBody !== '' ? $rawBody : wh_json_encode($payload);
    $stE->execute([(int)$txnId, $gateway ?: 'unknown', $env, $eventType ?: 'webhook', $payloadJson]);
} catch (Throwable $e) {
    wh_log("EVENT INSERT FAIL: ".$e->getMessage());
    // continue (do not break webhook)
}

// -----------------------------------------------------------------------------
// Update transaction if exists
// -----------------------------------------------------------------------------
$txnExists = false;
$txnRow = null;

if ($txnId > 0) {
    try {
        $st = $pdo->prepare("SELECT * FROM payment_transactions WHERE id=? LIMIT 1");
        $st->execute([(int)$txnId]);
        $txnRow = $st->fetch(PDO::FETCH_ASSOC) ?: null;
        $txnExists = (bool)$txnRow;
    } catch (Throwable $e) {
        wh_log("TXN SELECT FAIL: ".$e->getMessage());
    }
}

if ($txnExists) {
    try {
        // keep last payload snapshot in txn table (useful for admin)
        $stU = $pdo->prepare("
            UPDATE payment_transactions
            SET gateway_code = COALESCE(NULLIF(?, ''), gateway_code),
                env = COALESCE(NULLIF(?, ''), env),
                provider_ref = COALESCE(NULLIF(?, ''), provider_ref),
                provider_payload = ?,
                status = ?,
                updated_at = NOW()
            WHERE id = ?
            LIMIT 1
        ");
        $payloadJson = $rawBody !== '' ? $rawBody : wh_json_encode($payload);
        $stU->execute([
            $gateway ?: ($txnRow['gateway_code'] ?? ''),
            $env ?: ($txnRow['env'] ?? ''),
            $providerRef,
            $payloadJson,
            $newStatus,
            (int)$txnId
        ]);
    } catch (Throwable $e) {
        wh_log("TXN UPDATE FAIL: ".$e->getMessage());
    }

    // If paid and PaymentEngine exists => mark paid + (optionally) apply later in your PaymentApply flow
    if ($newStatus === 'paid' && $WH_HAS_ENGINE) {
        try {
            // We pass provider payload minimal
            
            // Amount/Currency safety check (prevents accepting a paid webhook for a different transaction)
            if (is_array($txnRow)) {
                $expAmt = isset($txnRow['amount']) ? (float)$txnRow['amount'] : null;
                $expCur = isset($txnRow['currency']) ? strtoupper((string)$txnRow['currency']) : null;
                [$gotAmt, $gotCur] = wh_extract_amount_currency($gateway, $payload);
                if ($expAmt !== null && $gotAmt !== null) {
                    // Allow tiny rounding differences
                    if (abs($expAmt - $gotAmt) > 0.01) {
                        wh_log("AMOUNT_MISMATCH txn=$txnId exp=$expAmt got=$gotAmt gateway=$gateway");
                        http_response_code(400);
                        echo "AMOUNT_MISMATCH";
                        exit;
                    }
                }
                if ($expCur !== null && $gotCur !== null) {
                    if ($expCur !== $gotCur) {
                        wh_log("CURRENCY_MISMATCH txn=$txnId exp=$expCur got=$gotCur gateway=$gateway");
                        http_response_code(400);
                        echo "CURRENCY_MISMATCH";
                        exit;
                    }
                }
            }

PaymentEngine::setTxnStatus((int)$txnId, 'paid', $providerRef, $payload);

            // Apply (idempotent) so webhook completes the business flow
            require_once __DIR__ . '/PaymentApply.php';
            try {
                $ap = PaymentApply::applyPaidTxn((int)$txnId);
                wh_log("APPLY_RESULT txn=$txnId | " . wh_json_encode($ap));
            } catch (Throwable $e) {
                wh_log("APPLY_FAIL txn=$txnId | " . $e->getMessage());
            }
        } catch (Throwable $e) {
            wh_log("ENGINE setTxnStatus FAIL: ".$e->getMessage());
        }
    }
}

// -----------------------------------------------------------------------------
// Response
// -----------------------------------------------------------------------------
http_response_code(200);

if ($DEBUG) {
    echo "OK\n";
    echo "gateway=$gateway\n";
    echo "env=$env\n";
    echo "txn_id=$txnId\n";
    echo "status=$newStatus\n";
    echo "provider_ref=$providerRef\n";
    echo "ip=$ip\n";
    echo "txn_exists=" . ($txnExists ? '1' : '0') . "\n";
} else {
    // Most providers accept any 200 text
    echo "OK";
}