<?php
// diagnose_notif.php - شامل تشخيص مشكلة الإشعارات
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connect.php';

$result = [
    'timestamp' => date('Y-m-d H:i:s'),
    'issues' => [],
    'data' => []
];

// ===== فحص 1: هل جدول notifications موجود؟ =====
try {
    $st = $pdo->prepare("SHOW TABLES LIKE 'notifications'");
    $st->execute();
    $exists = (bool)$st->fetchColumn();
    
    if (!$exists) {
        $result['issues'][] = '❌ جدول notifications غير موجود!';
    } else {
        $result['data']['notifications_table'] = '✅ موجود';
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في فحص الجدول: ' . $e->getMessage();
}

// ===== فحص 2: كم إشعار موجود؟ =====
try {
    $count = $pdo->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
    $result['data']['total_notifications'] = (int)$count;
    
    if ($count == 0) {
        $result['issues'][] = '⚠️ لا توجد إشعارات في قاعدة البيانات!';
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في عد الإشعارات: ' . $e->getMessage();
}

// ===== فحص 3: أعمدة الجدول =====
try {
    $st = $pdo->query("SHOW COLUMNS FROM notifications");
    $cols = [];
    while ($row = $st->fetch(PDO::FETCH_ASSOC)) {
        $cols[] = $row['Field'];
    }
    $result['data']['columns'] = $cols;
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في جلب الأعمدة: ' . $e->getMessage();
}

// ===== فحص 4: هل يوجد إشعارات بـ client_id محدد؟ =====
$testClientId = 1;
try {
    $st = $pdo->prepare("SELECT COUNT(*) FROM notifications WHERE client_id = ?");
    $st->execute([$testClientId]);
    $count = $st->fetchColumn();
    $result['data']['notifications_for_client_1'] = (int)$count;
    
    if ($count == 0) {
        $result['issues'][] = "⚠️ لا توجد إشعارات للعميل رقم 1";
    } else {
        // جلب تفاصيل الإشعارات
        $st = $pdo->prepare("SELECT id, title, message, link, created_at FROM notifications WHERE client_id = ? ORDER BY id DESC LIMIT 3");
        $st->execute([$testClientId]);
        $notifs = $st->fetchAll(PDO::FETCH_ASSOC);
        $result['data']['sample_notifications'] = $notifs;
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في البحث عن إشعارات: ' . $e->getMessage();
}

// ===== فحص 5: جدول user_notification_state =====
try {
    $st = $pdo->prepare("SHOW TABLES LIKE 'user_notification_state'");
    $st->execute();
    $exists = (bool)$st->fetchColumn();
    
    if ($exists) {
        $st = $pdo->prepare("SELECT COUNT(*) FROM user_notification_state WHERE user_id = ?");
        $st->execute([$testClientId]);
        $count = $st->fetchColumn();
        $result['data']['user_notification_state'] = [
            'table_exists' => true,
            'records_for_user_1' => (int)$count
        ];
    } else {
        $result['issues'][] = '⚠️ جدول user_notification_state غير موجود';
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في فحص user_notification_state: ' . $e->getMessage();
}

// ===== فحص 6: اختبر check_notif.php logic =====
if (session_status() === PHP_SESSION_NONE) session_start();
$_SESSION['user_id'] = $testClientId;

try {
    $last_seen = 0;
    $st = $pdo->prepare("SELECT last_seen_id FROM user_notification_state WHERE user_id=? LIMIT 1");
    $st->execute([$testClientId]);
    $last_seen = (int)($st->fetchColumn() ?: 0);
    
    $result['data']['check_notif_logic'] = [
        'user_id' => $testClientId,
        'last_seen_id' => $last_seen,
        'query_will_search_for' => "id > $last_seen"
    ];
    
    // محاولة جلب إشعار واحد
    $st = $pdo->prepare("
        SELECT id, title, message, image, link
        FROM notifications
        WHERE client_id = ? AND id > ?
        ORDER BY id ASC
        LIMIT 1
    ");
    $st->execute([$testClientId, $last_seen]);
    $n = $st->fetch(PDO::FETCH_ASSOC);
    
    if ($n) {
        $result['data']['check_notif_would_return'] = $n;
    } else {
        $result['issues'][] = "⚠️ check_notif.php سيعيد NULL - لا يوجد إشعارات جديدة";
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في محاكاة check_notif.php: ' . $e->getMessage();
}

// ===== فحص 7: هل notif_lib.php موجود؟ =====
if (file_exists(__DIR__ . '/notif_lib.php')) {
    $result['data']['notif_lib'] = '✅ موجود';
} else {
    $result['issues'][] = '❌ notif_lib.php غير موجود!';
}

// ===== فحص 8: اختبر إدراج إشعار جديد =====
try {
    require_once __DIR__ . '/notif_lib.php';
    
    $testTitle = 'اختبار تشخيصي';
    $testMsg = 'رسالة من diagnose_notif.php - ' . date('H:i:s');
    
    $success = notifyClient($pdo, $testClientId, $testTitle, $testMsg, 'diagnose_notif.php', 'test');
    
    if ($success) {
        $result['data']['test_insert'] = '✅ تم إدراج إشعار اختباري بنجاح';
        
        // جلب الإشعار الذي تم إدراجه
        $st = $pdo->prepare("SELECT * FROM notifications WHERE message LIKE ? ORDER BY id DESC LIMIT 1");
        $st->execute(['%diagnose_notif%']);
        $inserted = $st->fetch(PDO::FETCH_ASSOC);
        $result['data']['inserted_notification'] = $inserted;
    } else {
        $result['issues'][] = '❌ فشل إدراج الإشعار الاختباري';
    }
} catch (Exception $e) {
    $result['issues'][] = 'خطأ في اختبار الإدراج: ' . $e->getMessage();
}

// ===== ملخص النتائج =====
$result['summary'] = [
    'issues_found' => count($result['issues']),
    'status' => count($result['issues']) > 0 ? '❌ مشاكل مكتشفة' : '✅ لا توجد مشاكل'
];

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
