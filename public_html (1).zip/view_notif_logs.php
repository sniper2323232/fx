<?php
// view_notif_logs.php - عرض سجلات الإشعارات للتشخيص
header('Content-Type: text/html; charset=utf-8');

$logFile = __DIR__ . '/notif_lib.log';

?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <title>سجلات الإشعارات</title>
  <style>
    body { font-family: Tajawal, Arial; background: #f5f5f5; padding: 20px; }
    .container { max-width: 800px; margin: 0 auto; background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 8px rgba(0,0,0,0.1); }
    h1 { color: #333; border-bottom: 2px solid #007bff; padding-bottom: 10px; }
    .logs { background: #f9f9f9; border: 1px solid #ddd; border-radius: 5px; padding: 15px; font-family: monospace; font-size: 12px; max-height: 500px; overflow-y: auto; }
    .log-line { padding: 5px 0; border-bottom: 1px solid #eee; }
    .log-line.error { color: #d32f2f; }
    .log-line.success { color: #388e3c; }
    .log-line.info { color: #1976d2; }
    .btn { padding: 10px 20px; background: #007bff; color: white; border: none; border-radius: 5px; cursor: pointer; font-size: 14px; }
    .btn:hover { background: #0056b3; }
    .btn-danger { background: #d32f2f; }
    .btn-danger:hover { background: #b71c1c; }
    .status { margin: 15px 0; padding: 10px; border-radius: 5px; }
    .status.ok { background: #e8f5e9; color: #2e7d32; }
    .status.warning { background: #fff3e0; color: #e65100; }
    .status.error { background: #ffebee; color: #c62828; }
  </style>
</head>
<body>
  <div class="container">
    <h1>🔍 سجلات الإشعارات (notif_lib.log)</h1>
    
    <?php
    if (!file_exists($logFile)) {
        echo '<div class="status warning">⚠️ ملف السجل لم يُنشأ بعد - لم تحدث عمليات إشعارات بعد</div>';
    } else {
        $size = filesize($logFile);
        echo '<div class="status ok">✅ ملف السجل موجود - الحجم: ' . number_format($size) . ' بايت</div>';
        
        // عرض آخر 100 سطر
        $lines = file($logFile, FILE_IGNORE_NEW_LINES);
        $lines = array_reverse($lines);
        $lines = array_slice($lines, 0, 100);
        
        if (count($lines) > 0) {
            echo '<div class="logs">';
            foreach ($lines as $line) {
                $class = 'info';
                if (strpos($line, 'ERROR') !== false) $class = 'error';
                elseif (strpos($line, 'SUCCESS') !== false) $class = 'success';
                
                echo '<div class="log-line ' . $class . '">' . htmlspecialchars($line) . '</div>';
            }
            echo '</div>';
            echo '<p style="margin-top: 15px; color: #666; font-size: 12px;">آخر ' . count($lines) . ' سطر من السجل</p>';
        } else {
            echo '<div class="status warning">السجل فارغ</div>';
        }
    }
    ?>
    
    <br>
    <button class="btn" onclick="location.reload()">🔄 تحديث</button>
    <button class="btn btn-danger" onclick="clearLogs()">🗑️ مسح السجلات</button>
    
    <hr style="margin-top: 30px;">
    
    <h3>الخطوات المقترحة:</h3>
    <ol>
      <li>اختبر إدراج إشعار: <code>test_notif_insert.php?client_id=1</code></li>
      <li>تفقد السجلات هنا (<code>view_notif_logs.php</code>)</li>
      <li>اختبر الجلب: <code>test_notif_check.php?user_id=1</code></li>
      <li>شغّل التشخيص الشامل: <code>diagnose_notif.php</code></li>
    </ol>
  </div>
  
  <script>
    function clearLogs() {
      if (confirm('هل تريد مسح جميع السجلات؟')) {
        fetch('clear_notif_logs.php', { method: 'POST' }).then(() => {
          alert('تم مسح السجلات');
          location.reload();
        });
      }
    }
  </script>
</body>
</html>
<?php
?>
