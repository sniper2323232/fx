<?php
require_once __DIR__ . '/auth.php';
requireRole(["preparer", "admin"]);
?>
