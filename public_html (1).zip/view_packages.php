<?php
// view_packages.php - (تم الإصلاح: حفظ الوزن في العمود الصحيح allowed_weight)
// =============================================================

header('Content-Type: text/html; charset=utf-8');
require_once 'auth_admin.php'; 
require_once 'db_connect.php'; 

// Fetch Categories
$all_categories = $pdo->query("SELECT * FROM categories ORDER BY name")->fetchAll();

// Fetch Option Categories
$all_option_categories = [];
try {
    $checkTable = $pdo->query("SHOW TABLES LIKE 'option_categories'");
    if ($checkTable->rowCount() > 0) {
        $all_option_categories = $pdo->query("SELECT * FROM option_categories WHERE is_active=1 ORDER BY sort_order ASC, name ASC")->fetchAll();
    }
} catch (PDOException $e) {
    // جدول غير موجود
}

// Week Days
$week_days = [
    'Saturday'  => 'السبت', 'Sunday'    => 'الأحد', 'Monday'    => 'الاثنين',
    'Tuesday'   => 'الثلاثاء', 'Wednesday' => 'الأربعاء', 'Thursday'  => 'الخميس', 'Friday'    => 'الجمعة'
];

// --- 1. Add New Package Logic ---
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['add_package'])) {
    
    try {
        $pdo->beginTransaction();

        // Basic Data
        $name = trim($_POST['name']);
        $price = (float)$_POST['price'];
        $meals_per_day = (int)$_POST['meals_per_day'];
        $description = trim($_POST['description']);
        $duration_days = (int)$_POST['duration_days'];
        
        // Weight Constraint Logic (تصحيح هنا)
        $allowed_weight = 0; // القيمة الافتراضية للوزن المفتوح
        $weight_label = 'مفتوح';

        if (isset($_POST['weight_type']) && $_POST['weight_type'] == 'fixed') {
            // إذا كان وزناً ثابتاً، نحفظ الرقم في allowed_weight
            $allowed_weight = (float)$_POST['fixed_weight_value'];
            $weight_label = $allowed_weight . 'g';
        }

        // Off Days
        $off_days_str = "";
        if (isset($_POST['off_days']) && is_array($_POST['off_days'])) {
            $off_days_str = implode(',', $_POST['off_days']);
        }

        // 3.5 Max Options Logic
        $max_options_allowed = isset($_POST['max_options_allowed']) ? (int)$_POST['max_options_allowed'] : 1;

        // Image Upload Logic
        $image_url = 'uploads/packages/default.png'; 
        if (isset($_FILES['package_image']) && $_FILES['package_image']['error'] == 0) {
            $target_dir = "uploads/packages/";
            if (!is_dir($target_dir)) { mkdir($target_dir, 0755, true); }
            
            $file_ext = strtolower(pathinfo($_FILES['package_image']['name'], PATHINFO_EXTENSION));
            $filename = time() . "_" . uniqid() . "." . $file_ext;
            
            if (move_uploaded_file($_FILES['package_image']['tmp_name'], $target_dir . $filename)) {
                $image_url = $target_dir . $filename;
            }
        }
        
        // Insert Package (تم إضافة allowed_weight و max_options_allowed)
        // ملاحظة: تأكد أن عمود allowed_weight و max_options_allowed موجود في قاعدة البيانات
        $sql = "INSERT INTO packages (name, description, price, meals_per_day, allowed_weight, fixed_weight_label, duration_days, off_days, image_url, is_active, max_options_allowed) 
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, 1, ?)";
        $stmt = $pdo->prepare($sql);
        $stmt->execute([$name, $description, $price, $meals_per_day, $allowed_weight, $weight_label, $duration_days, $off_days_str, $image_url, $max_options_allowed]);
        $package_id = $pdo->lastInsertId();

        // Insert Category Limits
        if (isset($_POST['cat_limits']) && is_array($_POST['cat_limits'])) {
            $stmt_limit = $pdo->prepare("INSERT INTO package_category_limits (package_id, category_id, allowed_count) VALUES (?, ?, ?)");
            foreach ($_POST['cat_limits'] as $cat_id => $limit) {
                $limit = (int)$limit;
                if ($limit > 0) { 
                    $stmt_limit->execute([$package_id, $cat_id, $limit]);
                }
            }
        }

        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS package_allowed_categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                package_id INT NOT NULL,
                option_category_id INT NULL,
                category_id INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                KEY idx_pkg (package_id),
                KEY idx_opt_cat (option_category_id),
                KEY idx_cat (category_id),
                UNIQUE KEY uq_pkg_optcat (package_id, option_category_id),
                UNIQUE KEY uq_pkg_cat (package_id, category_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");

            $cols = packageAllowedCategoriesCols($pdo);
            $hasOpt = !empty($cols['has_option_category_id']);
            $hasCat = !empty($cols['has_category_id']);

            if (isset($_POST['allowed_option_cats']) && is_array($_POST['allowed_option_cats']) && ($hasOpt || $hasCat)) {
                if ($hasOpt && $hasCat) {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, option_category_id, category_id) VALUES (?, ?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$package_id, $cat_id, $cat_id]);
                    }
                } elseif ($hasOpt) {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, option_category_id) VALUES (?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$package_id, $cat_id]);
                    }
                } else {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, category_id) VALUES (?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$package_id, $cat_id]);
                    }
                }
            }
        } catch (Throwable $e) {}

        $pdo->commit();
        header("Location: view_packages.php?success=add");
        exit;

    } catch (PDOException $e) {
        $pdo->rollBack();
        die("<h3 style='color:red; text-align:center; margin-top:50px;'>System Error: " . $e->getMessage() . "</h3>");
    }
}

// --- 2. Delete Package ---
if (isset($_GET['delete_id'])) {
    $pid = (int)$_GET['delete_id'];
    $pdo->prepare("DELETE FROM package_category_limits WHERE package_id=?")->execute([$pid]);
    try { $pdo->prepare("DELETE FROM package_allowed_categories WHERE package_id=?")->execute([$pid]); } catch (Throwable $e) {}
    try {
        $checkTable = $pdo->query("SHOW TABLES LIKE 'package_option_category_limits'");
        if ($checkTable->rowCount() > 0) {
            $pdo->prepare("DELETE FROM package_option_category_limits WHERE package_id=?")->execute([$pid]);
        }
    } catch (PDOException $e) {
        // جدول غير موجود
    }
    $pdo->prepare("DELETE FROM packages WHERE id=?")->execute([$pid]);
    header("Location: view_packages.php?success=delete"); exit;
}

// --- 3. Fetch Packages ---
$packages = $pdo->query("SELECT * FROM packages ORDER BY id DESC")->fetchAll();

// Helper functions
function get_package_limits_html($pdo, $pkg_id) {
    $stmt = $pdo->prepare("SELECT c.name, l.allowed_count FROM package_category_limits l JOIN categories c ON l.category_id = c.id WHERE l.package_id = ?");
    $stmt->execute([$pkg_id]);
    $limits = $stmt->fetchAll();
    
    if (empty($limits)) return '<span class="limit-tag open">🌐 مفتوح للكل</span>';
    
    $html = '';
    foreach ($limits as $l) {
        $html .= '<span class="limit-tag">' . htmlspecialchars($l['name']) . ': <b>' . $l['allowed_count'] . '</b></span> ';
    }
    return $html;
}

function packageAllowedCategoriesCols(PDO $pdo): array {
    $hasTable = false;
    $hasOptionCategoryId = false;
    $hasCategoryId = false;
    try {
        $check = $pdo->query("SHOW TABLES LIKE 'package_allowed_categories'");
        $hasTable = ($check && $check->rowCount() > 0);
    } catch (Throwable $e) {
        $hasTable = false;
    }
    if ($hasTable) {
        try {
            $st = $pdo->query("SHOW COLUMNS FROM package_allowed_categories LIKE 'option_category_id'");
            $hasOptionCategoryId = ($st && $st->rowCount() > 0);
        } catch (Throwable $e) {
            $hasOptionCategoryId = false;
        }
        try {
            $st = $pdo->query("SHOW COLUMNS FROM package_allowed_categories LIKE 'category_id'");
            $hasCategoryId = ($st && $st->rowCount() > 0);
        } catch (Throwable $e) {
            $hasCategoryId = false;
        }
    }
    return [
        'has_table' => $hasTable,
        'has_option_category_id' => $hasOptionCategoryId,
        'has_category_id' => $hasCategoryId,
    ];
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <title>إدارة الباقات الذكية</title>
    <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
    <link rel="stylesheet" href="admin_colors.php?v=20260113">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
</head>
<body>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <header class="top-bar">
            <div class="user-info">📦 إدارة الباقات والاشتراكات</div>
            <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> خروج</a>
        </header>

        <main class="content-wrapper">
            <?php if (isset($_GET['success'])): ?>
                <div class="alert-message alert-success" style="margin-bottom:20px; padding:15px; background:#d4edda; color:#155724; border-radius:10px; display:flex; align-items:center; gap:10px;">
                    <i class="fas fa-check-circle" style="font-size:1.2rem;"></i> تم تنفيذ العملية بنجاح!
                </div>
            <?php endif; ?>

            <div class="form-card">
                <div class="section-title"><i class="fas fa-magic"></i> تصميم باقة جديدة</div>
                
                <form method="POST" enctype="multipart/form-data">
                    
                    <div style="display: grid; grid-template-columns: 2fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <div>
                            <label>اسم الباقة المميز</label>
                            <input type="text" name="name" class="form-control" required placeholder="مثال: باقة التنشيف الاحترافية">
                        </div>
                        <div>
                            <label>السعر (ر.س)</label>
                            <input type="number" step="0.01" name="price" class="form-control" required style="font-weight:bold; color:#27ae60;">
                        </div>
                    </div>

                    <div style="display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 20px;">
                        <div>
                            <label>مدة الاشتراك (يوم)</label>
                            <input type="number" name="duration_days" value="28" class="form-control" required>
                        </div>
                        <div>
                            <label>عدد الوجبات يومياً</label>
                            <select name="meals_per_day" class="form-control" required>
                                <option value="1">وجبة واحدة</option>
                                <option value="2">وجبتين</option>
                                <option value="3">3 وجبات</option>
                                <option value="4">4 وجبات</option>
                                <option value="5">5 وجبات</option>
                            </select>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label>نظام الوزن (Allowed Weight)</label>
                        <div class="weight-options">
                            <label class="w-option active" onclick="setWeightType('open', this)">
                                <input type="radio" name="weight_type" value="open" checked>
                                <i class="fas fa-balance-scale"></i>
                                <div>وزن مفتوح</div>
                                <small style="color:#888">العميل يختار الوزن بنفسه</small>
                            </label>
                            <label class="w-option" onclick="setWeightType('fixed', this)">
                                <input type="radio" name="weight_type" value="fixed">
                                <i class="fas fa-lock"></i>
                                <div>وزن ثابت</div>
                                <small style="color:#888">إجبار العميل على وزن محدد</small>
                            </label>
                        </div>
                        <div id="fixedWeightInput" style="display:none; margin-top:10px; animation:fadeIn 0.3s;">
                            <input type="number" name="fixed_weight_value" class="form-control" placeholder="أدخل الوزن (مثال: 150)" style="width:200px;">
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label>تخصيص الوجبات (Category Limits)</label>
                        <div class="cat-builder">
                            <div class="cat-input-group">
                                <select id="catSelect" class="cat-select">
                                    <option value="">-- اختر التصنيف --</option>
                                    <?php foreach($all_categories as $cat): ?>
                                        <option value="<?php echo $cat['id']; ?>"><?php echo htmlspecialchars($cat['name']); ?></option>
                                    <?php endforeach; ?>
                                </select>
                                <input type="number" id="catCount" class="cat-count" placeholder="العدد" min="1">
                                <button type="button" onclick="addCategoryLimit()" class="btn-add-cat"><i class="fas fa-plus"></i> إضافة</button>
                            </div>
                            
                            <div id="limitsContainer" class="added-limits">
                                <span style="color:#999; font-size:0.9rem;" id="emptyMsg">لم يتم تحديد قيود (الباقة مفتوحة لكل التصنيفات)</span>
                            </div>
                        </div>
                    </div>

                    <div class="form-card" style="margin-bottom: 25px; border-left: 5px solid #9b59b6;">
                        <label style="font-size:1.1rem; color:#2d3436;"><i class="fas fa-cubes" style="color:#9b59b6; margin-left:5px;"></i> إعدادات خيارات الوجبات (نظام الحصص)</label>
                        <small style="color:#666; font-size:0.9rem; margin-bottom:15px; display:block; line-height:1.5;">
                            <i class="fas fa-info-circle"></i> هنا تحدد القواعد العامة للخيارات (Options) التي تظهر مع الوجبات.<br>
                            1. <b>الحد الأقصى:</b> هو مجموع ما يمكن للعميل اختياره من كل التصنيفات مجتمعة للوجبة الواحدة.<br>
                            2. <b>التصنيفات المسموحة:</b> حدد فقط التصنيفات التي تريد أن تظهر للعميل في هذه الباقة.
                        </small>
                        
                        <div style="background:#f8f9fa; padding:20px; border-radius:15px; border:1px dashed #ced6e0;">
                            <!-- Global Limit Input -->
                            <div style="margin-bottom: 20px; background:white; padding:15px; border-radius:10px; border:1px solid #eee;">
                                <label style="font-weight:bold; color:#2d3436; margin-bottom:5px; display:block;">الحد الأقصى للخيارات المسموحة (للوجبة الواحدة):</label>
                                <div style="display:flex; align-items:center; gap:10px;">
                                    <input type="number" name="max_options_allowed" class="form-control" value="1" min="0" style="width:120px; font-weight:bold; text-align:center; font-size:1.2rem;">
                                    <span style="color:#888;">خيار</span>
                                </div>
                                <small style="color:#666; display:block; margin-top:5px;">مثال: إذا وضعت <b>2</b>، يمكن للعميل اختيار (2 كارب) أو (1 كارب + 1 سلطة) أو (2 سلطة) وهكذا من التصنيفات الظاهرة أدناه.</small>
                            </div>

                            <!-- Allowed Categories Checkboxes -->
                            <label style="font-weight:bold; color:#2d3436; margin-bottom:10px; display:block;">التصنيفات المسموح بظهورها لهذه الباقة:</label>
                            
                            <div style="display: grid; grid-template-columns: repeat(auto-fill, minmax(200px, 1fr)); gap: 10px;">
                                <?php if(empty($all_option_categories)): ?>
                                    <p style="color:#e74c3c;">لا توجد تصنيفات خيارات مضافة في النظام. يرجى إضافتها من صفحة "إدارة الخيارات".</p>
                                <?php else: ?>
                                    <?php foreach($all_option_categories as $optCat): ?>
                                        <label style="background:white; padding:10px; border-radius:8px; border:1px solid #ddd; display:flex; align-items:center; cursor:pointer; transition:0.2s;" onmouseover="this.style.borderColor='#9b59b6'" onmouseout="this.style.borderColor='#ddd'">
                                            <input type="checkbox" name="allowed_option_cats[]" value="<?php echo $optCat['id']; ?>" checked style="width:18px; height:18px; accent-color:#9b59b6; margin-left:10px;">
                                            <span style="font-weight:500;"><?php echo htmlspecialchars($optCat['name']); ?></span>
                                        </label>
                                    <?php endforeach; ?>
                                <?php endif; ?>
                            </div>
                        </div>
                    </div>

                    <div class="form-group" style="margin-bottom: 25px;">
                        <label>أيام التوقف (إجازة أسبوعية)</label>
                        <div class="days-grid">
                            <?php foreach($week_days as $en => $ar): ?>
                                <label>
                                    <input type="checkbox" name="off_days[]" value="<?php echo $en; ?>" class="day-check">
                                    <span class="day-label"><?php echo $ar; ?></span>
                                </label>
                            <?php endforeach; ?>
                        </div>
                    </div>

                    <div style="margin-bottom: 20px;">
                        <label>صورة الباقة</label>
                        <input type="file" name="package_image" class="form-control" accept="image/*">
                    </div>
                    
                    <div style="margin-bottom: 20px;">
                        <label>وصف تسويقي</label>
                        <textarea name="description" class="form-control" rows="3" placeholder="اكتب وصفاً جذاباً للباقة..."></textarea>
                    </div>

                    <button type="submit" name="add_package" class="btn-submit">
                        <i class="fas fa-check-circle"></i> حفظ وإطلاق الباقة
                    </button>
                </form>
            </div>

            <div class="form-card">
                <div class="section-title"><i class="fas fa-list-alt"></i> الباقات النشطة</div>
                <table class="data-table">
                    <thead>
                        <tr>
                            <th>الصورة</th><th>الباقة</th><th>الوزن (Allowed)</th><th>توزيع الوجبات</th><th>السعر</th><th>تحكم</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach($packages as $pkg): ?>
                        <tr>
                            <td><img src="<?php echo !empty($pkg['image_url']) ? htmlspecialchars($pkg['image_url']) : 'uploads/packages/default.png'; ?>" class="meal-image"></td>
                            <td>
                                <strong><?php echo htmlspecialchars($pkg['name']); ?></strong><br>
                                <span style="font-size:0.8rem; color:#777;"><?php echo $pkg['duration_days']; ?> يوم</span>
                            </td>
                            <td>
                                <?php if(isset($pkg['allowed_weight']) && $pkg['allowed_weight'] > 0): ?>
                                    <span class="badge badge-fixed"><i class="fas fa-lock"></i> <?php echo $pkg['allowed_weight']; ?>g</span>
                                <?php else: ?>
                                    <span class="badge badge-open">مفتوح</span>
                                <?php endif; ?>
                            </td>
                            <td><?php echo $pkg['meals_per_day']; ?> وجبات/يوم</td>
                            <td><strong style="color:#27ae60; font-size:1.1rem;"><?php echo number_format($pkg['price'], 2); ?></strong></td>
                            <td class="action-buttons">
                                <a href="edit_package.php?id=<?php echo $pkg['id']; ?>" class="action-btn btn-edit"><i class="fas fa-edit"></i></a>
                                <a href="view_packages.php?delete_id=<?php echo $pkg['id']; ?>" class="action-btn btn-delete" onclick="return confirm('تأكيد الحذف؟')"><i class="fas fa-trash"></i></a>
                            </td>
                        </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </main>
    </div>
    
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script>
        function setWeightType(type, element) {
            $('.w-option').removeClass('active');
            $(element).addClass('active');
            if (type === 'fixed') {
                $('#fixedWeightInput').slideDown();
            } else {
                $('#fixedWeightInput').slideUp();
            }
        }

        function addCategoryLimit() {
            let catId = $('#catSelect').val();
            let catName = $('#catSelect option:selected').text();
            let count = $('#catCount').val();

            if (!catId || !count || count <= 0) {
                alert('الرجاء اختيار تصنيف وتحديد عدد صحيح.');
                return;
            }

            if ($(`#limit_row_${catId}`).length > 0) {
                alert('هذا التصنيف مضاف مسبقاً، احذفه لإضافته مجدداً.');
                return;
            }

            $('#emptyMsg').hide();

            let html = `
                <div class="limit-chip" id="limit_row_${catId}">
                    <span>${catName}: <b>${count} وجبات</b></span>
                    <input type="hidden" name="cat_limits[${catId}]" value="${count}">
                    <i class="fas fa-times-circle" onclick="removeLimit(${catId})"></i>
                </div>
            `;
            $('#limitsContainer').append(html);
            
            $('#catSelect').val('');
            $('#catCount').val('');
        }

        function removeLimit(id) {
            $(`#limit_row_${id}`).remove();
            if ($('#limitsContainer').children().length <= 1) { 
                $('#emptyMsg').show();
            }
        }

        function addOptionCategoryLimit() {
            let catId = $('#optCatSelect').val();
            let catName = $('#optCatSelect option:selected').text();
            let count = $('#optCatCount').val();

            if (!catId || !count || count <= 0) {
                alert('الرجاء اختيار تصنيف خيارات وتحديد عدد صحيح.');
                return;
            }

            if ($(`#optcat_limit_row_${catId}`).length > 0) {
                alert('هذا التصنيف مضاف مسبقاً، احذفه لإضافته مجدداً.');
                return;
            }

            $('#optCatEmptyMsg').hide();

            let html = `
                <div class="limit-chip" id="optcat_limit_row_${catId}">
                    <span>${catName}: <b>${count} خيار</b></span>
                    <input type="hidden" name="optcat_limits[${catId}]" value="${count}">
                    <i class="fas fa-times-circle" onclick="removeOptionCatLimit(${catId})" style="color:#e74c3c; cursor:pointer;"></i>
                </div>
            `;
            $('#optCatLimitsContainer').append(html);
            $('#optCatSelect').val('');
            $('#optCatCount').val('1');
        }

        function removeOptionCatLimit(id) {
            $(`#optcat_limit_row_${id}`).remove();
            if ($('#optCatLimitsContainer').children().length === 0 || $('#optCatLimitsContainer').children().length === 1) { 
                $('#optCatEmptyMsg').show();
            }
        }
    </script>
</body>
</html>
