<?php
header("Cache-Control: no-cache, no-store, must-revalidate");
header('Content-Type: text/html; charset=utf-8');

require_once 'db_connect.php';
require_once 'csrf.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$client_id = (int)$_SESSION['user_id'];
$txn_id = isset($_GET['txn']) ? (int)$_GET['txn'] : 0;
if ($txn_id <= 0) { http_response_code(400); die("Invalid transaction"); }

$stmt = $pdo->prepare("SELECT * FROM subscription_transactions WHERE id=? AND client_id=? LIMIT 1");
$stmt->execute([$txn_id, $client_id]);
$sub_txn = $stmt->fetch(PDO::FETCH_ASSOC);
if (!$sub_txn) { http_response_code(404); die("Transaction not found"); }

$pkg_id = (int)($sub_txn['package_id'] ?? 0);
$pkg = null;
if ($pkg_id > 0) {
    $stmtP = $pdo->prepare("SELECT id, name, duration_days FROM packages WHERE id=? LIMIT 1");
    $stmtP->execute([$pkg_id]);
    $pkg = $stmtP->fetch(PDO::FETCH_ASSOC);
}

$status = strtolower((string)($sub_txn['status'] ?? ''));
$error_msg = '';
$success_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['set_start_date'])) {
    if (!verifyCSRFToken()) {
        $error_msg = "رمز الأمان غير صحيح. حاول مرة أخرى.";
    } elseif ($status !== 'paid') {
        $error_msg = "لا يمكن تفعيل الاشتراك قبل اكتمال الدفع.";
    } elseif (!$pkg) {
        $error_msg = "تعذر العثور على بيانات الباقة.";
    } else {
        $start_date_str = trim((string)($_POST['start_date'] ?? ''));
        if ($start_date_str === '') {
            $error_msg = "يرجى اختيار تاريخ بداية الاشتراك.";
        } else {
            try {
                $start_dt = new DateTime($start_date_str);
                $today = new DateTime();
                $today->setTime(0, 0, 0);
                if ($start_dt < $today) {
                    throw new Exception("تاريخ البداية لا يمكن أن يكون في الماضي.");
                }

                $duration = (int)($pkg['duration_days'] ?? 0);
                if ($duration <= 0) $duration = 30;
                $end_dt = clone $start_dt;
                $end_dt->modify("+{$duration} days");

                $start_fmt = $start_dt->format('Y-m-d');
                $end_fmt = $end_dt->format('Y-m-d');

                // Ensure client_details row exists
                $stmt_check = $pdo->prepare("SELECT id FROM client_details WHERE user_id=? LIMIT 1");
                $stmt_check->execute([$client_id]);
                if (!$stmt_check->fetchColumn()) {
                    $pdo->prepare("INSERT INTO client_details (user_id) VALUES (?)")->execute([$client_id]);
                }

                $pdo->beginTransaction();
                $pdo->prepare("
                    UPDATE client_details
                    SET package_id=?,
                        subscription_start_date=?,
                        subscription_end_date=?,
                        subscription_status='active'
                    WHERE user_id=?
                ")->execute([$pkg_id, $start_fmt, $end_fmt, $client_id]);

                $pdo->prepare("UPDATE subscription_transactions SET status='active' WHERE id=? LIMIT 1")->execute([$txn_id]);
                $pdo->commit();

                $success_msg = "تم تفعيل الاشتراك بنجاح.";
                header("refresh:2;url=client_dashboard.php");
            } catch (Exception $e) {
                if ($pdo->inTransaction()) $pdo->rollBack();
                $error_msg = $e->getMessage();
            }
        }
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0">
  <title>اختيار تاريخ بداية الاشتراك</title>
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
  <style>
    body{margin:0;font-family:'Tajawal',sans-serif;background:#f7f8ff;color:#111827;padding:20px}
    .card{max-width:520px;margin:0 auto;background:#fff;border-radius:18px;border:1px solid #e5e7eb;box-shadow:0 10px 25px rgba(0,0,0,.06);padding:18px}
    .h{font-size:1.1rem;font-weight:900;margin:0 0 10px}
    .muted{color:#6b7280;font-weight:800;font-size:.9rem;line-height:1.6}
    .alert{padding:12px;border-radius:12px;margin-top:10px;font-weight:800}
    .alert.err{background:#fee;border:1px solid #fcc;color:#c0392b}
    .alert.ok{background:#e7f7ee;border:1px solid #b7ebc6;color:#166534}
    .input{width:100%;padding:12px;border:2px solid #eee;border-radius:12px;font-size:1rem;font-family:inherit;margin-top:8px}
    .btn{width:100%;margin-top:12px;padding:14px;border:none;border-radius:14px;background:#6c5ce7;color:#fff;font-weight:900;font-size:1rem;cursor:pointer}
    .btn:disabled{opacity:.6;cursor:not-allowed}
  </style>
</head>
<body>
  <div class="card">
    <div class="h">اختيار تاريخ بداية الاشتراك</div>
    <div class="muted">
      الباقة: <b><?php echo htmlspecialchars($pkg['name'] ?? '—'); ?></b><br>
      الحالة: <b><?php echo htmlspecialchars($status ?: 'pending'); ?></b>
    </div>

    <?php if ($error_msg): ?>
      <div class="alert err"><?php echo htmlspecialchars($error_msg); ?></div>
    <?php endif; ?>
    <?php if ($success_msg): ?>
      <div class="alert ok"><?php echo htmlspecialchars($success_msg); ?></div>
    <?php endif; ?>

    <form method="POST">
      <?php echo csrfField(); ?>
      <input type="hidden" name="set_start_date" value="1">

      <label class="muted" style="display:block;margin-top:12px;">تاريخ بداية الاشتراك</label>
      <input class="input" type="date" name="start_date" required min="<?php echo date('Y-m-d'); ?>" <?php echo ($status !== 'paid') ? 'disabled' : ''; ?>>

      <button class="btn" type="submit" <?php echo ($status !== 'paid') ? 'disabled' : ''; ?>>
        تفعيل الاشتراك
      </button>
    </form>
  </div>
</body>
</html>
