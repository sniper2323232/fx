<?php
require_once 'db_connect.php';

try {
    echo "Checking database schema...\n";

    // 1. Create package_allowed_categories table if not exists
    $sql = "CREATE TABLE IF NOT EXISTS `package_allowed_categories` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `package_id` int(11) NOT NULL,
        `category_id` int(11) NOT NULL,
        PRIMARY KEY (`id`),
        KEY `package_id` (`package_id`),
        KEY `category_id` (`category_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    $pdo->exec($sql);
    echo "Table 'package_allowed_categories' checked/created.\n";

    // 2. Add max_options_allowed to packages if not exists
    $stmt = $pdo->query("SHOW COLUMNS FROM packages LIKE 'max_options_allowed'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE packages ADD COLUMN `max_options_allowed` int(11) NOT NULL DEFAULT 1 COMMENT 'عدد الخيارات المسموح للعميل اختيارها للوجبة الواحدة'");
        echo "Column 'max_options_allowed' added to 'packages'.\n";
    } else {
        echo "Column 'max_options_allowed' already exists in 'packages'.\n";
    }

    echo "Database schema update completed successfully.\n";

} catch (PDOException $e) {
    die("Error updating database: " . $e->getMessage() . "\n");
}
?>
