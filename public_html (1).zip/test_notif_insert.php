<?php
// test_notif_insert.php - Quick test to verify notification insertion works
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connect.php';
require_once __DIR__ . '/notif_lib.php';

$clientId = (int)($_GET['client_id'] ?? 1);
if ($clientId <= 0) $clientId = 1;

// Test 1: Check if notifications table exists
$tableExists = notif_table_exists($pdo);
if (!$tableExists) {
    echo json_encode(['ok'=>false, 'error'=>'notifications table does not exist'], JSON_UNESCAPED_UNICODE);
    exit;
}

// Test 2: Get columns
$cols = notif_get_columns($pdo);
echo json_encode([
    'ok' => true,
    'table_exists' => $tableExists,
    'columns' => $cols,
    'client_id' => $clientId
], JSON_UNESCAPED_UNICODE);

// Test 3: Try inserting a test notification
if (notifyClient($pdo, $clientId, 'اختبار', 'هذا إشعار اختبار من test_notif_insert.php', 'test_notif_insert.php', 'test')) {
    echo json_encode([
        'ok' => true,
        'message' => 'اختبار الإدراج نجح ✅',
        'client_id' => $clientId
    ], JSON_UNESCAPED_UNICODE);
} else {
    echo json_encode([
        'ok' => false,
        'message' => 'فشل إدراج الإشعار'
    ], JSON_UNESCAPED_UNICODE);
}
?>
