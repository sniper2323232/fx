<?php
// test_notif_check.php - Test fetching notifications from check_notif endpoint
header('Content-Type: application/json; charset=utf-8');

// Mock session for testing
if (session_status() === PHP_SESSION_NONE) session_start();

// Set a test user ID if not already set
if (!isset($_SESSION['user_id'])) {
    $_SESSION['user_id'] = (int)($_GET['user_id'] ?? 1);
}

$userId = $_SESSION['user_id'];

require_once 'db_connect.php';
require_once __DIR__ . '/notif_lib.php';

// Check what notifications exist for this user
$cols = notif_get_columns($pdo);

// Try to fetch last notification using similar logic to check_notif.php
$userIdMapped = null;
$userIdCol = null;

// Find which column maps to user_id
foreach (['user_id', 'client_id', 'customer_id', 'uid'] as $col) {
    if (in_array($col, $cols, true)) {
        $userIdCol = $col;
        break;
    }
}

if (!$userIdCol) {
    echo json_encode([
        'ok' => false,
        'error' => 'No user_id-like column found in notifications table',
        'columns' => $cols,
        'user_id' => $userId
    ], JSON_UNESCAPED_UNICODE);
    exit;
}

// Fetch notifications
try {
    $sql = "SELECT id, title, message, image, link, created_at FROM notifications WHERE $userIdCol = ? ORDER BY id DESC LIMIT 5";
    $st = $pdo->prepare($sql);
    $st->execute([$userId]);
    $rows = $st->fetchAll(PDO::FETCH_ASSOC);
    
    echo json_encode([
        'ok' => true,
        'user_id' => $userId,
        'user_id_column' => $userIdCol,
        'total_columns' => count($cols),
        'columns' => $cols,
        'notifications_found' => count($rows),
        'latest_notifications' => array_slice($rows, 0, 3)
    ], JSON_UNESCAPED_UNICODE);
} catch (Exception $e) {
    echo json_encode([
        'ok' => false,
        'error' => $e->getMessage(),
        'user_id' => $userId
    ], JSON_UNESCAPED_UNICODE);
}
?>
