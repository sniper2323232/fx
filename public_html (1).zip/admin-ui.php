<?php
// admin-ui.php?v=5 - Unified Admin Styles (dynamic colors)
header('Content-Type: text/css; charset=utf-8');

if (!isset($pdo)) {
    require_once __DIR__ . '/db_connect.php';
}

$defaults = [
    'admin_color_primary' => '#d97706',
    'admin_color_primary_dark' => '#b45309',
    'admin_color_primary_light' => '#f59e0b',
    'admin_color_accent' => '#dc2626',
    'admin_color_success' => '#16a34a',
    'admin_color_warning' => '#eab308',
];

$colors = $defaults;
try {
    $stmt = $pdo->query("SELECT setting_key, setting_value FROM system_settings WHERE setting_key LIKE 'admin_color_%'");
    $rows = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);
    foreach ($defaults as $key => $val) {
        if (!empty($rows[$key])) $colors[$key] = $rows[$key];
    }
} catch (Exception $e) {
    $colors = $defaults;
}
?>
@import url('https://fonts.googleapis.com/css2?family=Cairo:wght@400;600;700;800;900&display=swap');
@import url('https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css');

:root {
    --brand: <?php echo htmlspecialchars($colors['admin_color_primary'], ENT_QUOTES, 'UTF-8'); ?>;
    --brand-strong: <?php echo htmlspecialchars($colors['admin_color_primary_dark'], ENT_QUOTES, 'UTF-8'); ?>;
    --brand-soft: <?php echo htmlspecialchars($colors['admin_color_primary_light'], ENT_QUOTES, 'UTF-8'); ?>;
    --accent: <?php echo htmlspecialchars($colors['admin_color_accent'], ENT_QUOTES, 'UTF-8'); ?>;
    --success: <?php echo htmlspecialchars($colors['admin_color_success'], ENT_QUOTES, 'UTF-8'); ?>;
    --warning: <?php echo htmlspecialchars($colors['admin_color_warning'], ENT_QUOTES, 'UTF-8'); ?>;

    --bg: #f6f7fb;
    --bg-2: #eef1f7;
    --surface: #ffffff;
    --surface-2: #f9fafb;
    --text: #0f172a;
    --text-soft: #64748b;
    --muted: #94a3b8;
    --border: rgba(15, 23, 42, 0.08);
    --shadow: 0 16px 45px rgba(15, 23, 42, 0.08);
    --shadow-soft: 0 8px 24px rgba(15, 23, 42, 0.06);
    --radius-lg: 22px;
    --radius-md: 16px;
    --radius-sm: 12px;
    --gradient: linear-gradient(135deg, var(--brand-strong) 0%, var(--brand) 40%, var(--brand-soft) 100%);
    --sidebar-width: 280px;
    --primary: var(--brand);
    --warn: var(--warning);
    --muted: var(--muted);
}

* {
    box-sizing: border-box;
    -webkit-tap-highlight-color: transparent;
}

body {
    margin: 0;
    padding: 0;
    font-family: 'Cairo', 'Tahoma', sans-serif;
    background: var(--bg);
    color: var(--text);
    direction: rtl;
    line-height: 1.7;
}

h1, h2, h3, h4, h5 {
    margin: 0 0 8px 0;
    line-height: 1.4;
}

body::before {
    content: "";
    position: fixed;
    inset: 0;
    background:
        radial-gradient(900px 500px at 5% 0%, rgba(0,0,0,0.03), transparent 60%),
        radial-gradient(700px 500px at 95% 10%, rgba(0,0,0,0.03), transparent 60%),
        linear-gradient(180deg, rgba(0,0,0,0.02), transparent 40%);
    pointer-events: none;
    z-index: 0;
}

.sidebar {
    position: fixed;
    top: 0;
    right: 0;
    width: var(--sidebar-width);
    height: 100vh;
    background: var(--gradient);
    color: #fff;
    padding: 22px 18px;
    box-shadow: -8px 0 35px rgba(0,0,0,0.18);
    overflow-y: auto;
    z-index: 10;
}

.sidebar .sidebar {
    position: static;
    width: 100%;
    height: auto;
    background: transparent;
    box-shadow: none;
    padding: 0;
}

.sidebar::-webkit-scrollbar { width: 6px; }
.sidebar::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.25); border-radius: 999px; }

.sidebar-header {
    display: flex;
    align-items: center;
    gap: 14px;
    padding: 16px;
    border-radius: 18px;
    background: rgba(255,255,255,0.12);
    box-shadow: inset 0 0 0 1px rgba(255,255,255,0.12);
    margin-bottom: 18px;
}

.sidebar-header img {
    width: 52px;
    height: 52px;
    border-radius: 14px;
    object-fit: contain;
    background: rgba(255,255,255,0.2);
    padding: 8px;
}

.logo-fallback {
    width: 52px;
    height: 52px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    background: rgba(255,255,255,0.2);
    font-size: 1.4rem;
}

.sidebar-header .brand-title {
    font-weight: 900;
    font-size: 1.05rem;
    line-height: 1.3;
}

.sidebar-header .brand-subtitle {
    font-size: 0.78rem;
    color: rgba(255,255,255,0.8);
    font-weight: 700;
}

.sidebar-nav a,
.sidebar a {
    display: flex;
    align-items: center;
    gap: 12px;
    padding: 12px 14px;
    margin: 6px 0;
    border-radius: 14px;
    color: rgba(255,255,255,0.9);
    text-decoration: none;
    font-weight: 700;
    transition: all .2s ease;
}

.sidebar-nav a i,
.sidebar a i {
    width: 22px;
    text-align: center;
    font-size: 1.1rem;
}

.sidebar-nav a:hover,
.sidebar a:hover {
    background: rgba(255,255,255,0.16);
    transform: translateX(-4px);
}

.sidebar-nav a.active,
.sidebar a.active {
    background: rgba(255,255,255,0.25);
    box-shadow: 0 6px 18px rgba(0,0,0,0.18);
}

.sidebar-nav hr,
.sidebar hr {
    border: 0;
    height: 1px;
    background: rgba(255,255,255,0.2);
    margin: 12px 0;
}

.sidebar-nav li { list-style: none; }

.main-content,
.admin-main-content {
    margin-right: calc(var(--sidebar-width) + 20px);
    padding: 24px 28px 40px;
    position: relative;
    z-index: 1;
    width: calc(100% - var(--sidebar-width) - 20px);
}

.top-bar {
    display: flex;
    justify-content: space-between;
    align-items: center;
    background: var(--surface);
    border: 1px solid var(--border);
    padding: 16px 20px;
    border-radius: var(--radius-md);
    box-shadow: var(--shadow-soft);
    margin-bottom: 22px;
    gap: 12px;
    flex-wrap: wrap;
}

.top-bar .user-info {
    font-weight: 900;
    color: var(--text);
    flex: 1;
}

.top-bar a,
.top-bar button {
    white-space: nowrap;
}

.logout-link {
    color: var(--text);
    text-decoration: none;
    font-weight: 800;
    padding: 8px 12px;
    border-radius: 10px;
    border: 1px solid var(--border);
    background: var(--surface-2);
}

.content-wrapper,
.wrap {
    background: transparent;
    max-width: 1220px;
    margin: 0 auto;
    width: 100%;
}

.wrap {
    padding: 24px;
}

.pageHead {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 22px 24px;
    box-shadow: var(--shadow-soft);
    margin-bottom: 18px;
    text-align: right;
}

.titleBox h1 {
    font-size: 1.25rem;
    font-weight: 900;
}

.titleBox p {
    margin: 0;
    color: var(--text-soft);
    font-weight: 800;
    font-size: 0.95rem;
}

.statsRow {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 14px;
    margin-bottom: 18px;
    margin-top: 12px;
    align-items: stretch;
}

.statCard {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 18px;
    padding: 14px 16px;
    display: flex;
    gap: 12px;
    align-items: center;
    box-shadow: var(--shadow-soft);
    min-height: 78px;
}

.statIcon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    background: rgba(0,0,0,0.05);
    color: var(--brand);
}

.statInfo b {
    display: block;
    font-size: 1.2rem;
    font-weight: 900;
}

.statInfo small {
    color: var(--text-soft);
    font-weight: 800;
}

.searchForm {
    display: flex;
    flex-wrap: wrap;
    gap: 10px;
    align-items: center;
}

.searchForm .inp {
    width: 100%;
    padding: 12px 14px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-family: inherit;
    min-height: 46px;
    flex: 1 1 320px;
}

.searchForm .btn,
.searchForm .btnPrimary,
.searchForm .btnGhost {
    min-height: 46px;
    min-width: 110px;
    flex: 0 0 auto;
}

.btn,
.btnPrimary,
.btnGhost,
.btnOutline {
    border-radius: 12px;
    padding: 10px 16px;
    font-weight: 900;
}

.btnPrimary {
    background: var(--gradient);
    color: #fff;
    border: 1px solid transparent;
}

.btnGhost {
    background: var(--surface);
    color: var(--text);
    border: 1px solid var(--border);
}

.tableWrap {
    width: 100%;
    overflow-x: auto;
    border-radius: 16px;
}

.tableWrap table {
    min-width: 920px;
}

.form-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
    gap: 14px;
}

.campaign-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
    gap: 16px;
    margin-top: 12px;
}

.campaign-card {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 16px;
    padding: 16px;
    box-shadow: var(--shadow-soft);
}

.status-badge {
    padding: 6px 10px;
    border-radius: 999px;
    font-size: 0.8rem;
    font-weight: 900;
    border: 1px solid var(--border);
}

.status-badge.active { background: #ecfdf3; color: #166534; border-color: #bbf7d0; }
.status-badge.inactive { background: #fef2f2; color: #991b1b; border-color: #fecaca; }

.split {
    display: grid;
    grid-template-columns: 1.3fr 1fr;
    gap: 16px;
}

.preview-card {
    background: var(--surface-2);
    border: 1px dashed var(--border);
    border-radius: 16px;
    padding: 16px;
}

.chip {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    border-radius: 999px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-weight: 800;
    font-size: 0.8rem;
    color: var(--text-soft);
    cursor: pointer;
    text-decoration: none;
}

.chip:hover { border-color: var(--brand); color: var(--brand); }

.stat-mini {
    display: flex;
    align-items: center;
    gap: 10px;
    padding: 12px 14px;
    border-radius: 14px;
    background: var(--surface);
    border: 1px solid var(--border);
}

.stat-mini b { font-size: 1.05rem; }

@media (max-width: 960px) {
    .split { grid-template-columns: 1fr; }
}

@media (max-width: 860px) {
    .searchForm {
        grid-template-columns: 1fr;
    }
}
.topHead {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    padding: 18px 22px;
    box-shadow: var(--shadow-soft);
    margin-bottom: 18px;
    flex-wrap: wrap;
}

.topHead .title {
    font-weight: 900;
    font-size: 1.1rem;
}

.rowMini {
    display: flex;
    flex-wrap: wrap;
    gap: 8px;
}

.pill {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 6px 10px;
    border-radius: 999px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-weight: 800;
    font-size: 0.85rem;
    color: var(--text-soft);
}

.pill.ok { background: #ecfdf3; color: #166534; border-color: #bbf7d0; }
.pill.warn { background: #fffbeb; color: #92400e; border-color: #fde68a; }
.pill.bad { background: #fef2f2; color: #991b1b; border-color: #fecaca; }
.pill.muted { color: var(--text-soft); }

.kpiGrid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
    gap: 12px;
    margin-top: 12px;
}

.kpi {
    background: var(--surface-2);
    border: 1px solid var(--border);
    border-radius: 14px;
    padding: 12px;
    text-align: center;
}

.kpi small { color: var(--text-soft); font-weight: 800; display: block; }
.kpi b { font-size: 1.2rem; display: block; margin-top: 4px; }

.grid { display: grid; gap: 14px; }
.grid.g2 { grid-template-columns: repeat(auto-fit, minmax(260px, 1fr)); }
.grid.g3 { grid-template-columns: repeat(auto-fit, minmax(220px, 1fr)); }

.control {
    width: 100%;
    padding: 12px 14px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-family: inherit;
    font-size: 0.95rem;
}

.note {
    margin-top: 12px;
    padding: 12px 16px;
    border-radius: 12px;
    background: #f8fafc;
    border: 1px dashed var(--border);
    color: var(--text-soft);
    font-weight: 800;
    line-height: 1.7;
}

.flashErr,
.flashOk {
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 800;
    margin-bottom: 16px;
}
.flashErr { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.flashOk { background: #ecfdf3; color: #166534; border: 1px solid #bbf7d0; }

.admin-header,
.page-header {
    display: flex;
    justify-content: space-between;
    align-items: center;
    gap: 16px;
    padding: 18px 22px;
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow-soft);
    margin-bottom: 22px;
    flex-wrap: wrap;
}

.admin-header h1,
.page-header h1,
.page-title {
    margin: 0;
    font-size: 1.3rem;
    font-weight: 900;
}

.page-header .header-left,
.admin-header .header-left {
    display: flex;
    align-items: center;
    gap: 12px;
    flex-wrap: wrap;
}

.page-header .header-actions,
.admin-header .header-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
}

.form-card,
.admin-card,
.section-card,
.card,
.panel {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: var(--radius-lg);
    box-shadow: var(--shadow);
    padding: 20px;
    margin-bottom: 20px;
    width: 100%;
}

.section-title,
.card-header,
.admin-card-header {
    display: flex;
    align-items: center;
    gap: 10px;
    font-weight: 900;
    font-size: 1.05rem;
    margin-bottom: 16px;
}

.form-group { margin-bottom: 14px; }

label { display: block; font-weight: 800; margin-bottom: 8px; color: var(--text); }

.form-control,
input[type="text"],
input[type="email"],
input[type="password"],
input[type="number"],
input[type="time"],
input[type="date"],
input[type="file"],
select,
textarea {
    width: 100%;
    padding: 12px 14px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    font-family: inherit;
    font-size: 0.95rem;
    outline: none;
    transition: border-color .2s ease, box-shadow .2s ease;
}

input:focus,
select:focus,
textarea:focus {
    border-color: var(--brand);
    box-shadow: 0 0 0 3px rgba(15, 23, 42, 0.08);
}

.btn,
.admin-btn {
    display: inline-flex;
    align-items: center;
    gap: 8px;
    padding: 10px 16px;
    border-radius: 12px;
    border: 1px solid transparent;
    background: var(--gradient);
    color: #fff;
    text-decoration: none;
    font-weight: 900;
    cursor: pointer;
    transition: transform .2s ease, box-shadow .2s ease;
}

.btn-outline,
.admin-btn-secondary {
    background: var(--surface);
    color: var(--text);
    border: 1px solid var(--border);
}

.btn-icon,
.btn-back {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 8px;
    padding: 10px 14px;
    border-radius: 12px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    color: var(--text);
    text-decoration: none;
    font-weight: 800;
}

.btn:hover,
.admin-btn:hover { transform: translateY(-2px); box-shadow: 0 12px 24px rgba(0,0,0,0.15); }

.btn-success { background: var(--success); }
.btn-danger { background: var(--accent); }
.btn-warning { background: var(--warning); color: #1f2937; }

.action-buttons {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-wrap: wrap;
    white-space: nowrap;
}

.btn-edit,
.btn-delete {
    display: inline-flex;
    align-items: center;
    gap: 6px;
    padding: 8px 12px;
    border-radius: 10px;
    border: 1px solid var(--border);
    background: var(--surface-2);
    color: var(--text);
    font-weight: 800;
    font-size: 0.9rem;
}

.btn-edit:hover { border-color: var(--brand); color: var(--brand); }
.btn-delete:hover { border-color: var(--accent); color: var(--accent); }

.alert-message {
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 800;
    margin-bottom: 16px;
}
.alert-success { background: #ecfdf3; color: #166534; border: 1px solid #bbf7d0; }
.alert-error { background: #fef2f2; color: #991b1b; border: 1px solid #fecaca; }
.alert-warning { background: #fffbeb; color: #92400e; border: 1px solid #fde68a; }

.success-box {
    background: #ecfdf3;
    color: #166534;
    border: 1px solid #bbf7d0;
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 800;
    margin-bottom: 16px;
}

.moved-box {
    background: #fff7ed;
    color: #9a3412;
    border: 1px solid #fed7aa;
    padding: 12px 16px;
    border-radius: 12px;
    font-weight: 800;
    margin-bottom: 16px;
    line-height: 1.7;
}

.hint-box {
    margin-top: 12px;
    padding: 12px 16px;
    border-radius: 12px;
    background: #f8fafc;
    border: 1px dashed var(--border);
    color: var(--text-soft);
    font-weight: 800;
    line-height: 1.7;
}

.data-table,
.admin-table,
table {
    width: 100%;
    border-collapse: collapse;
    background: var(--surface);
    border-radius: 16px;
    overflow: hidden;
}

.data-table,
.admin-table {
    display: block;
    overflow-x: auto;
}

.data-table th,
.data-table td,
.admin-table th,
.admin-table td,
table th,
table td {
    padding: 12px 14px;
    border-bottom: 1px solid var(--border);
    text-align: right;
    font-weight: 700;
}

table thead th {
    background: var(--surface-2);
    color: var(--text);
    font-weight: 900;
}

.dashboard-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
    gap: 16px;
}

.stat-box {
    background: var(--surface);
    border: 1px solid var(--border);
    border-radius: 18px;
    padding: 16px;
    box-shadow: var(--shadow-soft);
    display: flex;
    gap: 14px;
    align-items: center;
}

.stat-icon {
    width: 46px;
    height: 46px;
    border-radius: 14px;
    display: grid;
    place-items: center;
    background: rgba(0,0,0,0.05);
    color: var(--brand);
}

.stat-info h3 {
    margin: 0;
    font-size: 0.9rem;
    color: var(--text-soft);
    font-weight: 800;
}

.stat-info .number {
    font-size: 1.4rem;
    font-weight: 900;
    margin-top: 4px;
}

.admin-grid,
.settings-grid {
    display: grid;
    grid-template-columns: repeat(auto-fit, minmax(280px, 1fr));
    gap: 18px;
}

.switch-wrap {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 12px;
    padding: 14px;
    border-radius: 14px;
    border: 1px solid var(--border);
    background: var(--surface-2);
}

.switch {
    position: relative;
    width: 54px;
    height: 30px;
    display: inline-block;
}
.switch input { display: none; }
.slider {
    position: absolute;
    inset: 0;
    background: #cbd5e1;
    border-radius: 999px;
    transition: .2s ease;
}
.slider:before {
    content: "";
    position: absolute;
    width: 24px;
    height: 24px;
    top: 3px;
    left: 3px;
    border-radius: 50%;
    background: #fff;
    transition: .2s ease;
    box-shadow: 0 6px 12px rgba(0,0,0,0.15);
}
.switch input:checked + .slider { background: var(--brand); }
.switch input:checked + .slider:before { transform: translateX(24px); }

.logo-preview {
    width: 100%;
    height: 120px;
    border-radius: 14px;
    border: 1px dashed var(--border);
    display: grid;
    place-items: center;
    background: var(--surface-2);
    overflow: hidden;
}
.logo-preview img { max-width: 100%; max-height: 100%; object-fit: contain; }
.logo-preview span { color: var(--text-soft); font-weight: 800; }

@media (max-width: 1024px) {
    :root { --sidebar-width: 250px; }
    .main-content, .admin-main-content { margin-right: calc(var(--sidebar-width) + 16px); padding: 20px; }
}

@media (max-width: 860px) {
    .sidebar { position: static; width: 100%; height: auto; }
    .main-content, .admin-main-content { margin-right: 0; }
    .top-bar { gap: 8px; }
    .tableWrap table { min-width: 720px; }
}




