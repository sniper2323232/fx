<?php
// check_db_keys.php - Check and verify database keys and indexes
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connect.php';

$result = [
    'ok' => true,
    'checks' => [],
    'needed_fixes' => []
];

// Check 1: notifications table primary key
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Key_name = 'PRIMARY'");
    $pk = $st->fetch(PDO::FETCH_ASSOC);
    if ($pk) {
        $result['checks'][] = ['name' => 'notifications PRIMARY KEY', 'status' => '✅ موجود', 'column' => $pk['Column_name']];
    } else {
        $result['checks'][] = ['name' => 'notifications PRIMARY KEY', 'status' => '❌ غير موجود'];
        $result['needed_fixes'][] = 'ALTER TABLE `notifications` ADD PRIMARY KEY (`id`);';
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'notifications PRIMARY KEY', 'status' => '⚠️ خطأ: ' . $e->getMessage()];
}

// Check 2: notifications AUTO_INCREMENT
try {
    $st = $pdo->query("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notifications'");
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if ($row && $row['AUTO_INCREMENT']) {
        $result['checks'][] = ['name' => 'notifications AUTO_INCREMENT', 'status' => '✅ موجود', 'value' => $row['AUTO_INCREMENT']];
    } else {
        $result['checks'][] = ['name' => 'notifications AUTO_INCREMENT', 'status' => '❌ غير موجود'];
        $result['needed_fixes'][] = 'ALTER TABLE `notifications` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;';
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'notifications AUTO_INCREMENT', 'status' => '⚠️ خطأ'];
}

// Check 3: user_notification_state primary key
try {
    $st = $pdo->query("SHOW KEYS FROM user_notification_state WHERE Key_name = 'PRIMARY'");
    $pk = $st->fetch(PDO::FETCH_ASSOC);
    if ($pk) {
        $result['checks'][] = ['name' => 'user_notification_state PRIMARY KEY', 'status' => '✅ موجود', 'column' => $pk['Column_name']];
    } else {
        $result['checks'][] = ['name' => 'user_notification_state PRIMARY KEY', 'status' => '❌ غير موجود'];
        $result['needed_fixes'][] = 'ALTER TABLE `user_notification_state` ADD PRIMARY KEY (`user_id`);';
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'user_notification_state PRIMARY KEY', 'status' => '⚠️ خطأ'];
}

// Check 4: Index on notifications.client_id
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Column_name = 'client_id'");
    $idx = $st->fetch(PDO::FETCH_ASSOC);
    if ($idx) {
        $result['checks'][] = ['name' => 'notifications.client_id INDEX', 'status' => '✅ موجود', 'type' => $idx['Key_name']];
    } else {
        $result['checks'][] = ['name' => 'notifications.client_id INDEX', 'status' => '⚠️ لا توجد فهرسة'];
        $result['needed_fixes'][] = 'ALTER TABLE `notifications` ADD INDEX idx_client_id (client_id);';
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'notifications.client_id INDEX', 'status' => '⚠️ خطأ'];
}

// Check 5: Index on notifications.created_at
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Column_name = 'created_at'");
    $idx = $st->fetch(PDO::FETCH_ASSOC);
    if ($idx) {
        $result['checks'][] = ['name' => 'notifications.created_at INDEX', 'status' => '✅ موجود'];
    } else {
        $result['checks'][] = ['name' => 'notifications.created_at INDEX', 'status' => '⚠️ لا توجد فهرسة'];
        $result['needed_fixes'][] = 'ALTER TABLE `notifications` ADD INDEX idx_created_at (created_at);';
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'notifications.created_at INDEX', 'status' => '⚠️ خطأ'];
}

// Check 6: Index on user_notification_state.user_id (already PRIMARY, but check)
try {
    $st = $pdo->query("SHOW KEYS FROM user_notification_state WHERE Column_name = 'user_id'");
    $idx = $st->fetch(PDO::FETCH_ASSOC);
    if ($idx) {
        $result['checks'][] = ['name' => 'user_notification_state.user_id INDEX', 'status' => '✅ موجود'];
    }
} catch (Exception $e) {
    $result['checks'][] = ['name' => 'user_notification_state.user_id INDEX', 'status' => '⚠️ خطأ'];
}

// Check 7: Table row counts
try {
    $notif_count = $pdo->query("SELECT COUNT(*) FROM notifications")->fetchColumn();
    $state_count = $pdo->query("SELECT COUNT(*) FROM user_notification_state")->fetchColumn();
    
    $result['counts'] = [
        'notifications' => (int)$notif_count,
        'user_notification_state' => (int)$state_count
    ];
} catch (Exception $e) {
    $result['counts'] = ['error' => $e->getMessage()];
}

// Determine if fixes are needed
if (count($result['needed_fixes']) > 0) {
    $result['ok'] = false;
    $result['action_required'] = 'نعم - تطبيق الأوامر أدناه مطلوب';
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
