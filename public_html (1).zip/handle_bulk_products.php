<?php
require_once 'auth_admin.php';
require_once 'db_connect.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST' && !empty($_POST['ids'])) {
    
    $action = $_POST['bulk_action'];
    $value = (float)$_POST['bulk_value'];
    $ids_placeholders = implode(',', array_fill(0, count($_POST['ids']), '?'));
    $ids = $_POST['ids'];

    try {
        $pdo->beginTransaction();

        if ($action == 'update_price') {
            // تغيير السعر لقيمة ثابتة
            $sql = "UPDATE products SET price = ? WHERE id IN ($ids_placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$value], $ids));

        } elseif ($action == 'increase_price_percent') {
            // زيادة السعر بنسبة مئوية
            $sql = "UPDATE products SET price = price + (price * ? / 100) WHERE id IN ($ids_placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$value], $ids));

        } elseif ($action == 'decrease_price_percent') {
            // عمل خصم (تحديث سعر العرض)
            // العرض = السعر الأصلي - النسبة
            $sql = "UPDATE products SET offer_price = price - (price * ? / 100) WHERE id IN ($ids_placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$value], $ids));

        } elseif ($action == 'update_weight') {
            // تغيير الوزن
            $sql = "UPDATE products SET weight = ? WHERE id IN ($ids_placeholders)";
            $stmt = $pdo->prepare($sql);
            $stmt->execute(array_merge([$value], $ids));

        } elseif ($action == 'delete') {
            $deleted = 0;
            $archived = 0;
            foreach ($ids as $id) {
                $id = (int)$id;
                if ($id <= 0) continue;
                $hasOrders = 0;
                try {
                    $st = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
                    $st->execute([$id]);
                    $hasOrders = (int)$st->fetchColumn();
                } catch (Exception $e) {
                    $hasOrders = 0;
                }

                if ($hasOrders > 0) {
                    $pdo->prepare("UPDATE products SET is_active=0 WHERE id=?")->execute([$id]);
                    $archived++;
                } else {
                    $pdo->prepare("DELETE FROM products WHERE id=?")->execute([$id]);
                    $deleted++;
                }
            }
        }

        $pdo->commit();
        if ($action === 'delete') {
            header("Location: manage_products.php?status=bulk&deleted={$deleted}&archived={$archived}");
        } else {
            header("Location: manage_products.php?success=1");
        }
        exit;

    } catch (Exception $e) {
        $pdo->rollBack();
        die("خطأ: " . $e->getMessage());
    }
}

header("Location: manage_products.php");
?>
