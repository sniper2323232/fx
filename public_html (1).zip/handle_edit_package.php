<?php
// handle_edit_package.php
// Backend Processor for Editing Packages (With Allowed Weight Fix)
// =============================================================

require_once 'auth_admin.php'; 
require_once 'db_connect.php'; 

// Check if request is POST and form was submitted
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['update_package'])) {

    // Global Error Handling
    try {
        // Validate ID
        if (!isset($_POST['id']) || empty($_POST['id'])) {
            throw new Exception("Missing Package ID");
        }

        $id = (int)$_POST['id'];

        // --- Schema Verification (Fix for Missing Columns) ---
        // Function to check if column exists
        function checkAndAddColumn($pdo, $table, $column, $definition) {
            try {
                $stmt = $pdo->query("SHOW COLUMNS FROM `$table` LIKE '$column'");
                if ($stmt->rowCount() == 0) {
                    $pdo->exec("ALTER TABLE `$table` ADD COLUMN `$column` $definition");
                }
            } catch (Exception $e) {
                // Ignore schema errors, proceed to try update
            }
        }

        // Ensure columns exist
        checkAndAddColumn($pdo, 'packages', 'allowed_weight', "DECIMAL(10,2) DEFAULT 0");
        checkAndAddColumn($pdo, 'packages', 'fixed_weight_label', "VARCHAR(50) DEFAULT NULL");
        checkAndAddColumn($pdo, 'packages', 'max_options_allowed', "INT DEFAULT 1");

        // --- Schema Verification (Table Creation) ---
        // Create table IF NOT EXISTS before transaction to avoid implicit commit
        try {
            $pdo->exec("CREATE TABLE IF NOT EXISTS package_allowed_categories (
                id INT AUTO_INCREMENT PRIMARY KEY,
                package_id INT NOT NULL,
                option_category_id INT NULL,
                category_id INT NULL,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
                KEY idx_pkg (package_id),
                KEY idx_opt_cat (option_category_id),
                KEY idx_cat (category_id),
                UNIQUE KEY uq_pkg_optcat (package_id, option_category_id),
                UNIQUE KEY uq_pkg_cat (package_id, category_id)
            ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4");
        } catch (Exception $e) {
            // Ignore table creation errors
        }

        // Start Transaction
        $pdo->beginTransaction();

        // 1. Collect Basic Data
        $name = trim($_POST['name']);
        $price = (float)$_POST['price'];
        $meals_per_day = (int)$_POST['meals_per_day'];
        $description = trim($_POST['description']);
        $duration_days = (int)$_POST['duration_days'];
        
        // Checkbox handling (is_active)
        $is_active = isset($_POST['is_active']) ? 1 : 0;

        // 2. Weight Constraint Logic [FIXED HERE]
        $allowed_weight = 0; // Default open weight
        $fixed_weight_label = NULL;

        // Check if weight type is set to fixed
        if (isset($_POST['weight_type']) && $_POST['weight_type'] == 'fixed') {
            $val = (float)$_POST['fixed_weight_value'];
            if ($val > 0) {
                $allowed_weight = $val;          // Save number (e.g., 150)
                $fixed_weight_label = $val . 'g'; // Save text (e.g., 150g)
            }
        }

        // 3. Off Days Logic
        $off_days_str = "";
        if (isset($_POST['off_days']) && is_array($_POST['off_days'])) {
            $off_days_str = implode(',', $_POST['off_days']);
        }
        
        // 3.5 Max Options Logic
        $max_options_allowed = isset($_POST['max_options_allowed']) ? (int)$_POST['max_options_allowed'] : 1;

        // 4. Image Upload Logic
        $image_sql_part = ""; 
        $params = [
            $name, 
            $description, 
            $price, 
            $meals_per_day, 
            $allowed_weight,      // New Numeric Field
            $fixed_weight_label,  // Text Label
            $duration_days, 
            $off_days_str, 
            $is_active,
            $max_options_allowed
        ];

        // Check if a new image is uploaded
        if (isset($_FILES['package_image']) && $_FILES['package_image']['error'] == 0) {
            $target_dir = "uploads/packages/";
            // Create directory if not exists
            if (!is_dir($target_dir)) { mkdir($target_dir, 0755, true); }
            
            $file_ext = strtolower(pathinfo($_FILES['package_image']['name'], PATHINFO_EXTENSION));
            $filename = time() . "_" . uniqid() . "." . $file_ext; // Unique filename
            
            if (move_uploaded_file($_FILES['package_image']['tmp_name'], $target_dir . $filename)) {
                $image_sql_part = ", image_url = ?";
                $params[] = $target_dir . $filename;
            }
        }
        
        // Add ID at the end for WHERE clause
        $params[] = $id;

        // 5. Update Packages Table
        $sql = "UPDATE packages SET 
                name=?, 
                description=?, 
                price=?, 
                meals_per_day=?, 
                allowed_weight=?,      -- Updated Column
                fixed_weight_label=?, 
                duration_days=?, 
                off_days=?, 
                is_active=?,
                max_options_allowed=?
                $image_sql_part 
                WHERE id=?";
        
        $stmt = $pdo->prepare($sql);
        $stmt->execute($params);

        // 6. Update Category Limits (Delete Old -> Insert New)
        $pdo->prepare("DELETE FROM package_category_limits WHERE package_id = ?")->execute([$id]);

        if (isset($_POST['cat_limits']) && is_array($_POST['cat_limits'])) {
            $stmt_limit = $pdo->prepare("INSERT INTO package_category_limits (package_id, category_id, allowed_count) VALUES (?, ?, ?)");
            
            foreach ($_POST['cat_limits'] as $cat_id => $limit) {
                $limit = (int)$limit;
                if ($limit > 0) { 
                    $stmt_limit->execute([$id, $cat_id, $limit]);
                }
            }
        }

        // 7. Update Allowed Option Categories (New Logic)
        try {
            // Delete old allowed categories
            $pdo->prepare("DELETE FROM package_allowed_categories WHERE package_id = ?")->execute([$id]);

            $hasOpt = false;
            $hasCat = false;
            try { $hasOpt = ($pdo->query("SHOW COLUMNS FROM package_allowed_categories LIKE 'option_category_id'")->rowCount() > 0); } catch (Throwable $e) { $hasOpt = false; }
            try { $hasCat = ($pdo->query("SHOW COLUMNS FROM package_allowed_categories LIKE 'category_id'")->rowCount() > 0); } catch (Throwable $e) { $hasCat = false; }

            if (isset($_POST['allowed_option_cats']) && is_array($_POST['allowed_option_cats']) && ($hasOpt || $hasCat)) {
                if ($hasOpt && $hasCat) {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, option_category_id, category_id) VALUES (?, ?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$id, $cat_id, $cat_id]);
                    }
                } elseif ($hasOpt) {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, option_category_id) VALUES (?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$id, $cat_id]);
                    }
                } else {
                    $stmt_allowed = $pdo->prepare("INSERT INTO package_allowed_categories (package_id, category_id) VALUES (?, ?)");
                    foreach ($_POST['allowed_option_cats'] as $cat_id) {
                        $cat_id = (int)$cat_id;
                        $stmt_allowed->execute([$id, $cat_id]);
                    }
                }
            }
        } catch (PDOException $e) {
            // Ignore if table doesn't exist yet
        }

        // Commit Transaction
        $pdo->commit();
        
        // Redirect with Success Message
        header("Location: edit_package.php?id=$id&success=update");
        exit;

    } catch (Throwable $e) {
        // Rollback on Error
        if ($pdo->inTransaction()) {
            $pdo->rollBack();
        }
        
        // Redirect back to Edit page with Error
        // Ensure ID is available, otherwise redirect to view
        if (isset($id) && $id > 0) {
            header("Location: edit_package.php?id=$id&error=" . urlencode($e->getMessage()));
        } else {
            header("Location: view_packages.php?error=" . urlencode($e->getMessage()));
        }
        exit;
    }
} else {
    // Direct Access Prevention
    header("Location: view_packages.php");
    exit;
}
