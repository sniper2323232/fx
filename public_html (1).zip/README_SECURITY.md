# دليل الأمان - Security Guide

## ✅ التحسينات الأمنية المطبقة

### 1. ملف الإعدادات الآمن (config.php)
- تم إنشاء ملف `config.php` لقراءة البيانات من ملف `.env`
- بيانات الاتصال بقاعدة البيانات لم تعد مكشوفة في الكود
- **ملاحظة:** يجب إنشاء ملف `.env` يدوياً ووضعه في `.gitignore`

### 2. نظام CSRF Protection
- تم إنشاء ملف `csrf.php` مع دوال كاملة لحماية CSRF
- استخدام: `<?php echo csrfField(); ?>` في النماذج
- التحقق: `verifyCSRFToken()` في المعالجات

### 3. تحسين Session Security
- تفعيل `session.cookie_httponly`
- تفعيل `session.use_strict_mode`
- تفعيل `session.cookie_secure` في HTTPS
- تفعيل `session.cookie_samesite = Strict`

### 4. إصلاح صلاحيات الملفات
- تغيير صلاحيات المجلدات من `0777` إلى `0755`
- تطبيق على: `handle_marketing.php`, `handle_product.php`, `handle_settings.php`

### 5. تحسين معالجة الأخطاء
- إزالة عرض الأخطاء في بيئة الإنتاج
- استخدام `IS_DEBUG` للتحكم في عرض الأخطاء
- تسجيل الأخطاء في `error_log` بدلاً من العرض

### 6. تحويل عمليات الحذف إلى POST
- تم إنشاء `handle_delete_client.php` مع حماية CSRF
- تحويل الحذف من GET إلى POST في `view_clients.php`

---

## 📋 خطوات الإعداد

### 1. إنشاء ملف .env
أنشئ ملف `.env` في المجلد الرئيسي:

```env
DB_HOST=localhost
DB_NAME=u132225456_chef
DB_USER=u132225456_chef123
DB_PASS=S102030N@g
APP_ENV=production
DEBUG_MODE=false
SESSION_LIFETIME=3600
```

### 2. حماية ملف .env
تأكد من أن ملف `.env` في `.gitignore`:

```
.env
*.log
```

### 3. استخدام CSRF في النماذج

**في النماذج:**
```php
<?php require_once 'csrf.php'; ?>
<form method="POST" action="handle_action.php">
    <?php echo csrfField(); ?>
    <!-- باقي الحقول -->
</form>
```

**في المعالجات:**
```php
<?php
require_once 'csrf.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verifyCSRFToken()) {
        die('CSRF token invalid');
    }
    // معالجة النموذج
}
```

---

## 🔒 أفضل الممارسات

### 1. كلمات المرور
- ✅ استخدام `password_hash()` و `password_verify()`
- ✅ استخدام `PASSWORD_DEFAULT` (bcrypt)

### 2. الاستعلامات
- ✅ استخدام Prepared Statements دائماً
- ✅ استخدام PDO مع Exception Handling

### 3. المدخلات
- ✅ استخدام `htmlspecialchars()` للعرض
- ✅ استخدام `filter_var()` للتحقق
- ✅ استخدام `trim()` لتنظيف المدخلات

### 4. الملفات المرفوعة
- ✅ التحقق من نوع الملف (`getimagesize()`)
- ✅ التحقق من الامتداد
- ✅ تحديد حجم أقصى
- ✅ استخدام أسماء ملفات آمنة (`uniqid()`)

### 5. الجلسات
- ✅ `session_regenerate_id()` بعد تسجيل الدخول
- ✅ التحقق من الصلاحيات في كل صفحة
- ✅ تسجيل الخروج الآمن

---

## ⚠️ تحذيرات

1. **لا ترفع ملف `.env` إلى Git**
2. **لا تعرض رسائل الخطأ للمستخدمين في الإنتاج**
3. **استخدم HTTPS في الإنتاج**
4. **راقب ملفات السجلات (logs) بانتظام**
5. **حدث النظام والاعتماديات بانتظام**

---

## 📞 الدعم

في حالة وجود مشاكل أمنية، راجع:
- ملف `تقرير_فحص_المشروع.md` للتفاصيل الكاملة
- ملف `config.php` لإعدادات البيئة
- ملف `csrf.php` لاستخدام CSRF Protection

---

*آخر تحديث: <?php echo date('Y-m-d'); ?>*

