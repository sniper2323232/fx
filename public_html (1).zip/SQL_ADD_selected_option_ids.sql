-- Add multi-option support for daily selections
ALTER TABLE `daily_selections`
  ADD COLUMN `selected_option_ids` TEXT NULL AFTER `selected_option`;
