<?php
// manage_options.php - (تصنيفات + خيارات + Tiered Pricing + Nutrition per Tier)
// ======================================================================================

header('Content-Type: text/html; charset=utf-8');

if (file_exists('auth_admin.php')) require_once 'auth_admin.php';
require_once 'db_connect.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

function mo_h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }

// =========================
// جلب التصنيفات + الخيارات
// =========================
$categories = [];
$options = [];

// فلاتر العرض
$view = (string)($_GET['view'] ?? 'active'); // active | archived | all
if (!in_array($view, ['active','archived','all'], true)) $view = 'active';
$cat_filter = (int)($_GET['cat'] ?? 0); // option_category_id

try {
    // 1) التصنيفات
    $checkCat = $pdo->query("SHOW TABLES LIKE 'option_categories'");
    if ($checkCat->rowCount() > 0) {
        $categories = $pdo->query("
            SELECT id, name, sort_order, is_active
            FROM option_categories
            ORDER BY sort_order ASC, id ASC
        ")->fetchAll(PDO::FETCH_ASSOC);
    }

    // 2) الخيارات
    $checkOpt = $pdo->query("SHOW TABLES LIKE 'global_options'");
    if ($checkOpt->rowCount() > 0) {
        $where = [];
        $params = [];

        if ($view === 'active') $where[] = "(o.is_active=1 OR o.is_active IS NULL)";
        if ($view === 'archived') $where[] = "o.is_active=0";
        if ($cat_filter > 0) { $where[] = "o.category_id=?"; $params[] = $cat_filter; }

        $sql = "
            SELECT o.*, c.name AS category_name, c.sort_order AS cat_sort
            FROM global_options o
            LEFT JOIN option_categories c ON c.id = o.category_id
        ";
        if (!empty($where)) $sql .= " WHERE " . implode(" AND ", $where);
        $sql .= " ORDER BY (c.sort_order IS NULL), c.sort_order ASC, o.id DESC";

        if (!empty($params)) {
            $st = $pdo->prepare($sql);
            $st->execute($params);
            $options = $st->fetchAll(PDO::FETCH_ASSOC);
        } else {
            $options = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
        }
    }
} catch (PDOException $e) {
    die("خطأ في قاعدة البيانات: " . $e->getMessage());
}

// تصنيفات نشطة فقط لاستخدامها في إضافة خيار
$activeCategories = array_values(array_filter($categories, fn($c) => (int)$c['is_active'] === 1));

function countTiersSafe($pricing_config): int {
    $pricing = json_decode($pricing_config ?? '', true);
    if (!is_array($pricing)) return 0;
    $tiers = $pricing['tiers'] ?? [];
    return is_array($tiers) ? count($tiers) : 0;
}

function mo_url(string $view, int $catId): string {
    $qs = [];
    if ($view !== '') $qs['view'] = $view;
    if ($catId > 0) $qs['cat'] = $catId;
    $q = http_build_query($qs);
    return 'manage_options.php' . ($q ? ('?' . $q) : '');
}

$toast_type = '';
$toast_title = '';
$toast_text = '';
if (isset($_GET['success'])) {
    $s = (string)$_GET['success'];
    if ($s === 'added') { $toast_type='ok'; $toast_title='تمت الإضافة'; $toast_text='تم إنشاء الخيار بنجاح.'; }
    elseif ($s === 'toggled') { $toast_type='ok'; $toast_title='تم تحديث الحالة'; $toast_text='تم تغيير حالة الخيار.'; }
    elseif ($s === 'disabled') { $toast_type='ok'; $toast_title='تمت الأرشفة'; $toast_text='تم إخفاء الخيار (أرشفة) بنجاح.'; }
    elseif ($s === 'enabled') { $toast_type='ok'; $toast_title='تم إلغاء الأرشفة'; $toast_text='تم إظهار الخيار مرة أخرى.'; }
    elseif ($s === 'deleted') { $toast_type='ok'; $toast_title='تم الحذف النهائي'; $toast_text='تم حذف الخيار نهائياً.'; }
}
if (isset($_GET['error']) && !$toast_type) {
    $e = (string)$_GET['error'];
    $toast_type='bad';
    if ($e === 'cannot_delete_used') { $toast_title='تعذر الحذف'; $toast_text='لا يمكن حذف هذا الخيار لأنه مرتبط بمنتجات. استخدم الأرشفة.'; }
    elseif ($e === 'csrf') { $toast_title='خطأ أمني'; $toast_text='انتهت صلاحية الجلسة. حدّث الصفحة وحاول مجددًا.'; }
    else { $toast_title='حدث خطأ'; $toast_text='تعذر تنفيذ العملية.'; }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة الخيارات والتصنيفات</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
    <link rel="stylesheet" href="admin_colors.php?v=20260113">

    <style>
        body.manage-options-page { --primary: var(--restaurant-primary); --bg: var(--admin-bg); --text: var(--admin-text-main); --card-bg: var(--admin-surface); --border: var(--admin-border); }
        body.manage-options-page { background:var(--bg); font-family:'Tajawal',sans-serif; margin:0; color:var(--text); direction:rtl; }

        .page-header{display:flex; justify-content:space-between; align-items:center; margin-bottom:30px; gap:12px; flex-wrap:wrap;}
        .page-header h2{margin:0; font-weight:800; color:var(--primary);}
        .btn-back{background:#e5e7eb; color:#374151; padding:10px 20px; border-radius:50px; text-decoration:none; font-weight:bold; display:inline-flex; gap:8px; align-items:center;}

        .card{background:var(--card-bg); padding:30px; border-radius:20px; box-shadow:0 4px 6px -1px rgba(0,0,0,.05); margin-bottom:30px; border:1px solid var(--border);}
        label{font-weight:800; font-size:.9rem; color:#4b5563; margin-bottom:8px; display:block;}
        .form-control{width:100%; padding:12px; border:2px solid var(--border); border-radius:12px; font-size:1rem; box-sizing:border-box; font-family:'Tajawal',sans-serif; transition:.2s;}
        .form-control:focus{border-color:var(--primary); outline:none; box-shadow:0 0 0 4px rgba(99,102,241,.12);}
        .form-row{display:grid; grid-template-columns:repeat(auto-fit,minmax(220px,1fr)); gap:20px; margin-bottom:20px;}

        .btn-add{background:var(--primary); color:#fff; border:none; padding:15px 30px; border-radius:14px; cursor:pointer; font-weight:900; width:100%; font-size:1.1rem; transition:.2s; box-shadow:0 6px 18px rgba(99,102,241,.35);}
        .btn-add:hover{transform:translateY(-2px);}

        /* Tier UI */
        .tiers-wrap{background:#fffbe6; padding:18px; border-radius:14px; border:1px solid #fef3c7;}
        .tier-row{
            display:grid;
            grid-template-columns:1.1fr .9fr .8fr 1.6fr 44px;
            gap:10px;
            background:#fff; padding:14px; border-radius:14px; border:1px solid var(--border);
            margin-bottom:10px; align-items:end; box-shadow:0 2px 8px rgba(0,0,0,.03);
        }
        @media(max-width:1100px){
            .tier-row{grid-template-columns:1fr 1fr}
            .tier-actions{grid-column:span 2}
        }
        .tier-label{font-size:.75rem; color:#6b7280; font-weight:900; display:block; margin-bottom:6px; white-space:nowrap;}
        .btn-del-row{color:#ef4444; background:#fee2e2; width:44px; height:44px; border-radius:12px; border:none; cursor:pointer; display:flex; align-items:center; justify-content:center; transition:.15s;}
        .btn-del-row:hover{background:#fecaca;}

        .auto-weight-badge{display:none; background:#dcfce7; color:#166534; padding:11px; border-radius:12px; font-size:.85rem; font-weight:900; text-align:center; border:1px dashed #22c55e;}

        .nutri-box{
            display:grid;
            grid-template-columns:repeat(4, 1fr);
            gap:8px;
            background:#f9fafb;
            border:1px dashed #e5e7eb;
            border-radius:14px;
            padding:10px;
        }
        @media(max-width:768px){ .nutri-box{grid-template-columns:1fr 1fr} }
        .nutri-box .form-control{padding:10px; border-radius:12px;}
        .nutri-mini{font-size:.75rem; color:#6b7280; font-weight:900; margin-bottom:6px; display:block;}

        table{width:100%; border-collapse:separate; border-spacing:0 10px; margin-top:10px;}
        th{color:#6b7280; font-weight:900; padding:10px 20px; text-align:right;}
        td{background:#fff; padding:15px 20px; border-top:1px solid var(--border); border-bottom:1px solid var(--border);}
        td:first-child{border-right:1px solid var(--border); border-top-right-radius:12px; border-bottom-right-radius:12px;}
        td:last-child{border-left:1px solid var(--border); border-top-left-radius:12px; border-bottom-left-radius:12px;}

        .badge{padding:5px 12px; border-radius:999px; font-size:.8rem; font-weight:900; display:inline-block;}
        .badge-tiered{background:#ffedd5; color:#9a3412;}
        .badge-cat{background:#eef2ff; color:#3730a3;}
        .badge-off{background:#f3f4f6; color:#6b7280;}
        .badge-on{background:#dcfce7; color:#166534;}

        .btn-action{padding:8px 12px; border-radius:10px; margin-left:6px; text-decoration:none; font-size:.9rem; transition:.2s; display:inline-flex; align-items:center; justify-content:center; border:none; cursor:pointer;}
        .btn-edit{background:#e0e7ff; color:var(--primary);}
        .btn-del{background:#fee2e2; color:#ef4444;}
        .btn-toggle{background:#ecfeff; color:#0e7490;}

        input[type="number"]{font-family:'Segoe UI',sans-serif; direction:ltr; text-align:center; font-weight:900;}

        /* Modal */
        .modal-backdrop{position:fixed; inset:0; background:rgba(0,0,0,.35); display:none; align-items:center; justify-content:center; z-index:2000;}
        .modal{width:min(520px,92vw); background:#fff; border-radius:16px; padding:18px; border:1px solid var(--border); box-shadow:0 10px 30px rgba(0,0,0,.12);}
        .modal-header{display:flex; justify-content:space-between; align-items:center; margin-bottom:10px;}
        .modal-title{font-weight:900; color:#111827;}
        .modal-close{background:#f3f4f6; border:1px solid var(--border); border-radius:12px; width:40px; height:40px; cursor:pointer;}
        .hint{color:#6b7280; font-weight:800; font-size:.85rem;}
        .warn{background:#fff7ed; border:1px dashed #fb923c; padding:12px; border-radius:12px; color:#9a3412; font-weight:900;}
        .note{background:#f0f9ff; border:1px dashed #38bdf8; padding:12px; border-radius:12px; color:#075985; font-weight:900; margin-top:12px;}

        .toolbar-top{display:flex;justify-content:space-between;align-items:center;gap:12px;flex-wrap:wrap;margin:0 0 14px 0}
        .view-tabs{display:flex;gap:10px;flex-wrap:wrap;align-items:center}
        .view-tab{padding:10px 14px;border-radius:999px;border:1px solid var(--border);background:#fff;text-decoration:none;color:#111827;font-weight:900;display:inline-flex;align-items:center;gap:8px}
        .view-tab.active{background:var(--restaurant-gradient);border-color:transparent;color:#fff}
        .cats-tabs{display:flex;gap:10px;overflow:auto;padding-bottom:6px;scrollbar-width:none;margin-bottom:14px}
        .cats-tabs::-webkit-scrollbar{display:none}
        .cat-tab{padding:10px 14px;border-radius:999px;border:1px solid var(--border);background:#fff;text-decoration:none;color:#111827;font-weight:900;white-space:nowrap;display:inline-flex;align-items:center;gap:8px}
        .cat-tab.active{background:rgba(217,119,6,.10);border-color:rgba(217,119,6,.28);color:#92400e}
        .searchRow{display:flex;gap:10px;align-items:center;flex-wrap:wrap}

        .row-archived{opacity:.55}
        .actionsWrap{display:flex;gap:8px;align-items:center;justify-content:flex-start;flex-wrap:wrap}
        .btn-mini{padding:8px 12px;border-radius:12px;border:1px solid rgba(28,25,23,0.10);background:#fff;cursor:pointer;display:inline-flex;align-items:center;justify-content:center;gap:8px;font-weight:1000;color:#111827}
        .btn-mini:hover{background:rgba(28,25,23,0.04)}
        .btn-mini.edit{background:rgba(37,99,235,0.08);border-color:rgba(37,99,235,0.18);color:#1d4ed8}
        .btn-mini.archive{background:rgba(245,158,11,0.12);border-color:rgba(245,158,11,0.20);color:#92400e}
        .btn-mini.unarchive{background:rgba(34,197,94,0.12);border-color:rgba(34,197,94,0.20);color:#166534}
        .btn-mini.delete{background:rgba(239,68,68,0.12);border-color:rgba(239,68,68,0.20);color:#b91c1c}
    </style>
</head>
<body class="manage-options-page">

<?php if(file_exists('sidebar.php')) include 'sidebar.php'; ?>

<div class="main-content">
    <header class="top-bar">
        <div class="user-info">الخيارات والتصنيفات</div>
        <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> خروج</a>
    </header>
    <div class="content-wrapper">

    <?php if ($toast_type && $toast_title): ?>
        <div class="toastStack" id="toastStack">
            <div class="toast <?php echo $toast_type === 'ok' ? 'toastOk' : 'toastBad'; ?>">
                <div class="toastIcon">
                    <i class="fas <?php echo $toast_type === 'ok' ? 'fa-check' : 'fa-triangle-exclamation'; ?>"></i>
                </div>
                <div class="toastBody">
                    <div class="toastTitle"><?php echo mo_h($toast_title); ?></div>
                    <?php if ($toast_text): ?>
                        <div class="toastText"><?php echo mo_h($toast_text); ?></div>
                    <?php endif; ?>
                </div>
                <button class="toastClose" type="button" onclick="this.closest('.toast').remove()"><i class="fas fa-xmark"></i></button>
            </div>
        </div>
    <?php endif; ?>

    <div class="page-header">
        <div>
            <h2>📦 مكتبة الخيارات + التصنيفات</h2>
            <small class="hint">الآن القيم الغذائية أصبحت داخل كل شريحة (Tier) — لكل وزن قيمه الخاصة ✅</small>
        </div>
        <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
            <a href="manage_products.php" class="btn-back"><i class="fas fa-arrow-right"></i> عودة للمنتجات</a>
        </div>
    </div>

    <!-- =======================
         Card: Categories
    ======================== -->
    <div class="card">
        <div style="display:flex; justify-content:space-between; align-items:center; gap:10px; flex-wrap:wrap;">
            <h3 style="margin:0; color:#374151;"><i class="fas fa-layer-group"></i> تصنيفات الخيارات</h3>
            <button class="btn-action btn-edit" type="button" onclick="openCategoryModal()">
                <i class="fas fa-plus"></i> إضافة تصنيف
            </button>
        </div>

        <?php if(count($categories) > 0): ?>
            <div style="overflow-x:auto; margin-top:15px;">
                <table>
                    <thead>
                    <tr>
                        <th>التصنيف</th>
                        <th>الترتيب</th>
                        <th>الحالة</th>
                        <th>تحكم</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($categories as $c):
                        $catActive = ((int)$c['is_active'] === 1);
                    ?>
                        <tr style="<?= $catActive ? '' : 'opacity:0.55;' ?>">
                            <td><strong><?= htmlspecialchars($c['name']) ?></strong></td>
                            <td><?= (int)$c['sort_order'] ?></td>
                            <td>
                                <?= $catActive
                                    ? '<span class="badge badge-on">نشط</span>'
                                    : '<span class="badge badge-off">مخفي</span>' ?>
                            </td>
                            <td>
                                <form action="handle_categories.php" method="POST" style="display:inline;">
                                    <input type="hidden" name="action" value="toggle_category">
                                    <input type="hidden" name="id" value="<?= (int)$c['id'] ?>">
                                    <button class="btn-action btn-toggle" type="submit" title="تبديل الحالة">
                                        <i class="fas fa-toggle-on"></i>
                                    </button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="text-align:center; padding:25px; color:#9ca3af;">لا توجد تصنيفات. أضف أول تصنيف الآن.</div>
        <?php endif; ?>
    </div>

    <!-- =======================
         Card: Add Option
    ======================== -->
    <div class="card">
        <h3 style="margin-top:0; padding-bottom:15px; border-bottom:1px dashed var(--border); color:#374151;">
            <i class="fas fa-plus-circle" style="color:var(--primary);"></i> إضافة خيار جديد
        </h3>

        <?php if(count($activeCategories) === 0): ?>
            <div class="warn">
                لازم تضيف تصنيف واحد على الأقل قبل إضافة الخيارات.
            </div>
        <?php endif; ?>

        <form action="handle_options.php" method="POST" <?= (count($activeCategories) === 0 ? 'onsubmit="return false;"' : '') ?>>
            <input type="hidden" name="csrf_token" value="<?php echo mo_h($_SESSION['csrf_token']); ?>">
            <input type="hidden" name="action" value="add">

            <div class="form-row">
                <div>
                    <label>اسم الخيار <span style="color:red">*</span></label>
                    <input type="text" name="name" class="form-control" placeholder="مثال: رز أبيض / صوص ثوم / عصير" required>
                </div>

                <div>
                    <label>التصنيف <span style="color:red">*</span></label>
                    <select name="category_id" class="form-control" required <?= (count($activeCategories) === 0 ? 'disabled' : '') ?>>
                        <option value="">-- اختر التصنيف --</option>
                        <?php foreach($activeCategories as $cat): ?>
                            <option value="<?= (int)$cat['id'] ?>"><?= htmlspecialchars($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </div>

                <div>
                    <label>وحدة القياس <span style="color:red">*</span></label>
                    <select name="unit" id="mainUnitSelect" class="form-control" style="font-weight:900; color:var(--primary);" onchange="updateUnitLabels()">
                        <option value="gram" data-label="وزن">جرام (g)</option>
                        <option value="ml" data-label="حجم">مل (ml)</option>
                        <option value="piece" data-label="عدد">قطعة (Piece)</option>
                        <option value="kg" data-label="وزن">كيلو (kg)</option>
                        <option value="liter" data-label="حجم">لتر (Liter)</option>
                    </select>
                </div>
            </div>

            <h4 style="color:var(--primary); margin:20px 0 10px 0; border-bottom:2px solid #f3f4f6; padding-bottom:10px;">
                <i class="fas fa-sliders-h"></i> شرائح التسعير + القيم الغذائية (لكل شريحة حسب وزن الوجبة)
            </h4>

            <div class="tiers-wrap">
                <div style="display:grid; grid-template-columns:1.1fr .9fr .8fr 1.6fr 44px; gap:10px; margin-bottom:10px; padding:0 8px; font-size:0.78rem; color:#92400e; font-weight:900;">
                    <div>شرط الوجبة (إذا الوزن &lt;)</div>
                    <div><i class="fas fa-utensils"></i> كمية الخيار (<span class="unit-display">جرام</span>)</div>
                    <div>السعر</div>
                    <div>📊 القيم الغذائية لهذه الشريحة</div>
                    <div></div>
                </div>

                <div id="tiers-container"></div>

                <button type="button" onclick="addTierRow()" style="background:white; border:2px dashed #d97706; color:#d97706; padding:12px 20px; border-radius:12px; cursor:pointer; font-weight:900; width:100%; margin-top:10px;">
                    <i class="fas fa-plus"></i> إضافة شريحة جديدة
                </button>

                <div class="note">
                    ✅ الآن القيم الغذائية يتم إدخالها داخل كل شريحة Tier (يعني لكل وزن قيمه الخاصة).
                </div>
            </div>

            <button type="submit" class="btn-add" style="margin-top:18px;" <?= (count($activeCategories) === 0 ? 'disabled' : '') ?>>
                <i class="fas fa-check-circle"></i> حفظ الخيار
            </button>
        </form>
    </div>

    <!-- =======================
         Card: Options List
    ======================== -->
    <div class="card">
        <h3 style="margin-top:0; color:#374151; font-size:1.1rem; margin-bottom:15px;">
            <i class="fas fa-list"></i> الخيارات (<?= count($options); ?>)
        </h3>

        <div class="toolbar-top">
            <div class="view-tabs">
                <a class="view-tab <?php echo $view==='active'?'active':''; ?>" href="<?php echo mo_h(mo_url('active', $cat_filter)); ?>"><i class="fas fa-circle-check"></i> نشطة</a>
                <a class="view-tab <?php echo $view==='archived'?'active':''; ?>" href="<?php echo mo_h(mo_url('archived', $cat_filter)); ?>"><i class="fas fa-box-archive"></i> مؤرشفة</a>
                <a class="view-tab <?php echo $view==='all'?'active':''; ?>" href="<?php echo mo_h(mo_url('all', $cat_filter)); ?>"><i class="fas fa-layer-group"></i> الكل</a>
            </div>
            <div class="searchRow">
                <input id="optSearch" type="text" class="form-control" placeholder="بحث بالاسم..." style="max-width:420px;">
            </div>
        </div>

        <div class="cats-tabs">
            <a class="cat-tab <?php echo $cat_filter===0?'active':''; ?>" href="<?php echo mo_h(mo_url($view, 0)); ?>"><i class="fas fa-list"></i> الكل</a>
            <?php foreach($categories as $c): ?>
                <a class="cat-tab <?php echo $cat_filter===(int)$c['id']?'active':''; ?>" href="<?php echo mo_h(mo_url($view, (int)$c['id'])); ?>">
                    <i class="fas fa-tag"></i> <?php echo mo_h($c['name']); ?>
                </a>
            <?php endforeach; ?>
        </div>

        <?php if(count($options) > 0): ?>
            <div style="overflow-x:auto;">
                <table id="optionsTable">
                    <thead>
                    <tr>
                        <th>الاسم</th>
                        <th>التصنيف</th>
                        <th>الوحدة</th>
                        <th>عدد الشرائح</th>
                        <th>الحالة</th>
                        <th>تحكم</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach($options as $opt):
                        $countTiers = countTiersSafe($opt['pricing_config'] ?? '');
                        $active = (int)($opt['is_active'] ?? 1) === 1;
                    ?>
                        <tr class="<?php echo $active ? '' : 'row-archived'; ?>"
                            data-name="<?php echo mo_h(mb_strtolower((string)$opt['name'])); ?>">
                            <td><strong style="font-size:1rem; color:#111827;"><?= mo_h($opt['name']); ?></strong></td>
                            <td><span class="badge badge-cat"><?= htmlspecialchars($opt['category_name'] ?? 'بدون تصنيف'); ?></span></td>
                            <td><span style="background:#f3f4f6; padding:5px 10px; border-radius:8px; font-weight:900; color:#555;"><?= htmlspecialchars($opt['unit']); ?></span></td>
                            <td><span class="badge badge-tiered"><?= (int)$countTiers; ?> مستويات</span></td>
                            <td><?= $active ? '<span class="badge badge-on">نشط</span>' : '<span class="badge badge-off">مخفي</span>' ?></td>
                            <td>
                                <div class="actionsWrap">
                                    <a href="edit_option.php?id=<?= (int)$opt['id']; ?>" class="btn-mini edit" title="تعديل">
                                        <i class="fas fa-pen"></i>
                                    </a>

                                    <?php if ($active): ?>
                                        <form action="handle_options.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo mo_h($_SESSION['csrf_token']); ?>">
                                            <input type="hidden" name="action" value="archive">
                                            <input type="hidden" name="id" value="<?= (int)$opt['id']; ?>">
                                            <button type="submit" class="btn-mini archive" title="أرشفة" onclick="return confirm('أرشفة (إخفاء) هذا الخيار؟');">
                                                <i class="fas fa-eye-slash"></i>
                                            </button>
                                        </form>
                                    <?php else: ?>
                                        <form action="handle_options.php" method="POST" style="display:inline;">
                                            <input type="hidden" name="csrf_token" value="<?php echo mo_h($_SESSION['csrf_token']); ?>">
                                            <input type="hidden" name="action" value="unarchive">
                                            <input type="hidden" name="id" value="<?= (int)$opt['id']; ?>">
                                            <button type="submit" class="btn-mini unarchive" title="إلغاء الأرشفة" onclick="return confirm('إلغاء الأرشفة وإظهار الخيار؟');">
                                                <i class="fas fa-rotate-left"></i>
                                            </button>
                                        </form>
                                    <?php endif; ?>

                                    <form action="handle_options.php" method="POST" style="display:inline;">
                                        <input type="hidden" name="csrf_token" value="<?php echo mo_h($_SESSION['csrf_token']); ?>">
                                        <input type="hidden" name="action" value="delete_permanent">
                                        <input type="hidden" name="id" value="<?= (int)$opt['id']; ?>">
                                        <button type="submit" class="btn-mini delete" title="حذف نهائي" onclick="return confirm('حذف نهائي لهذا الخيار؟ سيتم المنع إذا كان مرتبطاً بمنتجات.');">
                                            <i class="fas fa-trash"></i>
                                        </button>
                                    </form>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php else: ?>
            <div style="text-align:center; padding:40px; color:#9ca3af;">لا توجد خيارات مضافة.</div>
        <?php endif; ?>
    </div>

</div>
</div>

<!-- =======================
     Modal: Add Category
======================= -->
<div class="modal-backdrop" id="catModal">
    <div class="modal">
        <div class="modal-header">
            <div class="modal-title"><i class="fas fa-plus"></i> إضافة تصنيف</div>
            <button class="modal-close" type="button" onclick="closeCategoryModal()"><i class="fas fa-times"></i></button>
        </div>
        <form action="handle_categories.php" method="POST">
            <input type="hidden" name="action" value="add_category">
            <label>اسم التصنيف</label>
            <input type="text" name="name" class="form-control" placeholder="مثال: خيارات الكارب" required>
            <div style="height:10px;"></div>
            <label>الترتيب (اختياري)</label>
            <input type="number" name="sort_order" class="form-control" value="0">
            <div style="height:15px;"></div>
            <button class="btn-add" type="submit"><i class="fas fa-check"></i> حفظ التصنيف</button>
        </form>
    </div>
</div>

<script>
function openCategoryModal(){ document.getElementById('catModal').style.display='flex'; }
function closeCategoryModal(){ document.getElementById('catModal').style.display='none'; }

// Gram => auto (إخفاء دون تصفير)
function updateUnitLabels() {
    const select = document.getElementById('mainUnitSelect');
    const unit = select.value;
    const selectedOption = select.options[select.selectedIndex];
    const unitText = selectedOption.text;
    const labelType = selectedOption.getAttribute('data-label');

    document.querySelectorAll('.unit-display').forEach(el => el.textContent = unitText);

    const servingInputs = document.querySelectorAll('.serving-input');
    const servingBadges = document.querySelectorAll('.auto-weight-badge');

    if (unit === 'gram') {
        servingInputs.forEach(input => { input.style.display = 'none'; });
        servingBadges.forEach(b => b.style.display = 'block');
    } else {
        servingInputs.forEach(input => {
            input.style.display = 'block';
            input.placeholder = `ال${labelType} (${unitText})`;
        });
        servingBadges.forEach(b => b.style.display = 'none');
    }
}

document.addEventListener('DOMContentLoaded', () => {
    if (document.getElementById('tiers-container').children.length === 0) addTierRow();
    updateUnitLabels();

    const toast = document.getElementById('toastStack');
    if (toast) setTimeout(() => { toast.remove(); }, 4500);

    const search = document.getElementById('optSearch');
    if (search) {
        search.addEventListener('input', function(){
            const q = (this.value || '').trim().toLowerCase();
            document.querySelectorAll('#optionsTable tbody tr').forEach(tr => {
                const name = tr.getAttribute('data-name') || '';
                tr.style.display = name.includes(q) ? '' : 'none';
            });
        });
    }
});

function addTierRow() {
    const container = document.getElementById('tiers-container');
    const unit = document.getElementById('mainUnitSelect').value;

    const inputStyle = (unit === 'gram') ? 'display:none;' : 'display:block;';
    const badgeStyle = (unit === 'gram') ? 'display:block;' : 'display:none;';

    const div = document.createElement('div');
    div.className = 'tier-row';

    div.innerHTML = `
        <div>
            <span class="tier-label">شرط: وجبة أصغر من (جم)</span>
            <input type="number" name="tiers_weight[]" class="form-control" placeholder="200" required>
        </div>

        <div>
            <span class="tier-label" style="color:var(--primary)">الكمية الفعلية للخيار</span>
            <input type="number" step="0.01" name="tiers_serving[]" class="form-control serving-input"
                   placeholder="الكمية" style="border-color:var(--primary); background:#eff6ff; ${inputStyle}">
            <div class="auto-weight-badge" style="${badgeStyle}">
                <i class="fas fa-magic"></i> تلقائي (نفس الوجبة)
            </div>
        </div>

        <div>
            <span class="tier-label">السعر (ر.س)</span>
            <input type="number" step="0.5" name="tiers_price[]" class="form-control" placeholder="0" required>
        </div>

        <div>
            <span class="tier-label">القيم الغذائية لهذه الشريحة</span>
            <div class="nutri-box">
                <div>
                    <span class="nutri-mini">🔥 سعرات</span>
                    <input type="number" name="tiers_calories[]" class="form-control" placeholder="0">
                </div>
                <div>
                    <span class="nutri-mini">🥩 بروتين</span>
                    <input type="number" step="0.1" name="tiers_protein[]" class="form-control" placeholder="0">
                </div>
                <div>
                    <span class="nutri-mini">🥔 كارب</span>
                    <input type="number" step="0.1" name="tiers_carbs[]" class="form-control" placeholder="0">
                </div>
                <div>
                    <span class="nutri-mini">🥑 دهون</span>
                    <input type="number" step="0.1" name="tiers_fat[]" class="form-control" placeholder="0">
                </div>
            </div>
        </div>

        <div class="tier-actions">
            <button type="button" class="btn-del-row" onclick="this.closest('.tier-row').remove()">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `;

    container.appendChild(div);
    updateUnitLabels();
}
</script>

</body>
</html>
