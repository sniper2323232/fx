<?php
// apply_quota_updates.php
// سكربت لتحديث قاعدة البيانات لدعم نظام حصص الخيارات الجديد
require_once 'db_connect.php';

echo "<h1>تحديث قاعدة البيانات - نظام حصص الخيارات</h1>";
echo "<div style='background:#f9f9f9; padding:20px; border:1px solid #ddd;'>";

try {
    // 1. إضافة عمود max_options_allowed إلى جدول packages
    // نستخدمه لتحديد الحد الأقصى للخيارات المسموحة في الوجبة الواحدة
    $stmt = $pdo->query("SHOW COLUMNS FROM packages LIKE 'max_options_allowed'");
    if ($stmt->rowCount() == 0) {
        $pdo->exec("ALTER TABLE packages ADD COLUMN max_options_allowed INT(11) NOT NULL DEFAULT 1 COMMENT 'عدد الخيارات المسموح للعميل اختيارها للوجبة الواحدة'");
        echo "<p style='color:green;'>✓ تم إضافة عمود max_options_allowed بنجاح.</p>";
        
        // محاولة نسخ القيمة القديمة من options_selectable_count إذا وجدت
        try {
            $checkOld = $pdo->query("SHOW COLUMNS FROM packages LIKE 'options_selectable_count'");
            if ($checkOld->rowCount() > 0) {
                $pdo->exec("UPDATE packages SET max_options_allowed = options_selectable_count WHERE options_selectable_count > 0");
                echo "<p style='color:green;'>✓ تم نسخ قيم Limits القديمة إلى النظام الجديد.</p>";
            }
        } catch (Exception $ex) {}
        
    } else {
        echo "<p style='color:blue;'>✓ عمود max_options_allowed موجود مسبقاً.</p>";
    }

    // 2. إنشاء جدول package_allowed_categories
    // لربط الباقة بالتصنيفات المسموح بظهورها (Many-to-Many)
    $sql_table = "CREATE TABLE IF NOT EXISTS `package_allowed_categories` (
        `id` int(11) NOT NULL AUTO_INCREMENT,
        `package_id` int(11) NOT NULL,
        `category_id` int(11) NOT NULL,
        PRIMARY KEY (`id`),
        UNIQUE KEY `unique_pkg_cat` (`package_id`,`category_id`)
    ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;";
    
    $pdo->exec($sql_table);
    echo "<p style='color:green;'>✓ تم إنشاء/التحقق من جدول package_allowed_categories.</p>";

    echo "<hr><h3 style='color:green;'>تمت عملية التحديث بنجاح!</h3>";
    echo "<p>يمكنك الآن استخدام الميزات الجديدة في إدارة الباقات.</p>";

} catch (PDOException $e) {
    echo "<h3 style='color:red;'>حدث خطأ أثناء التحديث:</h3>";
    echo "<pre>" . $e->getMessage() . "</pre>";
}

echo "</div>";
?>
