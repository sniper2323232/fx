<?php
/**
 * client_select_meals.php (REWRITE - FIXED)
 * -----------------------------------------------------------------------------
 * ✅ Full rewrite with same UI pattern (cards + bottom sheet + AJAX)
 * ✅ Fix JS fatal errors (extra ">" / broken closing tags / missing functions)
 * ✅ Fix pkg_id scope in AJAX
 * ✅ Implement multi-select options using option_ids_csv
 * ✅ Enforce option-category limits if tables exist (package + client overrides + visibility)
 * ✅ Keeps footer include: client_footer_nav.php
 */

ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

ob_start();
header("Cache-Control: no-cache, no-store, must-revalidate");
header("Pragma: no-cache");
header("Expires: 0");

require_once 'db_connect.php';

if (session_status() === PHP_SESSION_NONE) session_start();
if (!isset($_SESSION['user_id'])) { header("Location: login.php"); exit; }

$client_id = (int)$_SESSION['user_id'];
date_default_timezone_set('Asia/Riyadh');

/* ===========================
   Helpers
=========================== */
function safeFloat($v): float {
    if ($v === null || $v === '' || !is_numeric($v)) return 0.0;
    return (float)$v;
}
function safeInt($v): int {
    if ($v === null || $v === '' || !is_numeric($v)) return 0;
    return (int)$v;
}
function fmtNum($n, $dec=1): string {
    $n = (float)$n;
    if (abs($n - round($n)) < 0.00001) return (string)(int)round($n);
    return rtrim(rtrim(number_format($n, $dec, '.', ''), '0'), '.');
}
function tableExists(PDO $pdo, string $table): bool {
    $st = $pdo->prepare("SHOW TABLES LIKE ?");
    $st->execute([$table]);
    return $st->rowCount() > 0;
}
function columnExists(PDO $pdo, string $table, string $column): bool {
    $st = $pdo->prepare("
        SELECT COUNT(*) FROM information_schema.COLUMNS
        WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME=? AND COLUMN_NAME=?
    ");
    $st->execute([$table, $column]);
    return (int)$st->fetchColumn() > 0;
}
function unitShort(string $u): string {
    $u = strtolower(trim($u));
    if ($u === 'gram' || $u === 'g' || $u === 'gm' || $u === 'جرام' || $u === 'غرام') return 'g';
    if ($u === 'ml' || $u === 'مل') return 'ml';
    if ($u === 'kg' || $u === 'كيلو' || $u === 'كجم') return 'kg';
    if ($u === 'liter' || $u === 'l' || $u === 'لتر') return 'l';
    if ($u === 'piece' || $u === 'pcs' || $u === 'قطعة' || $u === 'حبة') return 'pc';
    return $u ?: '';
}
function getUnitType($unit) {
    if (empty($unit)) return 'count';
    $u = strtolower(trim($unit));
    $solids  = ['g','gm','gram','kg','كيلو','كجم','جرام','غرام'];
    $liquids = ['ml','l','liter','مل','ملي','لتر'];
    if (in_array($u, $solids, true)) return 'solid';
    if (in_array($u, $liquids, true)) return 'liquid';
    return 'count';
}
function pickTierForMealWeight(string $jsonConfig, float $mealWeight): ?array {
    $data = json_decode($jsonConfig ?? '', true);
    if (!is_array($data)) return null;
    $tiers = $data['tiers'] ?? null;
    if (!is_array($tiers) || empty($tiers)) return null;

    usort($tiers, function($a, $b) {
        return safeFloat($a['threshold'] ?? 0) <=> safeFloat($b['threshold'] ?? 0);
    });

    foreach ($tiers as $tier) {
        $th = safeFloat($tier['threshold'] ?? 0);
        if ($mealWeight < $th) return $tier;
    }
    return end($tiers) ?: null;
}
function getMealBaseMacros(PDO $pdo, int $product_id, float $allowed_weight): array {
    // product_sizes must exist in your project, else fallback zeros
    if (!tableExists($pdo, 'product_sizes')) {
        return [
            'weight' => $allowed_weight,
            'unit' => 'gram',
            'calories' => 0,
            'protein' => 0,
            'carbs' => 0,
            'fat' => 0,
        ];
    }

    $st = $pdo->prepare("
        SELECT weight, unit, calories, protein, carbs, fats
        FROM product_sizes
        WHERE product_id=? AND is_active=1
        ORDER BY ABS(weight - ?) ASC
        LIMIT 1
    ");
    $st->execute([$product_id, $allowed_weight]);
    $row = $st->fetch(PDO::FETCH_ASSOC);

    if (!$row) {
        return [
            'weight' => $allowed_weight,
            'unit' => 'gram',
            'calories' => 0,
            'protein' => 0,
            'carbs' => 0,
            'fat' => 0,
        ];
    }

    return [
        'weight' => safeFloat($row['weight'] ?? $allowed_weight),
        'unit' => $row['unit'] ?? 'gram',
        'calories' => safeFloat($row['calories'] ?? 0),
        'protein' => safeFloat($row['protein'] ?? 0),
        'carbs' => safeFloat($row['carbs'] ?? 0),
        'fat' => safeFloat($row['fats'] ?? 0),
    ];
}
function computeOptionContribution(array $optRow, float $allowed_weight): array {
    $unit = (string)($optRow['unit'] ?? 'gram');
    $pc   = (string)($optRow['pricing_config'] ?? '');

    $tier = pickTierForMealWeight($pc, $allowed_weight);

    $serving = 0.0;
    if (is_array($tier)) {
        $serving = safeFloat($tier['serving'] ?? ($tier['qty'] ?? 0));
        if ($serving <= 0 && isset($tier['auto_serving']) && $tier['auto_serving']) {
            $t = getUnitType($unit);
            $serving = ($t === 'solid') ? $allowed_weight : 1;
        }
    }
    if ($serving <= 0) {
        $t = getUnitType($unit);
        $serving = ($t === 'solid') ? $allowed_weight : 1;
    }

    $nCal = 0.0; $nPro = 0.0; $nCar = 0.0; $nFat = 0.0;

    if (is_array($tier)) {
        if (isset($tier['nutrition']) && is_array($tier['nutrition'])) {
            $nCal = safeFloat($tier['nutrition']['calories'] ?? 0);
            $nPro = safeFloat($tier['nutrition']['protein'] ?? 0);
            $nCar = safeFloat($tier['nutrition']['carbs'] ?? 0);
            $nFat = safeFloat($tier['nutrition']['fat'] ?? 0);
        } else {
            $nCal = safeFloat($tier['calories'] ?? 0);
            $nPro = safeFloat($tier['protein'] ?? 0);
            $nCar = safeFloat($tier['carbs'] ?? 0);
            $nFat = safeFloat($tier['fat'] ?? 0);
        }
    }

    if (($nCal + $nPro + $nCar + $nFat) <= 0) {
        $nCal = safeFloat($optRow['calories'] ?? 0);
        $nPro = safeFloat($optRow['protein'] ?? 0);
        $nCar = safeFloat($optRow['carbs'] ?? 0);
        $nFat = safeFloat($optRow['fat'] ?? 0);
    }

    return [
        'serving' => $serving,
        'unit' => $unit,
        'calories' => $nCal,
        'protein'  => $nPro,
        'carbs'    => $nCar,
        'fat'      => $nFat,
    ];
}
function sumMacros(array $base, array $add): array {
    return [
        'calories' => safeFloat($base['calories'] ?? 0) + safeFloat($add['calories'] ?? 0),
        'protein'  => safeFloat($base['protein'] ?? 0)  + safeFloat($add['protein'] ?? 0),
        'carbs'    => safeFloat($base['carbs'] ?? 0)    + safeFloat($add['carbs'] ?? 0),
        'fat'      => safeFloat($base['fat'] ?? 0)      + safeFloat($add['fat'] ?? 0),
    ];
}

function getGraceDays(PDO $pdo): int {
    $graceDays = 30;
    try {
        $val = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key='grace_period_days'")->fetchColumn();
        if (is_numeric($val)) $graceDays = max(0, (int)$val);
    } catch (Throwable $e) {}
    return $graceDays;
}

function isKitchenLocked(PDO $pdo, int $client_id, string $date): bool {
    if (!tableExists($pdo, 'delivery_log')) return false;
    $st = $pdo->prepare("SELECT status FROM delivery_log WHERE client_id=? AND delivery_date=?");
    $st->execute([$client_id, $date]);
    $s = (string)$st->fetchColumn();
    return in_array($s, ['prepared','out_for_delivery','delivered'], true);
}

/* ===========================
   AJAX (POST)
=========================== */
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['ajax_action'])) {
    if (ob_get_length()) ob_clean();
    header('Content-Type: application/json; charset=utf-8');
    ini_set('display_errors', 0);

    try {
        $action = (string)($_POST['ajax_action'] ?? '');
        $action_date = (string)($_POST['date'] ?? '');
        if ($action_date === '') throw new Exception("تاريخ العملية مفقود.");

        // load client subscription + package
        $stmt_client = $pdo->prepare("
            SELECT cd.*, p.meals_per_day, p.id AS pkg_id, p.allowed_weight, p.duration_days, p.max_options_allowed
            FROM client_details cd
            JOIN packages p ON cd.package_id = p.id
            WHERE cd.user_id = ?
        ");
        $stmt_client->execute([$client_id]);
        $client_data = $stmt_client->fetch(PDO::FETCH_ASSOC);
        if (!$client_data) throw new Exception("لم يتم العثور على اشتراك نشط لهذا الحساب.");

        $pkg_id = (int)($client_data['pkg_id'] ?? 0); // ✅ FIX: defined here
        if ($pkg_id <= 0) throw new Exception("بيانات الباقة غير صحيحة.");

        // effective meals/day override
        $eff_meals_per_day = (!empty($client_data['meals_per_day_override']) && (int)$client_data['meals_per_day_override'] > 0)
            ? (int)$client_data['meals_per_day_override']
            : (int)($client_data['meals_per_day'] ?? 0);
        $client_data['meals_per_day'] = max(0, $eff_meals_per_day);

        $allowed_weight = safeFloat($client_data['allowed_weight'] ?? 0);

        // grace lock check
        $graceDays = getGraceDays($pdo);

        $subscription_start_dt = $client_data['subscription_start_date'] ?? null;
        if (empty($subscription_start_dt)) throw new Exception("تاريخ بداية الاشتراك غير موجود.");

        $package_days = (int)($client_data['duration_days'] ?? 0);
        if ($package_days <= 0) $package_days = 30;

        $endDt = (new DateTime($subscription_start_dt))->modify("+{$package_days} days");
        $graceEnd = (clone $endDt)->modify("+{$graceDays} days");

        $reqDt = new DateTime($action_date);
        if ($reqDt > $graceEnd) throw new Exception("تجاوزت فترة الإمهال. الرجاء تجديد الاشتراك.");

        // kitchen lock
        if (isKitchenLocked($pdo, $client_id, $action_date)) {
            throw new Exception("لا يمكن التعديل: الطلب دخل مرحلة التنفيذ في المطبخ.");
        }

        // option tables flags
        $hasIsActive = columnExists($pdo, 'global_options', 'is_active');
        $has_go_cat_id = columnExists($pdo, 'global_options', 'category_id');

        // ---- ADD MEAL
        if ($action === 'add_meal') {
            $meal_id = (int)($_POST['meal_id'] ?? 0);
            $cat_id  = (int)($_POST['cat_id'] ?? 0);
            if ($meal_id <= 0 || $cat_id <= 0) throw new Exception("بيانات غير صحيحة: رقم الوجبة/القسم.");

            // daily limit
            $st_day_count = $pdo->prepare("SELECT COUNT(*) FROM daily_selections WHERE client_id=? AND delivery_date=?");
            $st_day_count->execute([$client_id, $action_date]);
            $day_count = (int)$st_day_count->fetchColumn();

            $st_exists = $pdo->prepare("SELECT COUNT(*) FROM daily_selections WHERE client_id=? AND delivery_date=? AND meal_id=?");
            $st_exists->execute([$client_id, $action_date, $meal_id]);
            $already_same = ((int)$st_exists->fetchColumn() > 0);

            if (!$already_same && $client_data['meals_per_day'] > 0 && $day_count >= (int)$client_data['meals_per_day']) {
                throw new Exception("وصلت للحد اليومي المسموح (" . (int)$client_data['meals_per_day'] . " وجبات).");
            }

            // category credit check (package_category_limits + client_category_limits)
            $allowed_in_cat = 0;
            if (tableExists($pdo, 'package_category_limits')) {
                $st_pkg_cat = $pdo->prepare("SELECT COALESCE(allowed_count,0) FROM package_category_limits WHERE package_id=? AND category_id=?");
                $st_pkg_cat->execute([$pkg_id, $cat_id]);
                $allowed_in_cat = (int)$st_pkg_cat->fetchColumn();
            }

            if (tableExists($pdo, 'client_category_limits')) {
                $st_cli_cat = $pdo->prepare("SELECT allowed_count FROM client_category_limits WHERE user_id=? AND category_id=?");
                $st_cli_cat->execute([$client_id, $cat_id]);
                $ov = $st_cli_cat->fetchColumn();
                if ($ov !== false) $allowed_in_cat = (int)$ov;
            }

            if ($allowed_in_cat <= 0) throw new Exception("هذا القسم غير متاح ضمن باقتك.");

            $st_used_in_cat = $pdo->prepare("
                SELECT COUNT(*)
                FROM daily_selections
                WHERE client_id=? AND category_id=? AND delivery_date >= ?
            ");
            $st_used_in_cat->execute([$client_id, $cat_id, $client_data['subscription_start_date']]);
            $used_in_cat = (int)$st_used_in_cat->fetchColumn();
            $remaining_in_cat = $allowed_in_cat - $used_in_cat;

            if (!$already_same && $remaining_in_cat <= 0) throw new Exception("رصيد هذا القسم انتهى. اختر من قسم آخر.");

            // ---- OPTIONS multi select
            $option_ids = [];
            $csv = trim((string)($_POST['option_ids_csv'] ?? ''));
            if ($csv !== '') {
                foreach (preg_split('/\s*,\s*/', $csv) as $x) {
                    $x = (int)$x;
                    if ($x > 0) $option_ids[] = $x;
                }
            } else {
                $single = (int)($_POST['option_id'] ?? 0);
                if ($single > 0) $option_ids[] = $single;
            }
            $option_ids = array_values(array_unique($option_ids));

            // ---- GLOBAL POOL LIMITS & VISIBILITY ----
            $pkgMax = isset($client_data['max_options_allowed']) ? (int)$client_data['max_options_allowed'] : 1;
            $rawOverride = $client_data['max_options_allowed_override'] ?? null;
            
            if ($rawOverride === null || $rawOverride === '') {
                $globalMax = $pkgMax;
            } else {
                $globalMax = (int)$rawOverride;
            }

            // Visibility
            $visibleCatIds = [];
            // 1. From package (package_allowed_categories)
            if (tableExists($pdo, 'package_allowed_categories')) {
                 $hasOpt = columnExists($pdo, 'package_allowed_categories', 'option_category_id');
                 $hasCat = columnExists($pdo, 'package_allowed_categories', 'category_id');
                 if ($hasOpt && $hasCat) {
                     $st = $pdo->prepare("SELECT COALESCE(option_category_id, category_id) AS cid FROM package_allowed_categories WHERE package_id=?");
                 } elseif ($hasOpt) {
                     $st = $pdo->prepare("SELECT option_category_id FROM package_allowed_categories WHERE package_id=?");
                 } else {
                     $st = $pdo->prepare("SELECT category_id FROM package_allowed_categories WHERE package_id=?");
                 }
                 $st->execute([$pkg_id]);
                 $rows = $st->fetchAll(PDO::FETCH_COLUMN);
                 foreach($rows as $r) $visibleCatIds[] = (int)$r;
            } else {
                 // Fallback: use package_option_category_limits if exists
                 if (tableExists($pdo, 'package_option_category_limits')) {
                     $st = $pdo->prepare("SELECT option_category_id FROM package_option_category_limits WHERE package_id=?");
                     $st->execute([$pkg_id]);
                     $rows = $st->fetchAll(PDO::FETCH_COLUMN);
                     foreach($rows as $r) $visibleCatIds[] = (int)$r;
                 }
            }

            // 2. Client Visibility Overrides
            if (tableExists($pdo, 'client_option_category_visibility')) {
                 $st = $pdo->prepare("SELECT option_category_id, is_enabled FROM client_option_category_visibility WHERE user_id=?");
                 $st->execute([$client_id]);
                 foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                     $cid = (int)$r['option_category_id'];
                     if ((int)$r['is_enabled'] === 0) {
                         $visibleCatIds = array_diff($visibleCatIds, [$cid]);
                     }
                 }
            }
            $visibleCatIds = array_map('intval', array_values(array_unique($visibleCatIds)));

            // ---- validate option IDs allowed for this meal
            $validOptRows = [];
            if (!empty($option_ids)) {
                $place = implode(',', array_fill(0, count($option_ids), '?'));
                $params = $option_ids;

                $q = "SELECT go.* FROM global_options go WHERE go.id IN ($place)";
                if ($hasIsActive) $q .= " AND go.is_active=1";
                if ($has_go_cat_id && !empty($visibleCatIds)) {
                    $inCats = implode(',', array_fill(0, count($visibleCatIds), '?'));
                    $q .= " AND go.category_id IN ($inCats)";
                    $params = array_merge($params, $visibleCatIds);
                }

                $st = $pdo->prepare($q);
                $st->execute($params);
                foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
                    $validOptRows[(int)$r['id']] = $r;
                }

                // keep only valid options
                $option_ids = array_values(array_filter($option_ids, fn($id)=> isset($validOptRows[$id])));
            }

            // ---- Enforce Global Pool Limits
            if (count($option_ids) > $globalMax) {
                throw new Exception("تجاوزت الحد الأقصى للخيارات المسموحة لهذه الوجبة (" . $globalMax . ").");
            }

            foreach ($option_ids as $oid) {
                $cid = (int)($validOptRows[$oid]['category_id'] ?? 0);
                if (empty($visibleCatIds)) {
                    throw new Exception("لا توجد تصنيفات إضافات مفعلة لهذه الباقة.");
                }
                if (!in_array($cid, $visibleCatIds, true)) {
                     throw new Exception("اخترت خياراً من تصنيف غير متاح لك.");
                }
            }

            // ---- build option text + macros
            $saveOptionText = "بدون إضافات";
            $optMacros = ['calories'=>0,'protein'=>0,'carbs'=>0,'fat'=>0];
            $labels = [];

            foreach ($option_ids as $oid) {
                $row = $validOptRows[$oid] ?? null;
                if (!$row) continue;

                $name = trim((string)($row['name'] ?? ''));
                if ($name === '') $name = 'إضافة';

                $contr = computeOptionContribution($row, $allowed_weight);
                $labels[] = $name . ($contr['serving']>0 ? (' [' . fmtNum($contr['serving'], 2) . unitShort($contr['unit'] ?? '') . ']') : '');

                $optMacros['calories'] += (float)$contr['calories'];
                $optMacros['protein']  += (float)$contr['protein'];
                $optMacros['carbs']    += (float)$contr['carbs'];
                $optMacros['fat']      += (float)$contr['fat'];
            }
            if (!empty($labels)) $saveOptionText = implode(' + ', $labels);

            $receive_type = (($_POST['receive_type'] ?? 'delivery') === 'pickup') ? 'pickup' : 'delivery';
            $branch_name  = trim((string)($_POST['branch_name'] ?? ''));
            if ($receive_type === 'delivery') $branch_name = '';

            // ensure columns exist
            $has_selected_option_ids = columnExists($pdo, 'daily_selections', 'selected_option_ids');
            if (!$has_selected_option_ids) {
                // keep compatible
                $stmt = $pdo->prepare("
                    REPLACE INTO daily_selections
                    (client_id, delivery_date, meal_id, category_id, selected_weight, selected_option, receive_type, branch_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ok = $stmt->execute([
                    $client_id, $action_date, $meal_id, $cat_id,
                    (string)$allowed_weight,
                    $saveOptionText,
                    $receive_type,
                    $branch_name
                ]);
            } else {
                $stmt = $pdo->prepare("
                    REPLACE INTO daily_selections
                    (client_id, delivery_date, meal_id, category_id, selected_weight, selected_option, selected_option_ids, receive_type, branch_name)
                    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
                ");
                $ok = $stmt->execute([
                    $client_id, $action_date, $meal_id, $cat_id,
                    (string)$allowed_weight,
                    $saveOptionText,
                    (empty($option_ids) ? '' : implode(',', $option_ids)),
                    $receive_type,
                    $branch_name
                ]);
            }
            if (!$ok) throw new Exception("تعذر حفظ الاختيار.");

            $base = getMealBaseMacros($pdo, $meal_id, $allowed_weight);
            $total = sumMacros($base, $optMacros);

            echo json_encode([
                'status' => 'success',
                'message' => 'تم الحفظ بنجاح.',
                'data' => [
                    'meal_id'=>$meal_id,
                    'cat_id'=>$cat_id,
                    'selected_option'=>$saveOptionText,
                    'receive_type'=>$receive_type,
                    'branch_name'=>$branch_name,
                    'base'=>$base,
                    'total'=>$total
                ]
            ], JSON_UNESCAPED_UNICODE);
            exit;
        }

        // ---- REMOVE
        if ($action === 'remove_meal') {
            $meal_id = (int)($_POST['meal_id'] ?? 0);
            if ($meal_id <= 0) throw new Exception("رقم الوجبة غير صحيح.");

            $stmt = $pdo->prepare("DELETE FROM daily_selections WHERE client_id=? AND delivery_date=? AND meal_id=?");
            $stmt->execute([$client_id, $action_date, $meal_id]);

            echo json_encode(['status'=>'success','message'=>'تم الحذف بنجاح.'], JSON_UNESCAPED_UNICODE);
            exit;
        }

        throw new Exception("طلب غير معروف.");
    } catch (Throwable $e) {
        echo json_encode(['status'=>'error','msg'=>$e->getMessage()], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

/* ===========================
   UI (GET)
=========================== */

// cutoff
$cutoff_config_val = '20:00';
try {
    $v = $pdo->query("SELECT setting_value FROM system_settings WHERE setting_key='daily_cutoff_time'")->fetchColumn();
    if ($v) $cutoff_config_val = (string)$v;
} catch (Throwable $e) {}

$graceDays = getGraceDays($pdo);

// load package for UI
$stmt_pkg = $pdo->prepare("
    SELECT p.*, cd.subscription_start_date, cd.subscription_end_date, cd.meals_per_day_override, cd.max_options_allowed_override
    FROM client_details cd
    JOIN packages p ON cd.package_id = p.id
    WHERE cd.user_id = ?
");
$stmt_pkg->execute([$client_id]);
$current_pkg_ui = $stmt_pkg->fetch(PDO::FETCH_ASSOC);

if (!$current_pkg_ui) {
    ?>
    <!DOCTYPE html>
    <html lang="ar" dir="rtl">
    <head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
      <title>تنبيه</title>
      <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
      <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
      <script>
        (function(){
          const saved = (localStorage.getItem('theme') || 'light').toLowerCase();
          document.documentElement.setAttribute('data-theme', saved);
        })();
      </script>
      <style>
        :root { --primary:#6c5ce7; --bg:#f6f7ff; --surface:#fff; --text:#0f172a; --muted:#64748b; }
        [data-theme="dark"] { --bg:#0b1220; --surface:#101a2e; --text:#f8fafc; --muted:#9aa4b2; }
        body { margin:0; background:var(--bg); font-family:'Tajawal',sans-serif; color:var(--text); display:flex; align-items:center; justify-content:center; min-height:100vh; padding:20px; box-sizing:border-box; }
        .errCard { background:var(--surface); padding:40px 30px; border-radius:24px; text-align:center; box-shadow:0 10px 40px rgba(0,0,0,0.08); max-width:400px; width:100%; border:1px solid rgba(127,127,127,0.1); }
        .errIcon { font-size:4rem; color:var(--muted); margin-bottom:20px; opacity:0.5; }
        h2 { margin:0 0 10px; font-weight:900; font-size:1.4rem; }
        p { margin:0 0 25px; color:var(--muted); line-height:1.6; font-size:0.95rem; }
        .btn { display:inline-flex; align-items:center; gap:8px; background:var(--primary); color:#fff; padding:12px 24px; border-radius:14px; text-decoration:none; font-weight:700; transition:0.2s; }
        .btn:active { transform:scale(0.98); opacity:0.9; }
      </style>
    </head>
    <body>
      <div class="errCard">
        <div class="errIcon"><i class="fas fa-box-open"></i></div>
        <h2>لا يوجد اشتراك نشط</h2>
        <p>عذراً، لا نجد اشتراكاً سارياً مرتبطاً بحسابك حالياً. يرجى مراجعة تفاصيل اشتراكك أو التواصل مع الإدارة.</p>
        <a href="client_profile.php" class="btn">
            <i class="fas fa-user-circle"></i>
            الذهاب للملف الشخصي
        </a>
      </div>
    </body>
    </html>
    <?php
    exit;
}

$allowed_weight_ui = safeFloat($current_pkg_ui['allowed_weight'] ?? 0);

// effective meals/day
$effective_meals_per_day_ui = (!empty($current_pkg_ui['meals_per_day_override']) && (int)$current_pkg_ui['meals_per_day_override'] > 0)
    ? (int)$current_pkg_ui['meals_per_day_override']
    : (int)($current_pkg_ui['meals_per_day'] ?? 0);
$current_pkg_ui['meals_per_day'] = $effective_meals_per_day_ui;

// effective max options per meal (global pool)
$effective_max_options_allowed_ui = (int)($current_pkg_ui['max_options_allowed'] ?? 1);
$raw_max_opt_override_ui = $current_pkg_ui['max_options_allowed_override'] ?? null;
if ($raw_max_opt_override_ui !== null && $raw_max_opt_override_ui !== '') {
    $effective_max_options_allowed_ui = (int)$raw_max_opt_override_ui;
}
if ($effective_max_options_allowed_ui < 0) $effective_max_options_allowed_ui = 0;

// date strip
$hour_now = date('H:i');
$day_start_offset = ($hour_now >= $cutoff_config_val) ? 1 : 0;

$ui_navigation_dates = [];
for ($i=0; $i<7; $i++) {
    $offsetDays = $day_start_offset + $i;
    $dt = date('Y-m-d', strtotime("+{$offsetDays} day"));
    $ui_navigation_dates[] = [
        'full' => $dt,
        'day'  => date('l', strtotime($dt)),
        'num'  => date('d', strtotime($dt))
    ];
}
$selected_date = $_GET['date'] ?? $ui_navigation_dates[0]['full'];

// subscription state for UI
$sub_ui = [
  'status' => 'inactive',
  'label'  => 'غير نشط',
  'target_label' => 'متبقي على نهاية الاشتراك',
  'days' => 0,
  'end_date' => null,
  'grace_end_date' => null,
];

$subStart = $current_pkg_ui['subscription_start_date'] ?? null;
$pkgDays  = (int)($current_pkg_ui['duration_days'] ?? 30);
if ($pkgDays <= 0) $pkgDays = 30;

$endDt = null;
$graceEndDt = null;
try {
    if ($subStart) {
        $now = new DateTime();

        if (!empty($current_pkg_ui['subscription_end_date'])) {
            $endDt = new DateTime($current_pkg_ui['subscription_end_date']);
        } else {
            $endDt = (new DateTime($subStart))->modify("+{$pkgDays} days");
        }
        $graceEndDt = (clone $endDt)->modify("+{$graceDays} days");

        $sub_ui['end_date'] = $endDt->format('Y-m-d');
        $sub_ui['grace_end_date'] = $graceEndDt->format('Y-m-d');

        if ($now <= $endDt) {
            $sub_ui['status'] = 'active';
            $sub_ui['label']  = 'نشط';
            $sub_ui['target_label'] = 'متبقي على نهاية الاشتراك';
            $sub_ui['days'] = max(0, (int)$now->diff($endDt)->days);
        } elseif ($now <= $graceEndDt) {
            $sub_ui['status'] = 'grace';
            $sub_ui['label']  = 'إمهال';
            $sub_ui['target_label'] = 'متبقي على نهاية الإمهال';
            $sub_ui['days'] = max(0, (int)$now->diff($graceEndDt)->days);
        } else {
            $sub_ui['status'] = 'expired';
            $sub_ui['label']  = 'منتهي';
            $sub_ui['target_label'] = 'الاشتراك منتهي';
            $sub_ui['days'] = 0;
        }
    }
} catch (Throwable $e) {}

// kitchen/grace lock
$is_view_locked_ui = false;
$lock_reason = '';
if (isKitchenLocked($pdo, $client_id, $selected_date)) {
    $is_view_locked_ui = true;
    $lock_reason = 'kitchen';
}
if (!$is_view_locked_ui && $graceEndDt instanceof DateTime) {
    $selDt = new DateTime($selected_date);
    if ($selDt > $graceEndDt) {
        $is_view_locked_ui = true;
        $lock_reason = 'grace_expired';
    }
}

// branches
$active_branches_ui = [];
try {
    if (tableExists($pdo, 'branches')) {
        $active_branches_ui = $pdo->query("SELECT id, name FROM branches")->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Throwable $e) {}
if (!$active_branches_ui) $active_branches_ui = [['id'=>0,'name'=>'الفرع الرئيسي - الرياض']];

// picks for date
$stmt_picks = $pdo->prepare("SELECT * FROM daily_selections WHERE client_id=? AND delivery_date=?");
$stmt_picks->execute([$client_id, $selected_date]);
$picks_rows = $stmt_picks->fetchAll(PDO::FETCH_ASSOC);

$current_picks_map_ui = [];
$picked_cat_today = [];
foreach ($picks_rows as $r) {
    $mid = (int)($r['meal_id'] ?? 0);
    $cid = (int)($r['category_id'] ?? 0);
    if ($mid > 0) $current_picks_map_ui[$mid] = $r;
    if ($cid > 0) $picked_cat_today[$cid] = true;
}

// option categories names
$has_option_categories = tableExists($pdo, 'option_categories');
$has_go_cat_id = columnExists($pdo, 'global_options', 'category_id');
$has_go_active = columnExists($pdo, 'global_options', 'is_active');

$optionCats = [];
if ($has_option_categories) {
    $rows = $pdo->query("SELECT id, name FROM option_categories WHERE is_active=1 ORDER BY sort_order ASC, id ASC")->fetchAll(PDO::FETCH_ASSOC);
    foreach ($rows as $c) $optionCats[(int)$c['id']] = $c['name'];
} elseif ($has_go_cat_id) {
    $q = "SELECT DISTINCT category_id FROM global_options WHERE category_id IS NOT NULL AND category_id > 0";
    if ($has_go_active) $q .= " AND is_active=1";
    $rows = $pdo->query($q)->fetchAll(PDO::FETCH_COLUMN);
    foreach ($rows as $cid) $optionCats[(int)$cid] = "تصنيف " . (int)$cid;
}

// effective option-category limits for UI
$optcat_limits_eff = [];
$visible_opt_cat_ids_eff = [];
$opt_max_pick = 1; // Default global limit

try {
    // 1. New Logic: Global Quota System
    if (columnExists($pdo, 'packages', 'max_options_allowed')) {
        $opt_max_pick = (int)$effective_max_options_allowed_ui;
    } else {
        $opt_max_pick = (int)($current_pkg_ui['options_selectable_count'] ?? 1);
    }
    if ($opt_max_pick < 0) $opt_max_pick = 0;

    // 2. Fetch Allowed Categories (Visibility)
    $has_new_config = false;
    if (tableExists($pdo, 'package_allowed_categories')) {
        $hasOpt = columnExists($pdo, 'package_allowed_categories', 'option_category_id');
        $hasCat = columnExists($pdo, 'package_allowed_categories', 'category_id');
        if ($hasOpt && $hasCat) {
            $st = $pdo->prepare("SELECT COALESCE(option_category_id, category_id) AS cid FROM package_allowed_categories WHERE package_id=?");
        } elseif ($hasOpt) {
            $st = $pdo->prepare("SELECT option_category_id FROM package_allowed_categories WHERE package_id=?");
        } else {
            $st = $pdo->prepare("SELECT category_id FROM package_allowed_categories WHERE package_id=?");
        }
        $st->execute([(int)$current_pkg_ui['id']]);
        $allowed_cats_db = $st->fetchAll(PDO::FETCH_COLUMN);
        
        if (!empty($allowed_cats_db)) {
            $has_new_config = true;
            foreach ($allowed_cats_db as $cid) $visible_opt_cat_ids_eff[] = (int)$cid;
        }
    }

    // 3. Fallback to Old Logic if no new config found
    if (!$has_new_config) {
        // إذا لم يكن هناك إعدادات جديدة، نعرض جميع الخيارات بشكل افتراضي (للتوافق القديم)
        // ولكن إذا كان الجدول موجوداً وفارغاً (وهو ما يحدث عند إنشاء باقة جديدة)، فقد يخفي كل شيء
        // لذا: إذا لم نجد أي إعدادات، نعتبر كل شيء مسموح (إلا إذا كان هناك قيود قديمة)
        
        if (tableExists($pdo, 'package_option_category_limits')) {
            $st = $pdo->prepare("SELECT option_category_id, allowed_count FROM package_option_category_limits WHERE package_id=?");
            $st->execute([(int)$current_pkg_ui['id']]);
            $old_limits = $st->fetchAll(PDO::FETCH_ASSOC);
            if ($old_limits) {
                 foreach ($old_limits as $r) {
                    $optcat_limits_eff[(int)$r['option_category_id']] = max(0, (int)$r['allowed_count']);
                }
            } else {
                // لا توجد قيود قديمة ولا جديدة -> السماح بالكل
                // نتركه فارغاً هنا، والكود اللاحق سيتعامل معه
            }
        }
        
        // Use old global limit field if exists
        $opt_max_pick = (int)($current_pkg_ui['options_selectable_count'] ?? 1);
    }
    
    $visible_opt_cat_ids_eff = array_values(array_unique(array_filter(array_map('intval', $visible_opt_cat_ids_eff), fn($x)=>$x>0)));

    if (empty($visible_opt_cat_ids_eff) && empty($optcat_limits_eff)) {
        if (!tableExists($pdo, 'package_allowed_categories')) {
            if (!empty($optionCats)) {
                foreach ($optionCats as $cid => $name) $visible_opt_cat_ids_eff[] = (int)$cid;
            }
        }
    }

    // 4. Apply Client Overrides (Visibility/Limits)
    if (tableExists($pdo, 'client_option_category_limits')) {
        $st = $pdo->prepare("SELECT option_category_id, allowed_count FROM client_option_category_limits WHERE user_id=? AND is_enabled=1");
        $st->execute([$client_id]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $cid = (int)$r['option_category_id'];
            if ($cid <= 0) continue;
            if (!in_array($cid, $visible_opt_cat_ids_eff, true)) continue;
            $optcat_limits_eff[$cid] = max(0, (int)$r['allowed_count']);
        }
    }
    if (tableExists($pdo, 'client_option_category_visibility')) {
        $st = $pdo->prepare("SELECT option_category_id, is_enabled FROM client_option_category_visibility WHERE user_id=?");
        $st->execute([$client_id]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $cid = (int)$r['option_category_id'];
            if ((int)$r['is_enabled'] === 0) {
                $visible_opt_cat_ids_eff = array_values(array_diff($visible_opt_cat_ids_eff, [$cid]));
                unset($optcat_limits_eff[$cid]);
            }
        }
    }

    $visible_opt_cat_ids_eff = array_values(array_unique(array_filter(array_map('intval', $visible_opt_cat_ids_eff), fn($x)=>$x>0)));
    if (!empty($visible_opt_cat_ids_eff)) {
        foreach ($visible_opt_cat_ids_eff as $cid) {
            if (!isset($optcat_limits_eff[$cid])) $optcat_limits_eff[$cid] = 99;
        }
        foreach (array_keys($optcat_limits_eff) as $cid) {
            if (!in_array((int)$cid, $visible_opt_cat_ids_eff, true)) unset($optcat_limits_eff[$cid]);
        }
    }

} catch (Throwable $e) {}

$optcat_limits_json = json_encode($optcat_limits_eff, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);
$visible_opt_cat_ids_json = json_encode(array_values($visible_opt_cat_ids_eff), JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES);

// category limits for meals
$cat_limits_map_ui = [];
if (tableExists($pdo, 'package_category_limits')) {
    $st = $pdo->prepare("SELECT category_id, allowed_count FROM package_category_limits WHERE package_id=?");
    $st->execute([(int)$current_pkg_ui['id']]);
    $cat_limits_map_ui = $st->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
}
if (tableExists($pdo, 'client_category_limits')) {
    $st = $pdo->prepare("SELECT category_id, allowed_count FROM client_category_limits WHERE user_id=?");
    $st->execute([$client_id]);
    $ov = $st->fetchAll(PDO::FETCH_KEY_PAIR) ?: [];
    foreach ($ov as $cid => $cnt) $cat_limits_map_ui[$cid] = (int)$cnt;
}
if (!$cat_limits_map_ui) {
    // fallback: show all categories if no mapping
    if (tableExists($pdo, 'categories')) {
        $rows = $pdo->query("SELECT id FROM categories")->fetchAll(PDO::FETCH_COLUMN);
        foreach ($rows as $cid) $cat_limits_map_ui[(int)$cid] = 999999;
    }
}

// total credit label (approx)
$grand_remaining_balance_ui = 0;
try {
    $totalAllowed = 0;
    foreach ($cat_limits_map_ui as $cnt) $totalAllowed += max(0, (int)$cnt);
    $stUsed = $pdo->prepare("SELECT COUNT(*) FROM daily_selections WHERE client_id=? AND delivery_date >= ?");
    $stUsed->execute([$client_id, (string)$current_pkg_ui['subscription_start_date']]);
    $grand_remaining_balance_ui = max(0, $totalAllowed - (int)$stUsed->fetchColumn());
} catch (Throwable $e) { $grand_remaining_balance_ui = 0; }

// build menu
$final_rendered_menu = [];
foreach ($cat_limits_map_ui as $cid_key => $allowed_count) {
    $cid_key = (int)$cid_key;
    $allowed_count = (int)$allowed_count;

    // consumed in this category since subscription start
    $consumed = 0;
    try {
        $st_used = $pdo->prepare("
            SELECT COUNT(*) FROM daily_selections
            WHERE client_id=? AND category_id=? AND delivery_date >= ?
        ");
        $st_used->execute([$client_id, $cid_key, (string)$current_pkg_ui['subscription_start_date']]);
        $consumed = (int)$st_used->fetchColumn();
    } catch (Throwable $e) { $consumed = 0; }

    $remaining = $allowed_count - $consumed;

    // show if remaining or already picked today
    if ($remaining > 0 || isset($picked_cat_today[$cid_key])) {
        $cat_name = 'قسم';
        try {
            if (tableExists($pdo, 'categories')) {
                $st = $pdo->prepare("SELECT name FROM categories WHERE id=?");
                $st->execute([$cid_key]);
                $cat_name = $st->fetchColumn() ?: 'قسم';
            }
        } catch (Throwable $e) {}

        $products = [];
        $p_has_active_ui = false;
        try { $p_has_active_ui = columnExists($pdo, 'products', 'is_active'); } catch (Throwable $e) { $p_has_active_ui = false; }
        try {
            $q = "SELECT * FROM products WHERE category_id=?";
            if ($p_has_active_ui) $q .= " AND is_active=1";
            $stp = $pdo->prepare($q);
            $stp->execute([$cid_key]);
            $products = $stp->fetchAll(PDO::FETCH_ASSOC);
        } catch (Throwable $e) { $products = []; }

        foreach ($products as &$prod) {
            $pid = (int)$prod['id'];
            $base = getMealBaseMacros($pdo, $pid, $allowed_weight_ui);
            $prod['_base_macros'] = $base;

            // load options for meal
            $opts = [];
            try {
                if ($has_go_cat_id && tableExists($pdo, 'package_allowed_categories')) {
                    if (!empty($visible_opt_cat_ids_eff)) {
                        $in = implode(',', array_fill(0, count($visible_opt_cat_ids_eff), '?'));
                        $q = "SELECT go.* FROM global_options go WHERE go.category_id IN ($in)";
                        if ($has_go_active) $q .= " AND go.is_active=1";
                        $q .= " ORDER BY go.category_id ASC, go.id ASC";
                        $st = $pdo->prepare($q);
                        $st->execute($visible_opt_cat_ids_eff);
                    } else {
                        $opts = [];
                        $st = null;
                    }
                } else {
                    $q = "
                        SELECT go.*
                        FROM product_options po
                        JOIN global_options go ON po.global_option_id = go.id
                        WHERE po.product_id = ?
                    ";
                    if ($has_go_active) $q .= " AND go.is_active=1";
                    $st = $pdo->prepare($q);
                    $st->execute([$pid]);
                }
                if ($st) $opts = $st->fetchAll(PDO::FETCH_ASSOC);
            } catch (Throwable $e) { $opts = []; }

            $optPayload = [];
            foreach ($opts as $o) {
                $ocid_tmp = $has_go_cat_id ? (int)($o['category_id'] ?? 0) : 0;

                // enforce UI filter if limits exist
                if (!empty($optcat_limits_eff)) {
                    if ($ocid_tmp <= 0 || !isset($optcat_limits_eff[$ocid_tmp])) continue;
                }

                $contr = computeOptionContribution($o, $allowed_weight_ui);
                $optPayload[] = [
                    'id' => (int)$o['id'],
                    'name' => (string)($o['name'] ?? ''),
                    'unit' => unitShort((string)($o['unit'] ?? '')),
                    'category_id' => $ocid_tmp,
                    'serving' => (float)($contr['serving'] ?? 0),
                    'contr' => [
                        'calories' => (float)($contr['calories'] ?? 0),
                        'protein'  => (float)($contr['protein'] ?? 0),
                        'carbs'    => (float)($contr['carbs'] ?? 0),
                        'fat'      => (float)($contr['fat'] ?? 0),
                    ]
                ];
            }
            $prod['_options_payload'] = $optPayload;

            // compute total macros if selected
            $tot = $base;
            $pick = $current_picks_map_ui[$pid] ?? null;
            if ($pick) {
                $sel_ids_csv = trim((string)($pick['selected_option_ids'] ?? ''));
                $sel_ids = [];
                if ($sel_ids_csv !== '') {
                    foreach (preg_split('/\s*,\s*/', $sel_ids_csv) as $x) {
                        $x = (int)$x;
                        if ($x > 0) $sel_ids[] = $x;
                    }
                    $sel_ids = array_values(array_unique($sel_ids));
                }

                if (!empty($sel_ids)) {
                    $tot = $base;
                    foreach ($optPayload as $op) {
                        if (in_array((int)$op['id'], $sel_ids, true)) {
                            $tot = sumMacros($tot, [
                                'calories'=>$op['contr']['calories'],
                                'protein'=>$op['contr']['protein'],
                                'carbs'=>$op['contr']['carbs'],
                                'fat'=>$op['contr']['fat'],
                            ]);
                        }
                    }
                }
            }

            $prod['_total_macros'] = [
                'calories' => safeFloat($tot['calories'] ?? 0),
                'protein' => safeFloat($tot['protein'] ?? 0),
                'carbs' => safeFloat($tot['carbs'] ?? 0),
                'fat' => safeFloat($tot['fat'] ?? 0),
            ];
        }

        $final_rendered_menu[$cid_key] = [
            'name'  => $cat_name,
            'items' => $products,
            'rem'   => max(0, $remaining)
        ];
    }
}

$arabic_days = [
    'Saturday'=>'السبت','Sunday'=>'الأحد','Monday'=>'الاثنين',
    'Tuesday'=>'الثلاثاء','Wednesday'=>'الأربعاء','Thursday'=>'الخميس','Friday'=>'الجمعة'
];
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,maximum-scale=1,user-scalable=no">
  <title>اختيار الوجبات</title>

  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
  <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
  <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

  <script>
    (function(){
      const saved = (localStorage.getItem('theme') || 'light').toLowerCase();
      const theme = (saved === 'dark') ? 'dark' : 'light';
      document.documentElement.setAttribute('data-theme', theme);
      document.addEventListener('DOMContentLoaded', () => {
        document.body.setAttribute('data-theme', theme);
      });
    })();
  </script>

  <style>
    /* نفس نمطك (مختصر؛ تقدر تستبدله بـ CSS القديم بالكامل بدون مشاكل) */
    :root{
      --primary:#6c5ce7; --primary2:#4b3cff;
      --bg:#f6f7ff; --surface:#fff;
      --text:#0f172a; --muted:#64748b;
      --stroke: rgba(15,23,42,.08);
      --soft: rgba(15,23,42,.04);
      --shadow: 0 14px 40px rgba(15,23,42,.08);
      --ok:#10b981; --danger:#ef4444;
    }
    body[data-theme="dark"]{
      --bg:#0b1220; --surface:#101a2e;
      --text:#f8fafc; --muted:#9aa4b2;
      --stroke: rgba(148,163,184,.14);
      --soft: rgba(148,163,184,.06);
      --shadow: 0 18px 50px rgba(0,0,0,.35);
    }
    *{ box-sizing:border-box; -webkit-tap-highlight-color:transparent; }
    body{
      margin:0; background:var(--bg); font-family:'Tajawal',sans-serif; color:var(--text);
      padding-bottom:118px; overflow-x:hidden;
    }
    .swal2-container{ z-index: 250000 !important; }
    .topbar{ position:sticky; top:0; z-index:7000; padding:16px 16px 12px;
      background: linear-gradient(180deg, var(--bg), rgba(0,0,0,0)); backdrop-filter: blur(10px); }
    .cutoffCard{ background:var(--surface); border:1px solid var(--stroke); border-radius:18px;
      box-shadow:var(--shadow); padding:12px; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .cutoffLeft{ display:flex; align-items:center; gap:10px; font-weight:900; }
    .timer{ font-family: ui-monospace, Menlo, Consolas, monospace; font-weight:900;
      background: rgba(108,92,231,.14); color: var(--primary);
      padding: 8px 12px; border-radius: 14px; border: 1px solid rgba(108,92,231,.20);
      min-width: 108px; text-align:center; }
    .hero{ margin-top:12px; background:var(--surface); border:1px solid var(--stroke); border-radius:24px;
      box-shadow:var(--shadow); padding:14px; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .hero small{ color:var(--muted); font-weight:900; display:block; margin-bottom:6px; }
    .hero b{ font-size:1.6rem; font-weight:900; color:var(--primary); }
    .hero b span{ font-size:.95rem; color:var(--muted); font-weight:900; }
    .dates{ display:flex; gap:10px; overflow-x:auto; padding:12px 2px 2px; scrollbar-width:none; }
    .dates::-webkit-scrollbar{ display:none; }
    .datePill{ min-width:78px; padding:11px 10px; border-radius:18px; border:1px solid var(--stroke);
      background:var(--surface); box-shadow:var(--shadow); text-decoration:none; color:var(--muted); text-align:center; transition:.2s; }
    .datePill b{ display:block; color:var(--text); font-weight:900; font-size:1.02rem; }
    .datePill small{ font-weight:900; font-size:.78rem; }
    .datePill.active{ background: linear-gradient(135deg, var(--primary), var(--primary2)); color:#fff;
      border-color: rgba(255,255,255,.10); transform: translateY(-1px); }
    .datePill.active b{ color:#fff; }

    .catHead{ margin:18px 16px 10px; display:flex; justify-content:space-between; align-items:center; gap:10px; }
    .catTitle{ display:flex; align-items:center; gap:10px; font-weight:900; font-size:1.03rem; }
    .catRem{ padding:7px 12px; border-radius:999px; border:1px solid rgba(108,92,231,.18);
      background: rgba(108,92,231,.12); color: var(--primary); font-weight:900; font-size:.9rem; white-space:nowrap; }
    .mealCard{ margin:12px 16px; background:var(--surface); border:1px solid var(--stroke); border-radius:26px;
      box-shadow:var(--shadow); overflow:hidden; position:relative; }
    .mealTop{ position:relative; z-index:1; display:flex; gap:12px; padding:14px 14px 10px; align-items:center; }
    .mImg{ width:74px; height:74px; border-radius:18px; object-fit:cover; box-shadow: 0 14px 26px rgba(0,0,0,.18);
      border:1px solid rgba(255,255,255,.10); background: var(--soft); }
    .mInfo{ flex:1; min-width:0; }
    .mName{ margin:0 0 6px 0; font-weight:900; font-size:1.03rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .mHint{ color:var(--muted); font-weight:900; font-size:.86rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }

    .mAction{ width:46px; height:46px; border-radius:16px; border:1px solid var(--stroke); cursor:pointer;
      display:flex; align-items:center; justify-content:center; font-size:1.15rem; transition:.2s; background: var(--soft); }
    .btnAdd{ background: rgba(108,92,231,.12); border-color: rgba(108,92,231,.22); color: var(--primary); }
    .btnRemove{ background: rgba(16,185,129,.14); border-color: rgba(16,185,129,.22); color: var(--ok); }

    .nutriStrip{ margin:0 14px 14px; border-radius:18px; border:1px solid var(--stroke);
      background: linear-gradient(135deg, rgba(108,92,231,.08), rgba(15,23,42,0));
      padding:10px; display:grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap:10px; }
    .nutriItem{ border-radius:14px; border:1px solid var(--stroke); background:var(--surface);
      padding:10px; display:flex; align-items:center; justify-content:space-between; gap:10px; }
    .nutriKey{ min-width:44px; padding:7px 10px; border-radius:999px; border:1px solid rgba(108,92,231,.20);
      background: rgba(108,92,231,.10); color: var(--primary); font-weight:1000; font-size:.78rem; }
    .nutriVal{ text-align:left; font-weight:1000; font-size:.98rem; direction:ltr; }

    .sheetOverlay{ position:fixed; inset:0; background: rgba(0,0,0,.45); display:none; align-items:flex-end; justify-content:center;
      z-index:12000; backdrop-filter: blur(10px); }
    .sheet{ width:100%; max-width:820px; background:var(--surface); border-radius:28px 28px 0 0; padding:14px 14px 16px;
      box-shadow: 0 -26px 60px rgba(0,0,0,.30); max-height:92vh; overflow:auto; border:1px solid var(--stroke); border-bottom:none; }
    .sheetTop{ display:flex; align-items:center; justify-content:space-between; gap:10px; margin-bottom:10px; }
    .sheetTitle{ font-weight:900; font-size:1.05rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; max-width:85%; }
    .sheetClose{ width:42px; height:42px; border-radius:14px; border:1px solid var(--stroke); background:var(--soft); cursor:pointer;
      display:flex; align-items:center; justify-content:center; }

    .secTitle{ margin:10px 2px 8px; font-weight:900; color: var(--muted); font-size:.9rem; display:flex; align-items:center; gap:8px; }
    .tabs{ display:flex; gap:10px; background:var(--soft); border:1px solid var(--stroke); padding:6px; border-radius:18px; }
    .tab{ flex:1; text-align:center; padding:12px 10px; border-radius:14px; font-weight:900; cursor:pointer; color:var(--muted); }
    .tab.active{ background:var(--surface); color:var(--primary); border:1px solid rgba(108,92,231,.18);
      box-shadow:0 12px 18px rgba(0,0,0,.06); }
    .branchBox{ display:none; margin-top:8px; }
    .branchBox select{ width:100%; padding:14px 12px; border-radius:16px; border:1px solid var(--stroke); font-weight:900; }

    .optCats{ display:flex; gap:10px; overflow-x:auto; padding:2px 2px 4px; scrollbar-width:none; }
    .optCats::-webkit-scrollbar{ display:none; }
    .optCat{ padding:10px 12px; border-radius:999px; border:1px solid var(--stroke); background:var(--surface); color:var(--muted);
      font-weight:900; white-space:nowrap; cursor:pointer; }
    .optCat.active{ background: linear-gradient(135deg, rgba(108,92,231,.20), rgba(108,92,231,.08));
      border-color: rgba(108,92,231,.28); color: var(--primary); }

    .opts{ display:flex; flex-direction:column; gap:10px; max-height:340px; overflow:auto; padding-right:4px; }
    .optRow{ display:flex; align-items:center; gap:12px; padding:12px; border-radius:18px; border:1px solid var(--stroke);
      background:var(--surface); cursor:pointer; }
    .optRow.active{ border-color: rgba(108,92,231,.35); background: rgba(108,92,231,.06); }
    .optLeft{ flex:1; min-width:0; }
    .optLeft b{ display:block; font-weight:900; font-size:.98rem; white-space:nowrap; overflow:hidden; text-overflow:ellipsis; }
    .optLeft small{ display:flex; gap:10px; flex-wrap:wrap; margin-top:6px; font-weight:900; color:var(--muted); }
    .pill{ padding:5px 10px; border-radius:999px; border:1px solid var(--stroke); background:var(--soft);
      font-size:.78rem; white-space:nowrap; direction:ltr; }
    .pill strong{ color:var(--primary); font-weight:1000; }
    .optIcon{ color:#cbd5e1; font-size:1.15rem; }
    .optRow.active .optIcon{ color:var(--primary); }

    .liveBox{ border-radius:20px; border:1px solid var(--stroke);
      background: linear-gradient(135deg, rgba(16,185,129,.10), rgba(108,92,231,.06)); padding:12px; }
    .liveTitle{ display:flex; align-items:center; justify-content:space-between; gap:10px; font-weight:900; margin-bottom:10px; }
    .liveTitle span{ color:var(--muted); font-size:.9rem; }
    .liveTitle b{ color:var(--primary); }
    .liveRow{ display:grid; grid-template-columns: repeat(4, minmax(0,1fr)); gap:10px; }
    .liveMini{ border-radius:16px; border:1px solid var(--stroke); background:var(--surface); padding:10px; text-align:center; direction:ltr; }
    .liveMini small{ display:block; color:var(--muted); font-weight:900; font-size:.72rem; }
    .liveMini b{ display:block; color:var(--text); font-weight:1000; font-size:1.0rem; margin-top:3px; }

    .confirmBtn{ width:100%; margin-top:12px; padding:14px; border-radius:18px; border:none;
      background: linear-gradient(135deg, var(--primary), var(--primary2)); color:#fff; font-weight:1000; font-size:1.02rem; cursor:pointer; }
    .cancelBtn{ width:100%; margin-top:10px; padding:13px; border-radius:18px; border:1px solid var(--stroke);
      background: var(--soft); color: var(--text); font-weight:1000; cursor:pointer; }

    .lockedBox{ margin:50px 16px; background:var(--surface); box-shadow:var(--shadow); border-radius:26px;
      border:1px solid rgba(239,68,68,.18); padding:26px 18px; text-align:center; }
    .lockedBox i{ color:var(--danger); font-size:3rem; margin-bottom:12px; }
    .lockedBox h2{ margin:0 0 8px; font-weight:900; }
    .lockedBox p{ margin:0; color:var(--muted); font-weight:900; line-height:1.7; }

    @media (max-width:420px){
      .nutriStrip{ grid-template-columns: repeat(2, minmax(0, 1fr)); }
      .liveRow{ grid-template-columns: repeat(2, minmax(0,1fr)); }
    }
  </style>
</head>

<body data-theme="light">

  <div class="topbar">
    <div class="cutoffCard">
      <div class="cutoffLeft">
        <i class="fas fa-clock"></i>
        <span>الإغلاق اليومي: <b><?= date("g:i A", strtotime($cutoff_config_val)) ?></b></span>
      </div>
      <div class="timer" id="uiCountdown">00:00:00</div>
    </div>

    <div style="font-weight:900;color:var(--muted);font-size:.86rem;white-space:nowrap;margin-top:10px;">
      <?= htmlspecialchars($sub_ui['target_label']) ?>:
      <b style="color:var(--text)"><?= (int)$sub_ui['days'] ?></b> يوم
    </div>

    <div class="hero">
      <div>
        <small>إجمالي رصيد وجباتك المتاح</small>
        <b id="uiGrandRemaining"><?= (int)$grand_remaining_balance_ui ?> <span>وجبة</span></b>
      </div>
      <div style="width:46px;height:46px;border-radius:16px;background:rgba(108,92,231,.12);border:1px solid rgba(108,92,231,.18);
                  display:flex;align-items:center;justify-content:center;color:var(--primary);">
        <i class="fas fa-bowl-food"></i>
      </div>
    </div>

    <div class="dates">
      <?php foreach($ui_navigation_dates as $d):
        $active = ($d['full'] === $selected_date) ? 'active' : '';
      ?>
        <a class="datePill <?= $active ?>" href="?date=<?= $d['full'] ?>">
          <small><?= $arabic_days[$d['day']] ?? $d['day'] ?></small>
          <b><?= $d['num'] ?></b>
        </a>
      <?php endforeach; ?>
    </div>
  </div>

  <?php if ($is_view_locked_ui): ?>
    <div class="lockedBox">
      <i class="fas fa-lock"></i>
      <?php if ($lock_reason === 'grace_expired'): ?>
        <h2>انتهت فترة الإمهال</h2>
        <p>لا يمكن اختيار وجبات جديدة بعد نهاية الإمهال (<?= (int)$graceDays ?> يوم بعد نهاية الباقة).<br>الرجاء تجديد الاشتراك.</p>
        <div style="margin-top:14px;">
          <a href="client_browse_packages.php"
             style="display:inline-block;padding:12px 16px;border-radius:16px;background:linear-gradient(135deg,var(--primary),var(--primary2));
                    color:#fff;font-weight:900;text-decoration:none;">
            تجديد الاشتراك
          </a>
        </div>
      <?php else: ?>
        <h2>تم قفل التعديل لهذا اليوم</h2>
        <p>الطلبات دخلت مرحلة التنفيذ، لا يمكن التعديل حالياً.</p>
      <?php endif; ?>
    </div>
  <?php else: ?>

    <?php foreach ($final_rendered_menu as $cid => $cat): ?>
      <div class="catHead">
        <div class="catTitle">
          <i class="fas fa-utensils" style="color:var(--primary)"></i>
          <span><?= htmlspecialchars($cat['name']) ?></span>
        </div>
        <div class="catRem">
          المتبقي: <span><?= (int)$cat['rem'] ?></span>
        </div>
      </div>

      <?php foreach ($cat['items'] as $prod):
        $mealId = (int)$prod['id'];
        $catId  = (int)$cid;
        $isSelected = isset($current_picks_map_ui[$mealId]);

        $base = $prod['_base_macros'] ?? ['calories'=>0,'protein'=>0,'carbs'=>0,'fat'=>0,'weight'=>$allowed_weight_ui,'unit'=>'gram'];
        $total = $prod['_total_macros'] ?? ['calories'=>0,'protein'=>0,'carbs'=>0,'fat'=>0];

        $optionsPayload = $prod['_options_payload'] ?? [];
        $optionsJson = json_encode($optionsPayload, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $baseJson = json_encode([
          'weight'=>$base['weight'] ?? $allowed_weight_ui,
          'unit'=>unitShort($base['unit'] ?? 'gram'),
          'calories'=>$base['calories'] ?? 0,
          'protein'=>$base['protein'] ?? 0,
          'carbs'=>$base['carbs'] ?? 0,
          'fat'=>$base['fat'] ?? 0,
        ], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $totalJson = json_encode($total, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);

        $pick = $isSelected ? $current_picks_map_ui[$mealId] : null;
        $pickedOptText = trim((string)($pick['selected_option'] ?? 'بدون إضافات'));
        if ($pickedOptText === '') $pickedOptText = 'بدون إضافات';
        $pickedReceive = $pick['receive_type'] ?? 'delivery';
        $pickedBranch = trim((string)($pick['branch_name'] ?? ''));
      ?>
        <div class="mealCard"
             data-meal-id="<?= $mealId ?>"
             data-cat-id="<?= $catId ?>"
             data-meal-name="<?= htmlspecialchars($prod['name'], ENT_QUOTES, 'UTF-8') ?>"
             data-options='<?= htmlspecialchars($optionsJson, ENT_QUOTES, 'UTF-8') ?>'
             data-base='<?= htmlspecialchars($baseJson, ENT_QUOTES, 'UTF-8') ?>'
             data-total='<?= htmlspecialchars($totalJson, ENT_QUOTES, 'UTF-8') ?>'>

          <div class="mealTop">
            <img class="mImg"
                 src="uploads/<?= htmlspecialchars($prod['image'] ?? ($prod['image_url'] ?? ''), ENT_QUOTES, 'UTF-8') ?>"
                 onerror="this.src='https://placehold.co/200x200'">

            <div class="mInfo">
              <div class="mName"><?= htmlspecialchars($prod['name']) ?></div>
              <div class="mHint"><?= $isSelected ? 'تم اختيار الوجبة لهذا اليوم' : 'اختر الوجبة ثم حدّد الإضافة والاستلام' ?></div>
            </div>

            <?php if ($isSelected): ?>
              <button class="mAction btnRemove" onclick="handleOp(<?= $mealId ?>,'remove',<?= $catId ?>)" title="إزالة">
                <i class="fas fa-check"></i>
              </button>
            <?php else: ?>
              <button class="mAction btnAdd" onclick="openSheetFromCard(<?= $mealId ?>)" title="اختيار">
                <i class="fas fa-plus"></i>
              </button>
            <?php endif; ?>
          </div>

          <div class="nutriStrip">
            <?php
              $show = $isSelected ? $total : $base;
              $cal = safeFloat($show['calories'] ?? 0);
              $pro = safeFloat($show['protein'] ?? 0);
              $car = safeFloat($show['carbs'] ?? 0);
              $fat = safeFloat($show['fat'] ?? 0);
            ?>
            <div class="nutriItem"><span class="nutriKey">CAL</span><div class="nutriVal"><?= fmtNum($cal,0) ?></div></div>
            <div class="nutriItem"><span class="nutriKey">P</span><div class="nutriVal"><?= fmtNum($pro,1) ?></div></div>
            <div class="nutriItem"><span class="nutriKey">C</span><div class="nutriVal"><?= fmtNum($car,1) ?></div></div>
            <div class="nutriItem"><span class="nutriKey">F</span><div class="nutriVal"><?= fmtNum($fat,1) ?></div></div>
          </div>

          <?php if ($isSelected): ?>
            <div style="margin:0 14px 14px;border-radius:18px;border:1px solid rgba(16,185,129,.20);
                        background: linear-gradient(135deg, rgba(16,185,129,.14), rgba(108,92,231,.08)); padding:12px;">
              <div style="display:flex;align-items:center;gap:8px;font-weight:900;color:var(--ok);margin-bottom:10px;">
                <i class="fas fa-circle-check"></i> تفاصيل اختيارك
              </div>
              <div style="display:flex;flex-wrap:wrap;gap:10px;">
                <span style="display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:var(--surface);
                             border:1px solid var(--stroke);font-weight:900;font-size:.88rem;"><?= htmlspecialchars($pickedOptText) ?></span>
                <?php if ($pickedReceive === 'delivery'): ?>
                  <span style="display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:var(--surface);
                               border:1px solid var(--stroke);font-weight:900;font-size:.88rem;">توصيل</span>
                <?php else: ?>
                  <span style="display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:var(--surface);
                               border:1px solid var(--stroke);font-weight:900;font-size:.88rem;">استلام</span>
                  <?php if ($pickedBranch !== ''): ?>
                    <span style="display:inline-flex;align-items:center;gap:8px;padding:9px 12px;border-radius:999px;background:var(--surface);
                                 border:1px solid var(--stroke);font-weight:900;font-size:.88rem;"><?= htmlspecialchars($pickedBranch) ?></span>
                  <?php endif; ?>
                <?php endif; ?>
              </div>
            </div>
          <?php else: ?>
            <div style="margin:0 14px 14px;border-radius:18px;padding:10px 12px;border:1px solid rgba(108,92,231,.20);
                        background: linear-gradient(135deg, rgba(108,92,231,.16), rgba(16,185,129,.08));display:flex;justify-content:space-between;gap:10px;">
              <div style="display:flex;align-items:center;gap:10px;font-weight:900;">
                <span style="padding:6px 10px;border-radius:999px;background:rgba(255,255,255,.70);border:1px solid rgba(255,255,255,.30);font-size:.82rem;">
                  وزن الباقة
                </span>
                <div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;">
                  <?= fmtNum($base['weight'] ?? $allowed_weight_ui, 2) . unitShort($base['unit'] ?? 'gram') ?>
                </div>
              </div>
            </div>
          <?php endif; ?>

        </div>
      <?php endforeach; ?>
    <?php endforeach; ?>

  <?php endif; ?>

  <!-- Bottom Sheet -->
  <div id="sheetOverlay" class="sheetOverlay" onclick="if(event.target===this)closeSheet()">
    <div class="sheet">
      <div class="sheetTop">
        <div class="sheetTitle" id="sheetTitle">اختيار</div>
        <div class="sheetClose" onclick="closeSheet()"><i class="fas fa-xmark"></i></div>
      </div>

      <div>
        <div class="secTitle"><i class="fas fa-truck-ramp-box"></i> طريقة الاستلام</div>
        <div class="tabs">
          <div class="tab active" id="tabDelivery" onclick="setReceive('delivery')">توصيل</div>
          <div class="tab" id="tabPickup" onclick="setReceive('pickup')">استلام</div>
        </div>

        <div class="branchBox" id="branchBox">
          <div class="secTitle"><i class="fas fa-location-dot"></i> اختر الفرع</div>
          <select id="branchSelect">
            <?php foreach($active_branches_ui as $b): ?>
              <option value="<?= htmlspecialchars($b['name'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars($b['name']) ?></option>
            <?php endforeach; ?>
          </select>
        </div>
      </div>

      <div class="liveBox" style="margin-top:12px;">
        <div class="liveTitle">
          <div style="display:flex;align-items:center;gap:8px;">
            <i class="fas fa-chart-simple" style="color:var(--primary)"></i>
            <b>الإجمالي النهائي</b>
            <span id="liveHint">الوجبة الأساسية</span>
          </div>
          <span id="liveServing"></span>
        </div>
        <div class="liveRow">
          <div class="liveMini"><small>CAL</small><b id="liveCal">0</b></div>
          <div class="liveMini"><small>P</small><b id="livePro">0</b></div>
          <div class="liveMini"><small>C</small><b id="liveCar">0</b></div>
          <div class="liveMini"><small>F</small><b id="liveFat">0</b></div>
        </div>
      </div>

      <div style="margin-top:12px;">
        <div class="secTitle"><i class="fas fa-layer-group"></i> تصنيفات الإضافات</div>
        <div class="optCats" id="optCats"></div>

        <div class="secTitle"><i class="fas fa-list-check"></i> الإضافات</div>
        <div class="opts" id="optsBox"></div>

        <button class="confirmBtn" onclick="handleOp(0,'add')">تأكيد وحفظ</button>
        <button class="cancelBtn" onclick="closeSheet()">إلغاء</button>
      </div>

      <input type="hidden" id="hMeal">
      <input type="hidden" id="hCat">
      <input type="hidden" id="hReceive" value="delivery">
      <input type="hidden" id="hOptIds" value="">
      <input type="hidden" id="hBaseJson">
      <input type="hidden" id="hOptsJson">

      <input type="hidden" id="hOptCatLimitsJson" value='<?= htmlspecialchars($optcat_limits_json ?: "{}", ENT_QUOTES, "UTF-8") ?>'>
      <input type="hidden" id="hOptVisibleCatsJson" value='<?= htmlspecialchars($visible_opt_cat_ids_json ?: "[]", ENT_QUOTES, "UTF-8") ?>'>
      <input type="hidden" id="hOptMaxPick" value="<?= (int)$opt_max_pick ?>">
      <input type="hidden" id="hOptCatsJson" value='<?= htmlspecialchars(json_encode($optionCats, JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES), ENT_QUOTES, "UTF-8") ?>'>
    </div>
  </div>

  <?php include 'client_footer_nav.php'; ?>

<script>
  const UI_DATE = "<?= $selected_date ?>";
  const UI_CUTOFF = "<?= $cutoff_config_val ?>";

  function toast(msg){
    Swal.fire({toast:true,position:'top',showConfirmButton:false,timer:2200,icon:'info',title:msg});
  }

  const MAX_OPT_PICK = parseInt(document.getElementById('hOptMaxPick').value || '1', 10) || 1;
  let ALLOWED_OPT_CATS = {};
  try { ALLOWED_OPT_CATS = JSON.parse(document.getElementById('hOptCatLimitsJson').value || '{}') || {}; } catch(e){ ALLOWED_OPT_CATS = {}; }
  let VISIBLE_OPT_CATS = [];
  try { VISIBLE_OPT_CATS = JSON.parse(document.getElementById('hOptVisibleCatsJson').value || '[]') || []; } catch(e){ VISIBLE_OPT_CATS = []; }

  function escHtml(s){
    return String(s)
      .replaceAll('&','&amp;')
      .replaceAll('<','&lt;')
      .replaceAll('>','&gt;')
      .replaceAll('"','&quot;')
      .replaceAll("'","&#039;");
  }
  function n(v){ v = parseFloat(v); return isNaN(v) ? 0 : v; }
  function fmt(v, dec=1){
    v = n(v);
    if (Math.abs(v - Math.round(v)) < 0.00001) return String(Math.round(v));
    return (v.toFixed(dec)).replace(/\.0+$/,'').replace(/(\.\d*[1-9])0+$/,'$1');
  }

  let SHEET_OPTS = [];
  let SHEET_BASE = {calories:0,protein:0,carbs:0,fat:0,weight:0,unit:''};
  let SHEET_CATS = {};
  let ACTIVE_CAT = 0;

  function openSheetFromCard(mealId){
    const card = document.querySelector(`.mealCard[data-meal-id="${mealId}"]`);
    if(!card) return;

    const mealName = card.getAttribute('data-meal-name') || '';
    const catId = card.getAttribute('data-cat-id') || '0';

    let opts = [];
    let base = {};
    try { opts = JSON.parse(card.getAttribute('data-options') || '[]'); } catch(e){ opts=[]; }
    try { base = JSON.parse(card.getAttribute('data-base') || '{}'); } catch(e){ base={}; }

    SHEET_OPTS = Array.isArray(opts) ? opts : [];
    SHEET_BASE = base || {};

    document.getElementById('hBaseJson').value = JSON.stringify(SHEET_BASE);
    document.getElementById('hOptsJson').value = JSON.stringify(SHEET_OPTS);

    try { SHEET_CATS = JSON.parse(document.getElementById('hOptCatsJson').value || '{}') || {}; } catch(e){ SHEET_CATS = {}; }

    document.getElementById('sheetTitle').innerText = mealName;
    document.getElementById('hMeal').value = String(mealId);
    document.getElementById('hCat').value = String(catId);

    setReceive('delivery');
    setSelectedOptIds([]);          // ✅ بدل setOption غير الموجودة
    ACTIVE_CAT = 0;

    renderOptCats();
    renderOptionsByCat(ACTIVE_CAT);
    updateLiveTotals();

    $('#sheetOverlay').fadeIn(180).css('display','flex');
  }

  function closeSheet(){ $('#sheetOverlay').fadeOut(150); }

  function setReceive(mode){
    const m = (mode === 'pickup') ? 'pickup' : 'delivery';
    document.getElementById('hReceive').value = m;

    document.getElementById('tabDelivery').classList.remove('active');
    document.getElementById('tabPickup').classList.remove('active');

    if(m === 'delivery'){
      document.getElementById('tabDelivery').classList.add('active');
      $('#branchBox').slideUp(150);
    }else{
      document.getElementById('tabPickup').classList.add('active');
      $('#branchBox').slideDown(150);
    }
  }

  function renderOptCats(){
    let realCats = [];
    if (Array.isArray(VISIBLE_OPT_CATS) && VISIBLE_OPT_CATS.length) {
      realCats = Array.from(new Set(VISIBLE_OPT_CATS.map(x=>parseInt(x,10)).filter(x=>x>0))).sort((a,b)=>a-b);
    } else if (Object.keys(ALLOWED_OPT_CATS || {}).length) {
      const ids = [];
      for (const k in ALLOWED_OPT_CATS) {
        const cid = parseInt(k, 10) || 0;
        if (cid > 0) ids.push(cid);
      }
      realCats = Array.from(new Set(ids)).sort((a,b)=>a-b);
    } else {
      const set = new Set();
      for(const o of SHEET_OPTS){
        const cid = parseInt(o.category_id || 0, 10) || 0;
        if(cid>0) set.add(cid);
      }
      realCats = Array.from(set).sort((a,b)=>a-b);
    }

    let html = '';
    for(const cid of realCats){
      const name = (SHEET_CATS && SHEET_CATS[cid]) ? SHEET_CATS[cid] : (`تصنيف ${cid}`);
      html += `<div class="optCat ${ACTIVE_CAT===cid?'active':''}" onclick="setActiveCat(${cid})">${escHtml(name)}</div>`;
    }
    if(!html){
      ACTIVE_CAT = 0;
      html = `<div class="optCat active" onclick="setActiveCat(0)">الإضافات</div>`;
    } else if (ACTIVE_CAT === 0 || !realCats.includes(ACTIVE_CAT)) {
      ACTIVE_CAT = (realCats[0] || 0);
    }
    document.getElementById('optCats').innerHTML = html;
  }

  function setActiveCat(cid){
    ACTIVE_CAT = cid;
    document.querySelectorAll('#optCats .optCat').forEach(el=>el.classList.remove('active'));
    document.querySelectorAll('#optCats .optCat').forEach(el=>{
      const oc = el.getAttribute('onclick') || '';
      if (cid === -1 && el.textContent.trim() === 'الكل') el.classList.add('active');
      else if (oc === `setActiveCat(${cid})`) el.classList.add('active');
    });
    renderOptionsByCat(ACTIVE_CAT);
  }

  function renderOptionsByCat(catId){
    let html = '';
    html += `
      <div class="optRow ${getSelectedOptIds().length===0?'active':''}" data-opt="0" onclick="toggleOption('0')">
        <div class="optLeft"><b>بدون إضافات</b></div>
        <div class="optIcon"><i class="fas fa-check-circle"></i></div>
      </div>
    `;

    const list = [];
    for(const o of SHEET_OPTS){
      const cid = parseInt(o.category_id || 0, 10) || 0;

      if(Object.keys(ALLOWED_OPT_CATS||{}).length){
        if(cid<=0) continue;
        if(!(ALLOWED_OPT_CATS[String(cid)] !== undefined || ALLOWED_OPT_CATS[cid] !== undefined)) continue;
      }

      if(catId === -1) list.push(o);
      else if(catId === 0) list.push(o);
      else if(cid === catId) list.push(o);
    }

    if (catId > 0 && list.length === 0) {
      html += `
        <div class="optRow" style="opacity:.65; pointer-events:none;">
          <div class="optLeft"><b>لا توجد خيارات في هذا التصنيف لهذه الوجبة</b></div>
        </div>
      `;
    }

    const selectedIds = new Set(getSelectedOptIds());
    for(const o of list){
      const id = parseInt(o.id || 0, 10) || 0;
      const name = o.name || '';
      const unit = o.unit || '';
      const serving = n(o.serving || 0);
      const contr = o.contr || {};
      const ccal = n(contr.calories), cpro = n(contr.protein), ccar = n(contr.carbs), cfat = n(contr.fat);
      const servingTxt = serving > 0 ? `${fmt(serving,2)}${escHtml(unit)}` : '';
      const isActive = selectedIds.has(id);

      html += `
        <div class="optRow ${isActive?'active':''}" data-opt="${id}" onclick="toggleOption('${id}')">
          <div class="optLeft">
            <b>${escHtml(name)}</b>
            <small>
              ${servingTxt ? `<span class="pill"><strong>Serving</strong> ${servingTxt}</span>` : ``}
              <span class="pill"><strong>+CAL</strong> ${fmt(ccal,0)}</span>
              <span class="pill"><strong>+P</strong> ${fmt(cpro,1)}</span>
              <span class="pill"><strong>+C</strong> ${fmt(ccar,1)}</span>
              <span class="pill"><strong>+F</strong> ${fmt(cfat,1)}</span>
            </small>
          </div>
          <div class="optIcon"><i class="fas fa-check-circle"></i></div>
        </div>
      `;
    }

    document.getElementById('optsBox').innerHTML = html;
  }

  function getSelectedOptIds(){
    const v = (document.getElementById('hOptIds').value || '').trim();
    if(!v) return [];
    return v.split(',').map(x=>parseInt(x,10)).filter(x=>x>0);
  }
  function setSelectedOptIds(arr){
    const uniq = Array.from(new Set(arr.map(x=>parseInt(x,10)).filter(x=>x>0)));
    document.getElementById('hOptIds').value = uniq.join(',');
  }

  function toggleOption(optId){
    optId = parseInt(optId,10) || 0;
    const cur = getSelectedOptIds();
    const idx = cur.indexOf(optId);

    if(optId === 0){
      setSelectedOptIds([]);
      renderOptionsByCat(ACTIVE_CAT);
      updateLiveTotals();
      return;
    }

    if(idx >= 0){
      cur.splice(idx,1);
      setSelectedOptIds(cur);
    } else {
      // UX Enhancement: If Max is 1, replace instead of block
      if(MAX_OPT_PICK === 1 && cur.length >= 1) {
         cur = [optId]; // Replace
         setSelectedOptIds(cur);
      } else if(MAX_OPT_PICK > 0 && cur.length >= MAX_OPT_PICK){
        toast(`الحد الأقصى للإضافات: ${MAX_OPT_PICK}`);
        return;
      } else {
        cur.push(optId);
        setSelectedOptIds(cur);
      }
    }

    renderOptionsByCat(ACTIVE_CAT);
    updateLiveTotals();
  }

  function findOpt(optId){
    optId = String(optId);
    for(const o of SHEET_OPTS){
      if(String(o.id) === optId) return o;
    }
    return null;
  }

  function updateLiveTotals(){
    const base = SHEET_BASE || {};
    let cal = n(base.calories), pro = n(base.protein), car = n(base.carbs), fat = n(base.fat);

    const sel = getSelectedOptIds();
    const hint = sel.length ? 'الوجبة + الإضافات' : 'الوجبة الأساسية';
    let servingParts = [];

    for(const id of sel){
      const o = findOpt(String(id));
      if(!o) continue;
      const contr = o.contr || {};
      cal += n(contr.calories);
      pro += n(contr.protein);
      car += n(contr.carbs);
      fat += n(contr.fat);
      const s = n(o.serving || 0);
      if(s > 0) servingParts.push(`${fmt(s,2)}${o.unit||''}`);
    }

    document.getElementById('liveHint').textContent = hint;
    document.getElementById('liveCal').textContent = fmt(cal,0);
    document.getElementById('livePro').textContent = fmt(pro,1);
    document.getElementById('liveCar').textContent = fmt(car,1);
    document.getElementById('liveFat').textContent = fmt(fat,1);
    document.getElementById('liveServing').textContent = servingParts.length ? `Serving: ${servingParts.join(' + ')}` : '';
  }

  function handleOp(mealId, mode, catId){
    const action = (mode === 'remove') ? 'remove_meal' : 'add_meal';
    const mid = (mode === 'remove') ? mealId : (parseInt(document.getElementById('hMeal').value||'0',10)||0);
    const cid = (mode === 'remove') ? catId : (parseInt(document.getElementById('hCat').value||'0',10)||0);

    if(action==='add_meal' && (!mid || !cid)){
      toast('اختر الوجبة أولاً');
      return;
    }

    const receiveType = document.getElementById('hReceive').value || 'delivery';
    const branchName = (receiveType==='pickup') ? (document.getElementById('branchSelect').value||'') : '';
    const optCsv = (document.getElementById('hOptIds').value || '').trim();

    $.post('client_select_meals.php', {
      ajax_action: action,
      date: UI_DATE,
      meal_id: mid,
      cat_id: cid,
      option_ids_csv: optCsv,
      receive_type: receiveType,
      branch_name: branchName
    }, function(res){
      if(res && res.status==='success'){
        closeSheet();
        // أبسط تحديث: reload
        location.reload();
      }else{
        Swal.fire('خطأ', (res && (res.msg||res.message)) ? (res.msg||res.message) : 'تعذر الحفظ', 'error');
      }
    }, 'json').fail(function(){
      Swal.fire('خطأ', 'فشل الاتصال بالسيرفر أو يوجد خطأ PHP (راجع error logs)', 'error');
    });
  }

  // Optional: countdown timer (UI)
  function startCountdown(){
    const cutoff = UI_CUTOFF || '20:00';
    const [hh,mm] = cutoff.split(':').map(x=>parseInt(x,10)||0);
    const now = new Date();
    const end = new Date(now.getFullYear(), now.getMonth(), now.getDate(), hh, mm, 0);
    let diff = Math.floor((end.getTime() - now.getTime()) / 1000);
    if(diff < 0) diff = 0;

    const el = document.getElementById('uiCountdown');
    function tick(){
      let d = diff;
      const h = Math.floor(d/3600); d%=3600;
      const m = Math.floor(d/60); const s = d%60;
      if(el) el.textContent = String(h).padStart(2,'0')+":"+String(m).padStart(2,'0')+":"+String(s).padStart(2,'0');
      if(diff>0){ diff--; setTimeout(tick,1000); }
    }
    tick();
  }
  startCountdown();
</script>

</body>
</html>
