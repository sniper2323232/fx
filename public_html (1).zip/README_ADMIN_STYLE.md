# دليل توحيد ستايل صفحات المدير

## 📋 نظرة عامة
تم إنشاء ملف CSS موحد (`admin-unified-style.css`) لضمان تصميم عصرية ومتسقة لجميع صفحات المدير.

## 🚀 كيفية الاستخدام

### 1. إضافة الملف إلى صفحة المدير

أضف السطور التالية في `<head>` من أي صفحة مدير:

```html
<link rel="stylesheet" href="style.css">
<link rel="stylesheet" href="admin-unified-style.css">
<link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
```

### 2. استخدام الكلاسات

#### البطاقات (Cards)
```html
<div class="admin-card">
    <div class="admin-card-header">
        <h3><i class="fas fa-box"></i> عنوان البطاقة</h3>
    </div>
    <div>
        محتوى البطاقة
    </div>
</div>
```

#### الأزرار (Buttons)
```html
<button class="admin-btn admin-btn-primary">
    <i class="fas fa-save"></i> حفظ
</button>

<a href="#" class="admin-btn admin-btn-secondary">إلغاء</a>
<a href="#" class="admin-btn admin-btn-danger admin-btn-sm">حذف</a>
```

#### النماذج (Forms)
```html
<div class="admin-form-group">
    <label class="admin-form-label">اسم الحقل</label>
    <input type="text" class="admin-form-input" placeholder="أدخل النص">
</div>

<div class="admin-form-group">
    <label class="admin-form-label">الوصف</label>
    <textarea class="admin-form-textarea"></textarea>
</div>
```

#### الجداول (Tables)
```html
<div class="admin-table-wrapper">
    <table class="admin-table">
        <thead>
            <tr>
                <th>العمود الأول</th>
                <th>العمود الثاني</th>
            </tr>
        </thead>
        <tbody>
            <tr>
                <td>قيمة 1</td>
                <td>قيمة 2</td>
            </tr>
        </tbody>
    </table>
</div>
```

#### الشارات (Badges)
```html
<span class="admin-badge admin-badge-success">
    <i class="fas fa-check"></i> نشط
</span>
<span class="admin-badge admin-badge-warning">تحذير</span>
<span class="admin-badge admin-badge-danger">خطر</span>
```

#### بطاقات الإحصائيات (Stats Cards)
```html
<div class="admin-stats-grid">
    <div class="admin-stat-card">
        <div class="admin-stat-icon">
            <i class="fas fa-users"></i>
        </div>
        <div class="admin-stat-info">
            <span class="value">125</span>
            <span class="label">عدد العملاء</span>
        </div>
    </div>
</div>
```

#### التنبيهات (Alerts)
```html
<div class="admin-alert admin-alert-success">
    <i class="fas fa-check-circle"></i>
    تم الحفظ بنجاح
</div>

<div class="admin-alert admin-alert-danger">
    <i class="fas fa-exclamation-triangle"></i>
    حدث خطأ
</div>
```

#### الهيدر (Header)
```html
<div class="admin-header">
    <h1><i class="fas fa-dashboard"></i> لوحة التحكم</h1>
    <div class="admin-flex admin-gap-sm">
        <a href="#" class="admin-btn admin-btn-secondary">رجوع</a>
        <button class="admin-btn admin-btn-primary">حفظ</button>
    </div>
</div>
```

#### الحاوية الرئيسية
```html
<div class="admin-container">
    <!-- محتوى الصفحة -->
</div>
```

## 🎨 الألوان المتاحة

الملف يحتوي على متغيرات CSS يمكن تعديلها حسب الحاجة:

- `--admin-primary`: اللون الأساسي (#6c5ce7)
- `--admin-success`: اللون الأخضر (#10b981)
- `--admin-warning`: اللون البرتقالي (#f59e0b)
- `--admin-danger`: اللون الأحمر (#ef4444)
- `--admin-info`: اللون الأزرق (#3b82f6)

## 📱 التجاوب

التصميم متجاوب بالكامل ويتكيف مع جميع أحجام الشاشات.

## ✅ صفحات تم تطبيق التصميم عليها

- [x] admin_dashboard.php (مثال)

## 📝 ملاحظات

1. الملف متوافق مع `style.css` الموجود
2. يمكن استخدام الكلاسات الجديدة مع الكلاسات القديمة
3. التصميم يستخدم خط Tajawal العربي

## 🔧 التخصيص

يمكنك تعديل الألوان والأحجام في بداية ملف `admin-unified-style.css`:

```css
:root {
    --admin-primary: #6c5ce7; /* يمكن تغييره */
    --admin-radius-md: 16px;  /* يمكن تغييره */
    /* ... إلخ */
}
```


