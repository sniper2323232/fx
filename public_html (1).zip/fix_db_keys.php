<?php
// fix_db_keys.php - Auto-fix missing database keys and indexes
header('Content-Type: application/json; charset=utf-8');

require_once 'db_connect.php';

$result = [
    'ok' => true,
    'applied_fixes' => [],
    'skipped' => [],
    'errors' => []
];

// Fix 1: Add PRIMARY KEY to notifications if missing
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Key_name = 'PRIMARY'");
    if (!$st->fetch()) {
        try {
            $pdo->exec("ALTER TABLE `notifications` ADD PRIMARY KEY (`id`)");
            $result['applied_fixes'][] = 'PRIMARY KEY على notifications.id';
        } catch (Exception $e) {
            $result['errors'][] = 'Failed to add PRIMARY KEY: ' . $e->getMessage();
        }
    } else {
        $result['skipped'][] = 'PRIMARY KEY على notifications موجود بالفعل';
    }
} catch (Exception $e) {
    $result['errors'][] = 'Check PRIMARY KEY: ' . $e->getMessage();
}

// Fix 2: Set AUTO_INCREMENT on notifications.id
try {
    $st = $pdo->query("SELECT AUTO_INCREMENT FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'notifications'");
    $row = $st->fetch(PDO::FETCH_ASSOC);
    if (!$row || !$row['AUTO_INCREMENT']) {
        try {
            $pdo->exec("ALTER TABLE `notifications` MODIFY `id` int(11) NOT NULL AUTO_INCREMENT");
            $result['applied_fixes'][] = 'AUTO_INCREMENT على notifications.id';
        } catch (Exception $e) {
            $result['errors'][] = 'Failed to set AUTO_INCREMENT: ' . $e->getMessage();
        }
    } else {
        $result['skipped'][] = 'AUTO_INCREMENT على notifications موجود بالفعل';
    }
} catch (Exception $e) {
    $result['errors'][] = 'Check AUTO_INCREMENT: ' . $e->getMessage();
}

// Fix 3: Add PRIMARY KEY to user_notification_state if missing
try {
    $st = $pdo->query("SHOW KEYS FROM user_notification_state WHERE Key_name = 'PRIMARY'");
    if (!$st->fetch()) {
        try {
            $pdo->exec("ALTER TABLE `user_notification_state` ADD PRIMARY KEY (`user_id`)");
            $result['applied_fixes'][] = 'PRIMARY KEY على user_notification_state.user_id';
        } catch (Exception $e) {
            $result['errors'][] = 'Failed to add PRIMARY KEY to user_notification_state: ' . $e->getMessage();
        }
    } else {
        $result['skipped'][] = 'PRIMARY KEY على user_notification_state موجود بالفعل';
    }
} catch (Exception $e) {
    $result['errors'][] = 'Check user_notification_state PRIMARY KEY: ' . $e->getMessage();
}

// Fix 4: Add INDEX on notifications.client_id if missing
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Column_name = 'client_id' AND Key_name != 'PRIMARY'");
    if (!$st->fetch()) {
        try {
            $pdo->exec("ALTER TABLE `notifications` ADD INDEX idx_client_id (client_id)");
            $result['applied_fixes'][] = 'INDEX على notifications.client_id';
        } catch (Exception $e) {
            // قد تكون الفهرسة موجودة بتسمية أخرى
            $result['skipped'][] = 'INDEX على client_id: ' . $e->getMessage();
        }
    } else {
        $result['skipped'][] = 'INDEX على notifications.client_id موجود بالفعل';
    }
} catch (Exception $e) {
    $result['errors'][] = 'Check client_id INDEX: ' . $e->getMessage();
}

// Fix 5: Add INDEX on notifications.created_at if missing
try {
    $st = $pdo->query("SHOW KEYS FROM notifications WHERE Column_name = 'created_at'");
    if (!$st->fetch()) {
        try {
            $pdo->exec("ALTER TABLE `notifications` ADD INDEX idx_created_at (created_at)");
            $result['applied_fixes'][] = 'INDEX على notifications.created_at';
        } catch (Exception $e) {
            $result['skipped'][] = 'INDEX على created_at: ' . $e->getMessage();
        }
    } else {
        $result['skipped'][] = 'INDEX على notifications.created_at موجود بالفعل';
    }
} catch (Exception $e) {
    $result['errors'][] = 'Check created_at INDEX: ' . $e->getMessage();
}

// Summary
$result['summary'] = [
    'fixes_applied' => count($result['applied_fixes']),
    'already_existed' => count($result['skipped']),
    'errors' => count($result['errors'])
];

if (count($result['errors']) > 0) {
    $result['ok'] = false;
}

echo json_encode($result, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
?>
