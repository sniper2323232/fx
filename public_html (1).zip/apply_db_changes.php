<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>تحديث قاعدة البيانات</title>
    <style>
        body { font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif; background: #f3f4f6; padding: 20px; text-align: center; }
        .container { max-width: 600px; margin: 0 auto; background: white; padding: 30px; border-radius: 10px; box-shadow: 0 4px 6px rgba(0,0,0,0.1); }
        h1 { color: #d97706; margin-bottom: 20px; }
        .log { text-align: right; background: #1e293b; color: #10b981; padding: 15px; border-radius: 5px; font-family: monospace; overflow-x: auto; margin-bottom: 20px; }
        .error { color: #ef4444; }
        .success { color: #10b981; font-weight: bold; }
        .btn { display: inline-block; padding: 10px 20px; background: #d97706; color: white; text-decoration: none; border-radius: 5px; margin-top: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <h1>تحديث قاعدة البيانات</h1>
        <div class="log">
<?php
try {
    require_once 'db_connect.php';
    echo "✓ تم الاتصال بقاعدة البيانات بنجاح.<br>";
} catch (Throwable $e) {
    echo "<span class='error'>✗ فشل الاتصال بقاعدة البيانات: " . htmlspecialchars($e->getMessage()) . "</span><br>";
    exit;
}

// 1. Check for is_active in meals
try {
    $stmt = $pdo->query("SHOW COLUMNS FROM meals LIKE 'is_active'");
    if ($stmt->rowCount() == 0) {
        echo "جارٍ إضافة عمود 'is_active' إلى جدول الوجبات... ";
        $pdo->exec("ALTER TABLE meals ADD COLUMN is_active TINYINT(1) DEFAULT 1");
        echo "<span class='success'>تم!</span><br>";
    } else {
        echo "✓ عمود 'is_active' موجود مسبقاً في جدول الوجبات.<br>";
    }
} catch (Exception $e) {
    echo "<span class='error'>✗ خطأ في فحص جدول الوجبات: " . htmlspecialchars($e->getMessage()) . "</span><br>";
}

// 2. Ensure system_settings has color defaults
$defaults = [
    'admin_color_primary' => '#d97706',
    'admin_color_primary_dark' => '#b45309',
    'admin_color_primary_light' => '#f59e0b',
    'admin_color_accent' => '#dc2626',
    'admin_color_success' => '#16a34a',
    'admin_color_warning' => '#eab308',
    'admin_dark_mode' => '0',
    'grace_period_days' => '30',
    'grace_enabled' => '1'
];

echo "جارٍ التحقق من إعدادات الألوان...<br>";
foreach ($defaults as $key => $val) {
    try {
        $stmt = $pdo->prepare("SELECT setting_key FROM system_settings WHERE setting_key = ?");
        $stmt->execute([$key]);
        if ($stmt->rowCount() == 0) {
            echo "إضافة إعداد: $key... ";
            $pdo->prepare("INSERT INTO system_settings (setting_key, setting_value) VALUES (?, ?)")->execute([$key, $val]);
            echo "<span class='success'>تم</span><br>";
        }
    } catch (Exception $e) {
        echo "<span class='error'>خطأ في الإعداد $key: " . htmlspecialchars($e->getMessage()) . "</span><br>";
    }
}
echo "✓ تم التحقق من الإعدادات.<br>";

?>
        </div>
        <p class="success">تمت عملية التحديث بنجاح! يمكنك الآن استخدام النظام.</p>
        <a href="admin_dashboard.php" class="btn">الذهاب للوحة التحكم</a>
    </div>
</body>
</html>
