<?php
// clear_notif_logs.php - Clear notification logs
header('Content-Type: application/json; charset=utf-8');

$logFile = __DIR__ . '/notif_lib.log';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (file_exists($logFile)) {
        unlink($logFile);
        echo json_encode(['ok' => true, 'message' => 'تم مسح السجلات']);
    } else {
        echo json_encode(['ok' => false, 'message' => 'ملف السجل غير موجود']);
    }
} else {
    echo json_encode(['ok' => false, 'message' => 'Use POST']);
}
?>
