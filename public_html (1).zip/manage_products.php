<?php
// manage_products.php - النسخة الكاملة مع التعديل الجماعي والتكرار
// -------------------------------------------------------------------

// إجبار المتصفح على استخدام ترميز UTF-8
header('Content-Type: text/html; charset=utf-8');

// 1. الاتصال والحماية
if (file_exists('auth_admin.php')) require_once 'auth_admin.php';
require_once 'db_connect.php'; 

if (session_status() === PHP_SESSION_NONE) session_start();
if (empty($_SESSION['csrf_token'])) $_SESSION['csrf_token'] = bin2hex(random_bytes(32));

function mp_h($s){ return htmlspecialchars((string)$s, ENT_QUOTES, 'UTF-8'); }
function mp_table_exists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$table]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

function mp_url(string $view, int $catId): string {
    $qs = [];
    if ($view !== '') $qs['view'] = $view;
    if ($catId > 0) $qs['cat'] = $catId;
    $q = http_build_query($qs);
    return 'manage_products.php' . ($q ? ('?' . $q) : '');
}

function mp_status_url(string $status, string $view, int $catId): string {
    $base = mp_url($view, $catId);
    $sep = (strpos($base, '?') !== false) ? '&' : '?';
    return $base . $sep . 'status=' . urlencode($status);
}

// ============================================================
// 2. معالجة الإجراءات الجماعية (Bulk Actions)
// ============================================================
$status_msg = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['single_action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
        $rv = (string)($_POST['return_view'] ?? 'active');
        $rc = (int)($_POST['return_cat'] ?? 0);
        header("Location: " . mp_status_url('csrf', $rv, $rc));
        exit;
    }

    $id = (int)($_POST['id'] ?? 0);
    $action = (string)($_POST['single_action'] ?? '');
    if ($id <= 0) {
        $rv = (string)($_POST['return_view'] ?? 'active');
        $rc = (int)($_POST['return_cat'] ?? 0);
        header("Location: " . mp_status_url('error', $rv, $rc));
        exit;
    }

    try {
        $rv = (string)($_POST['return_view'] ?? 'active');
        $rc = (int)($_POST['return_cat'] ?? 0);

        if ($action === 'archive') {
            $pdo->prepare("UPDATE products SET is_active=0 WHERE id=?")->execute([$id]);
            header("Location: " . mp_status_url('archived', $rv, $rc));
            exit;
        }

        if ($action === 'unarchive') {
            $pdo->prepare("UPDATE products SET is_active=1 WHERE id=?")->execute([$id]);
            header("Location: " . mp_status_url('unarchived', $rv, $rc));
            exit;
        }

        if ($action === 'delete') {
            $hasOrders = 0;
            if (mp_table_exists($pdo, 'order_items')) {
                $st = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
                $st->execute([$id]);
                $hasOrders = (int)$st->fetchColumn();
            }
            if ($hasOrders > 0) {
                header("Location: " . mp_status_url('cannot_delete_orders', $rv, $rc));
                exit;
            }

            $pdo->beginTransaction();
            $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
            $stmt->execute([$id]);
            $img = (string)($stmt->fetchColumn() ?? '');

            if (mp_table_exists($pdo, 'product_sizes')) {
                $pdo->prepare("DELETE FROM product_sizes WHERE product_id = ?")->execute([$id]);
            }
            if (mp_table_exists($pdo, 'product_options')) {
                $pdo->prepare("DELETE FROM product_options WHERE product_id = ?")->execute([$id]);
            }
            $pdo->prepare("DELETE FROM products WHERE id = ?")->execute([$id]);
            $pdo->commit();

            if ($img && file_exists('uploads/' . $img)) @unlink('uploads/' . $img);

            header("Location: " . mp_status_url('deleted', $rv, $rc));
            exit;
        }
    } catch (Exception $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        $rv = (string)($_POST['return_view'] ?? 'active');
        $rc = (int)($_POST['return_cat'] ?? 0);
        header("Location: " . mp_status_url('error', $rv, $rc));
        exit;
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['bulk_action'])) {
    $csrf = $_POST['csrf_token'] ?? '';
    if (!$csrf || !hash_equals($_SESSION['csrf_token'], $csrf)) {
        $rv = (string)($_POST['return_view'] ?? 'active');
        $rc = (int)($_POST['return_cat'] ?? 0);
        header("Location: " . mp_status_url('csrf', $rv, $rc));
        exit;
    }
    
    if (isset($_POST['selected_ids']) && is_array($_POST['selected_ids'])) {
        $ids = $_POST['selected_ids'];
        $action = $_POST['bulk_action'];

        // أ) حالة التكرار (Duplicate)
        if ($action == 'duplicate') {
            $count = 0;
            try {
                $pdo->beginTransaction();
                
                // تحضير استعلام جلب المنتج الأصلي
                $stmt = $pdo->prepare("SELECT * FROM products WHERE id = ?");
                
                // تحضير استعلام نسخ المنتج
                $ins_sql = "INSERT INTO products (name, category_id, price, barcode, description, stock_qty, offer_price, offer_end_date, calories, protein, carbs, fat, image) 
                            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
                $ins_stmt = $pdo->prepare($ins_sql);

                // تحضير استعلام جلب الخيارات
                $opt_get = $pdo->prepare("SELECT * FROM product_options WHERE product_id = ?");
                
                // تحضير استعلام نسخ الخيارات
                $opt_ins = $pdo->prepare("INSERT INTO product_options (product_id, name, quantity, price, sku, custom_fields) VALUES (?, ?, ?, ?, ?, ?)");

                foreach ($ids as $id) {
                    // 1. جلب بيانات المنتج الأصلي
                    $stmt->execute([$id]);
                    $prod = $stmt->fetch(PDO::FETCH_ASSOC);

                    if ($prod) {
                        // 2. إنشاء نسخة جديدة (نضيف كلمة "نسخة" للاسم)
                        $new_name = $prod['name'] . ' (نسخة)';
                        
                        $ins_stmt->execute([
                            $new_name, $prod['category_id'], $prod['price'], $prod['barcode'], 
                            $prod['description'], $prod['stock_qty'], $prod['offer_price'], 
                            $prod['offer_end_date'], $prod['calories'], $prod['protein'], 
                            $prod['carbs'], $prod['fat'], $prod['image'] // نستخدم نفس مسار الصورة
                        ]);
                        
                        $new_prod_id = $pdo->lastInsertId();

                        // 3. نسخ الخيارات المرتبطة
                        $opt_get->execute([$id]);
                        $options = $opt_get->fetchAll(PDO::FETCH_ASSOC);
                        
                        foreach ($options as $opt) {
                            $opt_ins->execute([
                                $new_prod_id, $opt['name'], $opt['quantity'], $opt['price'], 
                                $opt['sku'], $opt['custom_fields']
                            ]);
                        }
                        $count++;
                    }
                }
                $pdo->commit();
                $status_msg = "<div class='alert-success'><i class='fas fa-clone'></i> تم تكرار ($count) منتج بنجاح!</div>";

            } catch (Exception $e) {
                $pdo->rollBack();
                $status_msg = "<div class='alert-danger'>حدث خطأ أثناء التكرار: " . $e->getMessage() . "</div>";
            }

        // ب) حالة الحذف الجماعي (Delete)
        } elseif ($action == 'delete') {
            $deleted = 0;
            $blocked = 0;
            foreach ($ids as $id) {
                $id = (int)$id;
                if ($id <= 0) continue;

                $hasOrders = 0;
                if (mp_table_exists($pdo, 'order_items')) {
                    $st = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
                    $st->execute([$id]);
                    $hasOrders = (int)$st->fetchColumn();
                }

                if ($hasOrders > 0) {
                    $blocked++;
                    continue;
                }

                $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
                $stmt->execute([$id]);
                $img = $stmt->fetchColumn();

                $del = $pdo->prepare("DELETE FROM products WHERE id = ?");
                $del->execute([$id]);
                $deleted++;

                if ($img && file_exists('uploads/' . $img)) @unlink('uploads/' . $img);
            }
            $parts = [];
            if ($deleted > 0) $parts[] = "حذف نهائي: ($deleted)";
            if ($blocked > 0) $parts[] = "لم يُحذف بسبب طلبات: ($blocked)";
            $status_msg = "<div class='alert-danger'><i class='fas fa-trash'></i> تم تنفيذ العملية — " . implode("، ", $parts) . ".</div>";
        } elseif ($action == 'archive') {
            $count = 0;
            foreach ($ids as $id) {
                $id = (int)$id;
                if ($id <= 0) continue;
                $pdo->prepare("UPDATE products SET is_active=0 WHERE id=?")->execute([$id]);
                $count++;
            }
            $status_msg = "<div class='alert-warning'><i class='fas fa-box-archive'></i> تم أرشفة ($count) منتج.</div>";
        } elseif ($action == 'unarchive') {
            $count = 0;
            foreach ($ids as $id) {
                $id = (int)$id;
                if ($id <= 0) continue;
                $pdo->prepare("UPDATE products SET is_active=1 WHERE id=?")->execute([$id]);
                $count++;
            }
            $status_msg = "<div class='alert-success'><i class='fas fa-rotate-left'></i> تم إلغاء أرشفة ($count) منتج.</div>";
        }
    } else {
        $status_msg = "<div class='alert-warning'>يرجى تحديد منتج واحد على الأقل.</div>";
    }
}

$view = (string)($_GET['view'] ?? 'active');
if (!in_array($view, ['active','archived','all'], true)) $view = 'active';
$cat_filter = (int)($_GET['cat'] ?? 0);

$categories = [];
try {
    $categories = $pdo->query("SELECT id, name FROM categories ORDER BY name ASC")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) { $categories = []; }

// 3. جلب المنتجات للعرض
$products = [];
try {
    $where = [];
    $params = [];

    if ($view === 'active') $where[] = "(p.is_active=1 OR p.is_active IS NULL)";
    if ($view === 'archived') $where[] = "p.is_active=0";
    if ($cat_filter > 0) { $where[] = "p.category_id=?"; $params[] = $cat_filter; }

    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id";
    if (!empty($where)) $sql .= " WHERE " . implode(" AND ", $where);
    $sql .= " ORDER BY p.id DESC";

    if (!empty($params)) {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        $products = $st->fetchAll(PDO::FETCH_ASSOC);
    } else {
        $products = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
    }
} catch (Exception $e) {
    $sql = "SELECT p.*, c.name as category_name 
            FROM products p 
            LEFT JOIN categories c ON p.category_id = c.id 
            ORDER BY p.id DESC";
    $products = $pdo->query($sql)->fetchAll(PDO::FETCH_ASSOC);
}

// معالجة رسائل الرابط (GET)
if (isset($_GET['status']) && empty($status_msg)) {
    if ($_GET['status'] == 'success') $status_msg = '<div class="alert-success">تم حفظ البيانات بنجاح!</div>';
    if ($_GET['status'] == 'deleted') $status_msg = '<div class="alert-danger">تم حذف المنتج.</div>';
    if ($_GET['status'] == 'archived') $status_msg = '<div class="alert-warning"><i class="fas fa-box-archive"></i> تم أرشفة المنتج.</div>';
    if ($_GET['status'] == 'unarchived') $status_msg = '<div class="alert-success"><i class="fas fa-rotate-left"></i> تم إلغاء أرشفة المنتج.</div>';
    if ($_GET['status'] == 'cannot_delete_orders') $status_msg = '<div class="alert-warning"><i class="fas fa-triangle-exclamation"></i> لا يمكن حذف الوجبة نهائياً لأنها مرتبطة بطلبات. استخدم الأرشفة بدلاً من الحذف.</div>';
    if ($_GET['status'] == 'csrf') $status_msg = '<div class="alert-warning"><i class="fas fa-triangle-exclamation"></i> انتهت صلاحية الجلسة. حدّث الصفحة وحاول مجددًا.</div>';
    if ($_GET['status'] == 'bulk') {
        $deleted = (int)($_GET['deleted'] ?? 0);
        $archived = (int)($_GET['archived'] ?? 0);
        $parts = [];
        if ($deleted > 0) $parts[] = "حذف نهائي: ($deleted)";
        if ($archived > 0) $parts[] = "أرشفة: ($archived)";
        $status_msg = '<div class="alert-warning"><i class="fas fa-box-archive"></i> تم تنفيذ العملية — ' . implode('، ', $parts) . '.</div>';
    }
}
?>

<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>إدارة المنتجات</title>
    
    <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
    <link rel="stylesheet" href="admin_colors.php?v=20260113">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
    
    <style>
        /* تنسيقات شريط الإجراءات الجماعية */
        .bulk-toolbar {
            background: #fff;
            padding: 15px 20px;
            border-radius: 10px;
            box-shadow: 0 4px 15px rgba(0,0,0,0.03);
            margin-bottom: 25px;
            display: flex;
            align-items: center;
            gap: 15px;
            border: 1px solid #e0e0e0;
        }
        
        .bulk-btn {
            border: none;
            padding: 10px 20px;
            border-radius: 6px;
            font-weight: bold;
            cursor: pointer;
            transition: 0.3s;
            display: flex; align-items: center; gap: 8px;
            font-family: inherit;
        }

        .btn-duplicate { background: #eef2ff; color: #4a69bd; border: 1px solid #4a69bd; }
        .btn-duplicate:hover { background: #4a69bd; color: #fff; }

        .btn-bulk-delete { background: #fff0f0; color: #e74c3c; border: 1px solid #e74c3c; }
        .btn-bulk-delete:hover { background: #e74c3c; color: #fff; }

        .btn-bulk-archive { background: #fff7ed; color: #9a3412; border: 1px solid #fb923c; }
        .btn-bulk-archive:hover { background: #fb923c; color: #fff; }

        .btn-bulk-unarchive { background: #ecfdf5; color: #166534; border: 1px solid #22c55e; }
        .btn-bulk-unarchive:hover { background: #22c55e; color: #fff; }

        .toolbar-top {
            display:flex;
            align-items:center;
            justify-content:space-between;
            gap:12px;
            flex-wrap:wrap;
            margin-bottom:14px;
        }

        .view-tabs {
            display:flex;
            gap:10px;
            flex-wrap:wrap;
            align-items:center;
        }
        .view-tab {
            padding:10px 14px;
            border-radius:999px;
            border:1px solid #e5e7eb;
            background:#fff;
            text-decoration:none;
            color:#111827;
            font-weight:900;
            display:inline-flex;
            align-items:center;
            gap:8px;
        }
        .view-tab.active {
            background: var(--restaurant-gradient);
            border-color: transparent;
            color:#fff;
        }

        .cats-tabs {
            display:flex;
            gap:10px;
            overflow:auto;
            padding-bottom:6px;
            scrollbar-width: none;
            margin-bottom: 14px;
        }
        .cats-tabs::-webkit-scrollbar { display:none; }
        .cat-tab {
            padding:10px 14px;
            border-radius:999px;
            border:1px solid #e5e7eb;
            background:#fff;
            text-decoration:none;
            color:#111827;
            font-weight:900;
            white-space:nowrap;
            display:inline-flex;
            align-items:center;
            gap:8px;
        }
        .cat-tab.active {
            background: rgba(217, 119, 6, 0.10);
            border-color: rgba(217, 119, 6, 0.28);
            color: #92400e;
        }

        .product-card.is-archived {
            opacity: 0.55;
            filter: grayscale(0.15);
        }

        .archived-badge {
            position:absolute;
            top: 15px;
            right: 15px;
            background: rgba(28, 25, 23, 0.82);
            color: #fff;
            padding: 6px 10px;
            border-radius: 999px;
            font-weight: 1000;
            font-size: 0.78rem;
            display:inline-flex;
            align-items:center;
            gap:8px;
            z-index: 3;
        }

        .actions-bar {
            background:#fcfcfc;
            padding:10px 15px;
            border-top:1px solid #f0f0f0;
            display:flex;
            gap:10px;
        }
        .actions-bar form { flex: 1; }
        .actions-bar button { width: 100%; justify-content:center; }

        .btn-archive {
            background: linear-gradient(135deg, #f59e0b 0%, #fb923c 100%);
            box-shadow: 0 10px 18px rgba(245, 158, 11, 0.20);
        }
        .btn-unarchive {
            background: linear-gradient(135deg, #16a34a 0%, #22c55e 100%);
            box-shadow: 0 10px 18px rgba(34, 197, 94, 0.20);
        }

        /* تنسيق مربع الاختيار داخل الكارت */
        .card-checkbox-wrapper {
            position: absolute;
            top: 15px;
            right: 15px;
            z-index: 10;
        }
        
        .custom-checkbox {
            width: 22px;
            height: 22px;
            cursor: pointer;
            accent-color: #6f42c1; /* لون بنفسجي عند التحديد */
        }

        /* تعديل مكان شارة التصنيف لتكون في اليسار بدلاً من اليمين (لإفساح المجال للاختيار) */
        .category-badge-left {
            position: absolute;
            top: 15px;
            left: 15px;
            background: rgba(255, 255, 255, 0.95);
            padding: 5px 12px;
            border-radius: 30px;
            font-size: 0.75rem;
            font-weight: bold;
            color: #6f42c1;
            box-shadow: 0 2px 5px rgba(0,0,0,0.1);
            z-index: 2;
        }

        /* رسائل التنبيه */
        .alert-success { background: #d4edda; color: #155724; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-danger { background: #f8d7da; color: #721c24; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        .alert-warning { background: #fff3cd; color: #856404; padding: 15px; border-radius: 8px; margin-bottom: 20px; }
        /* ========================================= */
/* إصلاح شبكة عرض المنتجات (Grid System)     */
/* ========================================= */

/* 1. الحاوية الرئيسية (الشبكة) */
.product-grid {
    display: grid;
    /* هذا السطر يجعل الكروت تتجاوب تلقائياً مع الشاشة */
    /* يعرض 3 أو 4 منتجات في الصف للشاشات الكبيرة، و 1 للجوال */
    grid-template-columns: repeat(auto-fill, minmax(280px, 1fr));
    gap: 25px; /* المسافة بين الكروت */
    padding-bottom: 50px;
}

/* 2. تصميم كرت المنتج */
.product-card {
    background: #fff;
    border-radius: 16px; /* حواف دائرية ناعمة */
    overflow: hidden; /* قص أي محتوى يخرج عن الإطار */
    border: 1px solid #f0f0f0;
    box-shadow: 0 4px 20px rgba(0,0,0,0.04); /* ظل خفيف جداً */
    transition: transform 0.3s ease, box-shadow 0.3s ease;
    display: flex;
    flex-direction: column; /* ترتيب المحتوى عمودياً */
    height: 100%; /* لضمان تساوي ارتفاع جميع الكروت في نفس الصف */
    position: relative;
}

.product-card:hover {
    transform: none;
    box-shadow: 0 6px 18px rgba(0,0,0,0.06);
}

/* 3. حاوية الصورة (لضبط الارتفاع الموحد) */
.prod-img-container {
    width: 100%;
    height: 200px; /* ارتفاع ثابت لجميع الصور مهما كان حجمها الأصلي */
    background-color: #f8f9fa;
    display: flex;
    align-items: center;
    justify-content: center;
    overflow: hidden;
    position: relative;
    border-bottom: 1px solid #eee;
}

/* 4. الصورة نفسها */
.prod-img {
    width: 100%;
    height: 100%;
    object-fit: cover; /* أهم خاصية: تملأ الإطار دون مط الصورة */
    transition: transform 0.5s ease;
}

.product-card:hover .prod-img {
    transform: none;
}

/* 5. أيقونة (لا توجد صورة) */
.no-image-placeholder {
    display: flex;
    flex-direction: column;
    align-items: center;
    justify-content: center;
    color: #ccc;
    font-size: 0.9rem;
}

/* 6. شارة التصنيف (Category Badge) */
.category-badge {
    position: absolute;
    top: 15px;
    left: 15px; /* وضعناها يساراً لتبدو أجمل مع اللغة العربية */
    background: rgba(255, 255, 255, 0.95);
    padding: 5px 12px;
    border-radius: 30px;
    font-size: 0.75rem;
    font-weight: bold;
    color: #6f42c1; /* اللون البنفسجي */
    box-shadow: 0 2px 8px rgba(0,0,0,0.1);
    z-index: 2;
}

/* 7. تفاصيل المنتج (النص) */
.prod-details {
    padding: 15px 20px;
    flex-grow: 1; /* يأخذ المساحة المتبقية لدفع الأزرار للأسفل */
    display: flex;
    flex-direction: column;
}

.prod-title {
    font-size: 1.1rem;
    font-weight: 700;
    color: #333;
    margin: 0 0 8px 0;
    white-space: nowrap; /* منع نزول العنوان لسطرين */
    overflow: hidden;
    text-overflow: ellipsis; /* وضع (...) إذا كان العنوان طويلاً */
}

.prod-meta {
    display: flex;
    justify-content: space-between;
    align-items: center;
    margin-bottom: 15px;
    font-size: 0.85rem;
    color: #888;
}

/* 8. السعر */
.price-area {
    margin-top: auto; /* دفع السعر للأسفل */
    display: flex;
    align-items: center;
    justify-content: space-between;
    padding-top: 10px;
    border-top: 1px dashed #eee;
}

.current-price {
    font-size: 1.2rem;
    font-weight: 800;
    color: #27ae60; /* الأخضر */
}

.old-price {
    text-decoration: line-through;
    color: #aaa;
    font-size: 0.9rem;
    margin-right: 8px;
}

/* 9. شريط الأزرار (تعديل وحذف) */
.actions-bar {
    padding: 15px 20px;
    background-color: #fcfcfc;
    border-top: 1px solid #f0f0f0;
    display: flex;
    gap: 10px; /* مسافة بين الزرين */
}

.btn-action {
    flex: 1; /* الزر يأخذ نصف المساحة */
    padding: 10px 0;
    text-align: center;
    border-radius: 8px;
    text-decoration: none;
    font-size: 0.9rem;
    font-weight: 600;
    transition: all 0.2s ease;
    display: flex;
    align-items: center;
    justify-content: center;
    gap: 5px;
}

.btn-action.btn-edit {
    background-color: #eef2ff;
    color: #4a69bd;
}
.btn-action.btn-edit:hover {
    background-color: #4a69bd;
    color: #fff;
}

.btn-action.btn-delete {
    background-color: #fff0f0;
    color: #e74c3c;
}
.btn-action.btn-delete:hover {
    background-color: #e74c3c;
    color: #fff;
}
        
    </style>
</head>
<body>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        
        <header class="top-bar">
            <div>
                <h2>إدارة المنتجات</h2>
                <span>عرض وتعديل وتكرار الوجبات</span>
            </div>
            <a href="add_product.php" class="btn btnPrimary">
                <i class="fas fa-plus"></i> إضافة منتج جديد
            </a>
        </header>

        <main class="content-wrapper">
            
            <?php echo $status_msg; ?>

            <div class="toolbar-top">
                <div class="view-tabs">
                    <a class="view-tab <?php echo $view==='active'?'active':''; ?>" href="<?php echo mp_h(mp_url('active', $cat_filter)); ?>">
                        <i class="fas fa-circle-check"></i> نشطة
                    </a>
                    <a class="view-tab <?php echo $view==='archived'?'active':''; ?>" href="<?php echo mp_h(mp_url('archived', $cat_filter)); ?>">
                        <i class="fas fa-box-archive"></i> مؤرشفة
                    </a>
                    <a class="view-tab <?php echo $view==='all'?'active':''; ?>" href="<?php echo mp_h(mp_url('all', $cat_filter)); ?>">
                        <i class="fas fa-layer-group"></i> الكل
                    </a>
                </div>

                <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                    <input id="productSearch" type="text" class="form-control" placeholder="بحث بالاسم أو الباركود..." style="max-width: 420px;">
                </div>
            </div>

            <div class="cats-tabs">
                <a class="cat-tab <?php echo $cat_filter===0?'active':''; ?>" href="<?php echo mp_h(mp_url($view, 0)); ?>">
                    <i class="fas fa-list"></i> الكل
                </a>
                <?php foreach ($categories as $c): ?>
                    <a class="cat-tab <?php echo $cat_filter===(int)$c['id']?'active':''; ?>" href="<?php echo mp_h(mp_url($view, (int)$c['id'])); ?>">
                        <i class="fas fa-tag"></i> <?php echo mp_h($c['name']); ?>
                    </a>
                <?php endforeach; ?>
            </div>

            <form method="POST" action="" id="bulkForm">
                <input type="hidden" name="csrf_token" value="<?php echo mp_h($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="return_view" value="<?php echo mp_h($view); ?>">
                <input type="hidden" name="return_cat" value="<?php echo (int)$cat_filter; ?>">
                
                <div class="bulk-toolbar">
                    <div style="display:flex; align-items:center; gap:8px;">
                        <input type="checkbox" id="selectAll" class="custom-checkbox">
                        <label for="selectAll" style="margin:0; font-weight:bold; cursor:pointer;">تحديد الكل</label>
                    </div>
                    
                    <div style="height:30px; width:1px; background:#ddd; margin:0 10px;"></div>

                    <button type="submit" name="bulk_action" value="duplicate" class="bulk-btn btn-duplicate">
                        <i class="fas fa-clone"></i> تكرار المحدد
                    </button>

                    <button type="submit" name="bulk_action" value="archive" class="bulk-btn btn-bulk-archive" onclick="return confirm('أرشفة المنتجات المحددة؟');">
                        <i class="fas fa-box-archive"></i> أرشفة المحدد
                    </button>

                    <button type="submit" name="bulk_action" value="unarchive" class="bulk-btn btn-bulk-unarchive" onclick="return confirm('إلغاء أرشفة المنتجات المحددة؟');">
                        <i class="fas fa-rotate-left"></i> إلغاء الأرشفة
                    </button>

                    <button type="submit" name="bulk_action" value="delete" class="bulk-btn btn-bulk-delete" onclick="return confirm('حذف نهائي للمنتجات المحددة (غير المرتبطة بطلبات فقط)؟');">
                        <i class="fas fa-trash"></i> حذف المحدد
                    </button>
                </div>

                <?php if (count($products) > 0): ?>
                    <div class="product-grid">
                        <?php foreach ($products as $prod): ?>
                            
                            <?php 
                                $has_offer = false;
                                $display_price = $prod['price'];
                                if (!empty($prod['offer_price']) && $prod['offer_price'] > 0) {
                                    if (empty($prod['offer_end_date']) || new DateTime($prod['offer_end_date']) > new DateTime()) {
                                        $has_offer = true;
                                        $display_price = $prod['offer_price'];
                                    }
                                }
                            ?>

                            <?php $is_archived = isset($prod['is_active']) && (int)$prod['is_active'] === 0; ?>
                            <div class="product-card <?php echo $is_archived ? 'is-archived' : ''; ?>"
                                 data-name="<?php echo mp_h(mb_strtolower((string)$prod['name'])); ?>"
                                 data-barcode="<?php echo mp_h(mb_strtolower((string)($prod['barcode'] ?? ''))); ?>"
                                 data-cat="<?php echo (int)($prod['category_id'] ?? 0); ?>">

                                <?php if ($is_archived): ?>
                                    <div class="archived-badge"><i class="fas fa-box-archive"></i> مؤرشف</div>
                                <?php endif; ?>
                                
                                <div class="card-checkbox-wrapper">
                                    <input type="checkbox" name="selected_ids[]" value="<?php echo $prod['id']; ?>" class="custom-checkbox item-checkbox">
                                </div>

                                <div class="category-badge-left">
                                    <i class="fas fa-utensils"></i> <?php echo htmlspecialchars($prod['category_name'] ?? 'عام'); ?>
                                </div>

                                <div class="prod-img-container">
                                    <?php if (!empty($prod['image'])): ?>
                                        <img class="prod-img" src="uploads/<?php echo htmlspecialchars($prod['image']); ?>" alt="">
                                    <?php else: ?>
                                        <div class="no-image-placeholder"><i class="fas fa-image fa-3x"></i></div>
                                    <?php endif; ?>
                                </div>

                                <div class="prod-details">
                                    <h3 class="prod-title"><?php echo htmlspecialchars($prod['name']); ?></h3>
                                    
                                    <div style="display:flex; justify-content:space-between; font-size:0.85rem; color:#777; margin-bottom:10px;">
                                        <span><?php echo !empty($prod['barcode']) ? $prod['barcode'] : '#---'; ?></span>
                                        <?php if ((int)$prod['stock_qty'] === -1): ?>
                                            <span style="color:#2980b9; background:#e8f4fd; padding:2px 8px; border-radius:4px; font-weight:bold;">
                                                <i class="fas fa-infinity"></i> لا محدود
                                            </span>
                                        <?php elseif ((int)$prod['stock_qty'] > 0): ?>
                                            <span style="color:#27ae60; background:#e8f8f5; padding:2px 8px; border-radius:4px;">متاح: <?php echo $prod['stock_qty']; ?></span>
                                        <?php else: ?>
                                            <span style="color:#e74c3c; background:#fdedec; padding:2px 8px; border-radius:4px;">نفذت الكمية</span>
                                        <?php endif; ?>
                                    </div>
                                    
                                    <div style="margin-top:auto; padding-top:10px; border-top:1px dashed #eee; display:flex; justify-content:space-between; align-items:center;">
                                        <div>
                                            <span style="font-size:1.2rem; font-weight:bold; color:#27ae60;"><?php echo number_format($display_price, 2); ?> ر.س</span>
                                            <?php if ($has_offer): ?>
                                                <span style="text-decoration:line-through; color:#aaa; font-size:0.9rem; margin-right:5px;"><?php echo number_format($prod['price'], 2); ?></span>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>

                                <div class="actions-bar">
                                    <a href="edit_product.php?id=<?php echo (int)$prod['id']; ?>" class="action-btn btn-edit" style="flex:1; justify-content:center;">
                                        <i class="fas fa-edit"></i> تعديل
                                    </a>

                                    <?php if (!$is_archived): ?>
                                        <button type="button"
                                                class="action-btn btn-archive"
                                                style="flex:1; justify-content:center;"
                                                onclick="submitSingleAction('archive', <?php echo (int)$prod['id']; ?>, 'أرشفة هذه الوجبة؟');">
                                            <i class="fas fa-box-archive"></i> أرشفة
                                        </button>
                                    <?php else: ?>
                                        <button type="button"
                                                class="action-btn btn-unarchive"
                                                style="flex:1; justify-content:center;"
                                                onclick="submitSingleAction('unarchive', <?php echo (int)$prod['id']; ?>, 'إلغاء أرشفة هذه الوجبة؟');">
                                            <i class="fas fa-rotate-left"></i> إلغاء الأرشفة
                                        </button>
                                    <?php endif; ?>

                                    <button type="button"
                                            class="action-btn btn-delete"
                                            style="flex:1; justify-content:center;"
                                            onclick="submitSingleAction('delete', <?php echo (int)$prod['id']; ?>, 'حذف نهائي لهذه الوجبة؟ سيتم المنع إذا كانت مرتبطة بطلبات.');">
                                        <i class="fas fa-trash"></i> حذف
                                    </button>
                                </div>
                            </div>

                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <div style="text-align:center; padding:50px; background:white; border-radius:15px; border:1px dashed #ddd;">
                        <h3 style="color:#777;">لا توجد منتجات. ابدأ بإضافة منتج جديد.</h3>
                    </div>
                <?php endif; ?>
            </form>

            <form id="singleActionForm" method="POST" action="">
                <input type="hidden" name="csrf_token" value="<?php echo mp_h($_SESSION['csrf_token']); ?>">
                <input type="hidden" name="return_view" value="<?php echo mp_h($view); ?>">
                <input type="hidden" name="return_cat" value="<?php echo (int)$cat_filter; ?>">
                <input type="hidden" name="id" id="singleActionId" value="">
                <input type="hidden" name="single_action" id="singleActionType" value="">
            </form>

        </main>
    </div>

    <script>
        document.getElementById('selectAll').addEventListener('change', function() {
            var checkboxes = document.querySelectorAll('.item-checkbox');
            for (var checkbox of checkboxes) {
                checkbox.checked = this.checked;
            }
        });

        (function() {
            var input = document.getElementById('productSearch');
            if (!input) return;

            function applyFilter() {
                var q = (input.value || '').trim().toLowerCase();
                var cards = document.querySelectorAll('.product-card');
                cards.forEach(function(card) {
                    var name = (card.getAttribute('data-name') || '');
                    var barcode = (card.getAttribute('data-barcode') || '');
                    var ok = (q === '') || name.indexOf(q) !== -1 || barcode.indexOf(q) !== -1;
                    card.style.display = ok ? '' : 'none';
                });
            }

            input.addEventListener('input', applyFilter);
        })();

        function submitSingleAction(action, id, message) {
            if (message && !confirm(message)) return;
            var form = document.getElementById('singleActionForm');
            var idEl = document.getElementById('singleActionId');
            var actionEl = document.getElementById('singleActionType');
            if (!form || !idEl || !actionEl) return;
            idEl.value = String(id || '');
            actionEl.value = String(action || '');
            form.submit();
        }
    </script>
</body>
</html>
