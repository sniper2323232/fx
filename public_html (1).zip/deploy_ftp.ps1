param(
  [string]$FtpHost = "92.113.28.131",
  [int]$Port = 21,
  [string]$Username = "u132225456.carby.najd-almotatorh.com",
  [string]$RemoteDir = "/public_html",
  [string]$LocalDir = "",
  [string[]]$Files = @(
    "admin-unified-style-v2.css",
    "system_settings.php",
    "handle_settings.php",
    "sidebar.php",
    "subscriptions_center.php",
    "handle_delete_client.php"
  ),
  [ValidateSet("Auto","On","Off")]
  [string]$Tls = "Auto",
  [switch]$InsecureTls,
  [switch]$TestOnly,
  [switch]$DryRun
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

if ([string]::IsNullOrWhiteSpace($LocalDir)) {
  $LocalDir = (Get-Location).Path
}

$RemoteDir = $RemoteDir.TrimEnd("/")
if (-not $RemoteDir.StartsWith("/")) {
  $RemoteDir = "/" + $RemoteDir
}

function Get-PlainTextFromSecureString([Security.SecureString]$Secure) {
  $bstr = [Runtime.InteropServices.Marshal]::SecureStringToBSTR($Secure)
  try { return [Runtime.InteropServices.Marshal]::PtrToStringBSTR($bstr) }
  finally { [Runtime.InteropServices.Marshal]::ZeroFreeBSTR($bstr) }
}

function New-FtpRequest {
  param(
    [string]$HostName,
    [int]$PortNumber,
    [string]$User,
    [string]$Pass,
    [string]$RemotePath,
    [string]$Method,
    [bool]$EnableSsl
  )

  $remoteUrl = "ftp://{0}:{1}{2}" -f $HostName, $PortNumber, $RemotePath
  $request = [System.Net.FtpWebRequest]::Create($remoteUrl)
  $request.Method = $Method
  $request.Credentials = New-Object System.Net.NetworkCredential($User, $Pass)
  $request.UseBinary = $true
  $request.UsePassive = $true
  $request.KeepAlive = $false
  $request.Proxy = $null
  $request.EnableSsl = $EnableSsl
  return $request
}

function Get-FtpErrorDetails {
  param([System.Net.WebException]$WebEx)
  $resp = $WebEx.Response
  if ($null -ne $resp -and $resp -is [System.Net.FtpWebResponse]) {
    $ftp = [System.Net.FtpWebResponse]$resp
    return ("FTP {0}: {1}" -f $ftp.StatusCode, ($ftp.StatusDescription.Trim()))
  }
  return $WebEx.Message
}

function Test-FtpLogin {
  param(
    [string]$HostName,
    [int]$PortNumber,
    [string]$User,
    [string]$Pass,
    [string]$RemoteDirPath,
    [bool]$EnableSsl
  )
  $path = $RemoteDirPath
  if (-not $path.EndsWith("/")) { $path += "/" }
  $req = New-FtpRequest -HostName $HostName -PortNumber $PortNumber -User $User -Pass $Pass -RemotePath $path -Method ([System.Net.WebRequestMethods+Ftp]::ListDirectory) -EnableSsl $EnableSsl
  try {
    $resp = [System.Net.FtpWebResponse]$req.GetResponse()
    try { return $resp.StatusDescription }
    finally { $resp.Close() }
  } catch [System.Net.WebException] {
    throw (Get-FtpErrorDetails -WebEx $_.Exception)
  }
}

function Upload-FtpFile {
  param(
    [string]$HostName,
    [int]$PortNumber,
    [string]$User,
    [string]$Pass,
    [string]$RemotePath,
    [string]$LocalPath,
    [bool]$EnableSsl
  )

  $bytes = [System.IO.File]::ReadAllBytes($LocalPath)

  $request = New-FtpRequest -HostName $HostName -PortNumber $PortNumber -User $User -Pass $Pass -RemotePath $RemotePath -Method ([System.Net.WebRequestMethods+Ftp]::UploadFile) -EnableSsl $EnableSsl
  $request.ContentLength = $bytes.Length

  try {
    $stream = $request.GetRequestStream()
    try { $stream.Write($bytes, 0, $bytes.Length) }
    finally { $stream.Close() }
  } catch [System.Net.WebException] {
    throw (Get-FtpErrorDetails -WebEx $_.Exception)
  }

  try {
    $response = [System.Net.FtpWebResponse]$request.GetResponse()
    try { return $response.StatusDescription }
    finally { $response.Close() }
  } catch [System.Net.WebException] {
    throw (Get-FtpErrorDetails -WebEx $_.Exception)
  }
}

if ($DryRun) {
  Write-Host ("DryRun: Host={0}:{1} User={2} RemoteDir={3} LocalDir={4}" -f $FtpHost, $Port, $Username, $RemoteDir, $LocalDir)
  foreach ($f in $Files) {
    $lp = Join-Path $LocalDir $f
    $rp = "{0}/{1}" -f $RemoteDir, $f
    $exists = Test-Path -LiteralPath $lp
    Write-Host ("- {0} -> {1} ({2})" -f $lp, $rp, ($(if ($exists) { "OK" } else { "MISSING" })))
  }
  exit 0
}

$secure = Read-Host "FTP Password" -AsSecureString
$password = Get-PlainTextFromSecureString $secure

$effectiveSsl = $false
if ($InsecureTls) {
  [System.Net.ServicePointManager]::ServerCertificateValidationCallback = { $true }
}

if ($Tls -eq "On") { $effectiveSsl = $true }
elseif ($Tls -eq "Off") { $effectiveSsl = $false }
else {
  $firstError = $null
  try {
    $null = Test-FtpLogin -HostName $FtpHost -PortNumber $Port -User $Username -Pass $password -RemoteDirPath $RemoteDir -EnableSsl $false
    $effectiveSsl = $false
  } catch {
    $firstError = $_.Exception.Message
    try {
      $null = Test-FtpLogin -HostName $FtpHost -PortNumber $Port -User $Username -Pass $password -RemoteDirPath $RemoteDir -EnableSsl $true
      $effectiveSsl = $true
    } catch {
      throw ("فشل تسجيل الدخول. بدون TLS: {0} | مع TLS: {1}" -f $firstError, $_.Exception.Message)
    }
  }
}

if ($TestOnly) {
  $status = Test-FtpLogin -HostName $FtpHost -PortNumber $Port -User $Username -Pass $password -RemoteDirPath $RemoteDir -EnableSsl $effectiveSsl
  Write-Host ("Login OK. TLS={0}. {1}" -f $effectiveSsl, $status.Trim())
  exit 0
}

foreach ($f in $Files) {
  $localPath = Join-Path $LocalDir $f
  if (-not (Test-Path -LiteralPath $localPath)) {
    throw ("File not found: {0}" -f $localPath)
  }
  $remotePath = "{0}/{1}" -f $RemoteDir, $f
  $status = Upload-FtpFile -HostName $FtpHost -PortNumber $Port -User $Username -Pass $password -RemotePath $remotePath -LocalPath $localPath -EnableSsl $effectiveSsl
  Write-Host ("Uploaded: {0} -> {1} ({2})" -f $f, $remotePath, $status.Trim())
}

Write-Host "Done"
