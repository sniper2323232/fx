<?php
// notif_lib.php - Compatibility helpers for inserting notifications
// Provides flexible insertion supporting different notifications schema variants

if (file_exists(__DIR__ . '/notif_fcm.php')) {
    require_once __DIR__ . '/notif_fcm.php';
}

function notif_table_exists(PDO $pdo): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE 'notifications'");
        $st->execute();
        return (bool)$st->fetchColumn();
    } catch (Exception $e) { return false; }
}

function notif_get_columns(PDO $pdo): array {
    $cols = [];
    try {
        $st = $pdo->query("SHOW COLUMNS FROM `notifications`");
        while ($r = $st->fetch(PDO::FETCH_ASSOC)) $cols[] = $r['Field'];
    } catch (Exception $e) {}
    return $cols;
}

function notif_log(string $msg): void {
    $file = __DIR__ . '/notif_lib.log';
    error_log('[' . date('Y-m-d H:i:s') . '] ' . $msg . "\n", 3, $file);
}

function insertNotificationFlexible(PDO $pdo, array $data): bool {
    if (!notif_table_exists($pdo)) {
        notif_log('ERROR: notifications table does not exist');
        return false;
    }
    
    $cols = notif_get_columns($pdo);
    if (empty($cols)) {
        notif_log('ERROR: Could not get columns from notifications');
        return false;
    }

    // خريطة المجالات المتعددة الأعمدة
    $map = [
        'user_id'    => ['user_id','client_id','customer_id','uid'],
        'title'      => ['title','notif_title','subject'],
        'message'    => ['message','body','content','notif_message','text'],
        'link'       => ['link','url','target_url'],
        'type'       => ['type','category','notif_type'],
        'is_read'    => ['is_read','read_flag','seen','is_seen'],
        'created_at' => ['created_at','created','date_created','createdOn']
    ];

    $insertCols = [];
    $placeholders = [];
    $params = [];

    // اختر الأعمدة المتاحة والبيانات الموجودة
    foreach ($map as $key => $cands) {
        if (!array_key_exists($key, $data)) continue;
        
        foreach ($cands as $c) {
            if (in_array($c, $cols, true)) {
                $insertCols[] = "`$c`";
                $placeholders[] = '?';
                $params[] = $data[$key];
                break;
            }
        }
    }

    if (count($insertCols) < 1) {
        notif_log('ERROR: No compatible columns found for data: ' . json_encode($data));
        return false;
    }

    $sql = "INSERT INTO `notifications` (" . implode(',', $insertCols) . ") VALUES (" . implode(',', $placeholders) . ")";
    
    try {
        $st = $pdo->prepare($sql);
        $st->execute($params);
        notif_log('SUCCESS: Inserted notification. Columns: ' . implode(', ', $insertCols));
        if (isset($data['user_id']) && function_exists('fcm_send_user_notification')) {
            $uid = (int)$data['user_id'];
            if ($uid > 0) {
                $title = (string)($data['title'] ?? '');
                $message = (string)($data['message'] ?? '');
                $link = isset($data['link']) ? (string)$data['link'] : null;
                $type = isset($data['type']) ? (string)$data['type'] : null;
                $image = isset($data['image']) ? (string)$data['image'] : null;
                fcm_send_user_notification($pdo, $uid, $title, $message, $link, $type, $image);
            }
        }
        return true;
    } catch (Exception $e) {
        notif_log('ERROR: Failed to insert: ' . $e->getMessage() . ' | SQL: ' . $sql);
        return false;
    }
}

function notifyClient(PDO $pdo, int $clientId, string $title, string $message, ?string $link = null, ?string $type = null): bool {
    notif_log("notifyClient called: client_id=$clientId, title='$title'");
    
    return insertNotificationFlexible($pdo, [
        'user_id' => $clientId,
        'title' => $title,
        'message' => $message,
        'link' => $link,
        'type' => $type,
        'created_at' => date('Y-m-d H:i:s'),
        'is_read' => 0
    ]);
}

function notifyRoleFallback(PDO $pdo, string $role, string $title, string $message, ?string $link = null) {
    notif_log("notifyRoleFallback called: role=$role, title='$title'");
    
    // try to find all users with this role and insert per-user, else insert generic role notice if supported
    try {
        $st = $pdo->prepare("SELECT id FROM users WHERE role = ?");
        $st->execute([$role]);
        $ids = $st->fetchAll(PDO::FETCH_COLUMN);
        if ($ids && count($ids) > 0) {
            foreach ($ids as $uid) {
                insertNotificationFlexible($pdo, [
                    'user_id' => (int)$uid,
                    'title' => $title,
                    'message' => $message,
                    'link' => $link,
                    'created_at' => date('Y-m-d H:i:s'),
                    'is_read' => 0
                ]);
            }
            notif_log("notifyRoleFallback: Inserted for $role to " . count($ids) . ' users');
            return true;
        }
    } catch (Exception $e) {
        notif_log("notifyRoleFallback: Error finding users with role '$role': " . $e->getMessage());
    }

    // fallback: try inserting a role-level notification if table supports 'role' column
    $cols = notif_get_columns($pdo);
    if (in_array('role', $cols, true)) {
        try {
            $st = $pdo->prepare("INSERT INTO notifications (role, title, message, link, created_at) VALUES (?, ?, ?, ?, ?)");
            $st->execute([$role, $title, $message, $link, date('Y-m-d H:i:s')]);
            notif_log("notifyRoleFallback: Inserted generic role notification");
            return true;
        } catch (Exception $e) {
            notif_log("notifyRoleFallback: Error inserting role notification: " . $e->getMessage());
        }
    }
    return false;
}

?>
