<?php
// يجب استدعاء lang_handler.php قبل أي header() أو output
require_once 'lang_handler.php';

// إجبار المتصفح على استخدام ترميز UTF-8
header('Content-Type: text/html; charset=utf-8');

require_once 'auth_admin.php'; 
require_once 'db_connect.php'; 

function is_valid_ymd(string $s): bool {
    return (bool)preg_match('/^\d{4}-\d{2}-\d{2}$/', $s);
}

function table_exists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$table]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

function status_label(string $status): string {
    switch ($status) {
        case 'pending': return 'قيد الانتظار';
        case 'prepared': return 'تم التجهيز';
        case 'out_for_delivery': return 'جاري التوصيل';
        case 'delivered': return 'تم التسليم';
        case 'picked_up': return 'تم الاستلام';
        case 'cancelled': return 'ملغي';
        default: return $status;
    }
}

function payment_label(?string $method): string {
    $m = strtolower(trim((string)$method));
    if ($m === '' || $m === 'null') return 'غير محدد';
    if ($m === 'cod') return 'عند الاستلام';
    if ($m === 'cash') return 'كاش';
    if ($m === 'card') return 'شبكة';
    if ($m === 'bank transfer') return 'تحويل';
    return $method;
}

function get_dashboard_stats(PDO $pdo, string $from, string $to): array {
    $summary = [
        'sales_total' => 0.0,
        'orders_total' => 0,
        'cancelled_total' => 0,
        'avg_order' => 0.0,
    ];

    $st = $pdo->prepare("
        SELECT
            COUNT(*) AS orders_total,
            SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) AS sales_total,
            SUM(CASE WHEN status = 'cancelled' THEN 1 ELSE 0 END) AS cancelled_total,
            SUM(CASE WHEN status != 'cancelled' THEN 1 ELSE 0 END) AS non_cancelled_orders
        FROM individual_orders
        WHERE order_date BETWEEN ? AND ?
    ");
    $st->execute([$from, $to]);
    $row = $st->fetch(PDO::FETCH_ASSOC) ?: [];
    $summary['orders_total'] = (int)($row['orders_total'] ?? 0);
    $summary['sales_total'] = (float)($row['sales_total'] ?? 0);
    $summary['cancelled_total'] = (int)($row['cancelled_total'] ?? 0);
    $non_cancelled = (int)($row['non_cancelled_orders'] ?? 0);
    $summary['avg_order'] = $non_cancelled > 0 ? ($summary['sales_total'] / $non_cancelled) : 0.0;

    $dailyMap = [];
    $st = $pdo->prepare("
        SELECT
            order_date AS d,
            COUNT(*) AS orders_count,
            SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) AS sales_amount
        FROM individual_orders
        WHERE order_date BETWEEN ? AND ?
        GROUP BY order_date
        ORDER BY order_date ASC
    ");
    $st->execute([$from, $to]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $d = (string)($r['d'] ?? '');
        if ($d === '') continue;
        $dailyMap[$d] = [
            'orders' => (int)($r['orders_count'] ?? 0),
            'sales' => (float)($r['sales_amount'] ?? 0),
        ];
    }

    $labels = [];
    $dailySales = [];
    $dailyOrders = [];
    $cur = new DateTime($from);
    $end = new DateTime($to);
    while ($cur <= $end) {
        $d = $cur->format('Y-m-d');
        $labels[] = $d;
        $dailySales[] = (float)($dailyMap[$d]['sales'] ?? 0);
        $dailyOrders[] = (int)($dailyMap[$d]['orders'] ?? 0);
        $cur->modify('+1 day');
    }

    $byStatus = [];
    $st = $pdo->prepare("
        SELECT status, COUNT(*) AS c
        FROM individual_orders
        WHERE order_date BETWEEN ? AND ?
        GROUP BY status
        ORDER BY c DESC
    ");
    $st->execute([$from, $to]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $s = (string)($r['status'] ?? '');
        $byStatus[] = ['status' => $s, 'label' => status_label($s), 'count' => (int)($r['c'] ?? 0)];
    }

    $byPayment = [];
    $st = $pdo->prepare("
        SELECT LOWER(COALESCE(payment_method,'')) AS pm, COUNT(*) AS c,
               SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) AS sales
        FROM individual_orders
        WHERE order_date BETWEEN ? AND ?
        GROUP BY pm
        ORDER BY c DESC
    ");
    $st->execute([$from, $to]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $pm = (string)($r['pm'] ?? '');
        $byPayment[] = [
            'method' => $pm,
            'label' => payment_label($pm),
            'count' => (int)($r['c'] ?? 0),
            'sales' => (float)($r['sales'] ?? 0),
        ];
    }

    $topCustomers = [];
    $st = $pdo->prepare("
        SELECT
            COALESCE(NULLIF(customer_phone,''), CONCAT('U#', user_id)) AS k,
            customer_name,
            customer_phone,
            COUNT(*) AS orders_count,
            SUM(CASE WHEN status != 'cancelled' THEN total_price ELSE 0 END) AS sales_amount
        FROM individual_orders
        WHERE order_date BETWEEN ? AND ?
        GROUP BY k, customer_name, customer_phone
        ORDER BY sales_amount DESC
        LIMIT 5
    ");
    $st->execute([$from, $to]);
    foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
        $topCustomers[] = [
            'name' => (string)($r['customer_name'] ?? ''),
            'phone' => (string)($r['customer_phone'] ?? ''),
            'orders' => (int)($r['orders_count'] ?? 0),
            'sales' => (float)($r['sales_amount'] ?? 0),
        ];
    }

    $topProducts = [];
    if (table_exists($pdo, 'individual_order_items') && table_exists($pdo, 'products')) {
        $st = $pdo->prepare("
            SELECT
                i.meal_id,
                COALESCE(NULLIF(p.name,''), CONCAT('ID#', i.meal_id)) AS name,
                SUM(i.quantity) AS qty,
                SUM(i.quantity * i.price) AS revenue
            FROM individual_order_items i
            JOIN individual_orders o ON o.id = i.order_id
            LEFT JOIN products p ON p.id = i.meal_id
            WHERE o.order_date BETWEEN ? AND ?
              AND o.status != 'cancelled'
            GROUP BY i.meal_id, name
            ORDER BY qty DESC
            LIMIT 7
        ");
        $st->execute([$from, $to]);
        foreach ($st->fetchAll(PDO::FETCH_ASSOC) as $r) {
            $topProducts[] = [
                'meal_id' => (int)($r['meal_id'] ?? 0),
                'name' => (string)($r['name'] ?? ''),
                'qty' => (int)($r['qty'] ?? 0),
                'revenue' => (float)($r['revenue'] ?? 0),
            ];
        }
    }

    return [
        'range' => ['from' => $from, 'to' => $to],
        'kpis' => $summary,
        'daily' => ['labels' => $labels, 'sales' => $dailySales, 'orders' => $dailyOrders],
        'by_status' => $byStatus,
        'by_payment' => $byPayment,
        'top_customers' => $topCustomers,
        'top_products' => $topProducts,
    ];
}

$today_date = date('Y-m-d');
$range_to_raw = (string)($_GET['to'] ?? '');
$range_from_raw = (string)($_GET['from'] ?? '');
$range_to = is_valid_ymd($range_to_raw) ? $range_to_raw : $today_date;
$range_from = is_valid_ymd($range_from_raw) ? $range_from_raw : date('Y-m-d', strtotime($range_to . ' -13 days'));
if ($range_from > $range_to) {
    $tmp = $range_from;
    $range_from = $range_to;
    $range_to = $tmp;
}

if (isset($_GET['action']) && $_GET['action'] === 'dashboard_stats') {
    header('Content-Type: application/json; charset=utf-8');
    try {
        $stats = get_dashboard_stats($pdo, $range_from, $range_to);
        echo json_encode(['ok' => true, 'data' => $stats], JSON_UNESCAPED_UNICODE);
    } catch (Throwable $e) {
        echo json_encode(['ok' => false, 'message' => 'تعذر جلب البيانات'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

if (isset($_GET['action']) && $_GET['action'] === 'dashboard_export') {
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename="dashboard_' . $range_from . '_to_' . $range_to . '.csv"');
    echo "\xEF\xBB\xBF";
    $stats = get_dashboard_stats($pdo, $range_from, $range_to);
    $out = fopen('php://output', 'w');
    fputcsv($out, ['from', $stats['range']['from'], 'to', $stats['range']['to']]);
    fputcsv($out, ['sales_total', $stats['kpis']['sales_total'], 'orders_total', $stats['kpis']['orders_total'], 'cancelled_total', $stats['kpis']['cancelled_total'], 'avg_order', $stats['kpis']['avg_order']]);
    fputcsv($out, []);
    fputcsv($out, ['date', 'orders', 'sales']);
    $len = count($stats['daily']['labels']);
    for ($i = 0; $i < $len; $i++) {
        fputcsv($out, [$stats['daily']['labels'][$i], $stats['daily']['orders'][$i], $stats['daily']['sales'][$i]]);
    }
    fclose($out);
    exit;
}

// --- جلب الإحصائيات (للنظام الجديد: الطلبات الفردية) ---
try {
    // 1. مبيعات اليوم (المالية)
    $stmt = $pdo->prepare("SELECT SUM(total_price) FROM individual_orders WHERE order_date = ? AND status != 'cancelled'");
    $stmt->execute([$today_date]);
    $daily_sales = $stmt->fetchColumn() ?: 0;

    // 2. عدد طلبات اليوم
    $stmt = $pdo->prepare("SELECT COUNT(*) FROM individual_orders WHERE order_date = ?");
    $stmt->execute([$today_date]);
    $daily_orders_count = $stmt->fetchColumn();

    // 3. عدد العملاء المسجلين
    $total_clients = $pdo->query("SELECT COUNT(*) FROM users WHERE role = 'client'")->fetchColumn();

    // 4. عدد الوجبات في المنيو
    $total_meals = $pdo->query("SELECT COUNT(*) FROM meals")->fetchColumn();

    // 5. جلب "آخر 10 طلبات" (للمتابعة الحية)
    $sql_recent = "SELECT * FROM individual_orders ORDER BY created_at DESC LIMIT 10";
    $recent_orders = $pdo->query($sql_recent)->fetchAll();

    $range_stats = get_dashboard_stats($pdo, $range_from, $range_to);
} catch (PDOException $e) {
    die("خطأ في جلب البيانات: " . $e->getMessage());
}

// دالة مساعدة لحالة الطلب
function get_status_badge($status) {
    switch ($status) {
        case 'pending': return '<span style="color:#f39c12; font-weight:bold;">قيد الانتظار ⏳</span>';
        case 'prepared': return '<span style="color:#3498db; font-weight:bold;">تم التجهيز 👨‍🍳</span>';
        case 'out_for_delivery': return '<span style="color:#9b59b6; font-weight:bold;">جاري التوصيل 🚗</span>';
        case 'delivered': return '<span style="color:#27ae60; font-weight:bold;">تم التسليم ✅</span>';
        case 'picked_up': return '<span style="color:#16a34a; font-weight:bold;">تم الاستلام ✅</span>';
        case 'cancelled': return '<span style="color:#e74c3c; font-weight:bold;">ملغي ❌</span>';
        default: return $status;
    }
}
?>
<!DOCTYPE html>
<html lang="ar" dir="rtl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>لوحة التحكم - الرئيسية</title>
    <link rel="stylesheet" href="admin-unified-style-v2.css?v=20260113">
    <link rel="stylesheet" href="admin_colors.php?v=20260113">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Tajawal:wght@400;500;700;800;900&display=swap" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.1/dist/chart.umd.min.js"></script>
    <style>
        .dashFilters{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:12px;align-items:end}
        .dashField label{display:block;margin:0 0 6px;color:var(--admin-text-secondary);font-weight:1000;font-size:.9rem}
        .dashQuick{display:flex;gap:10px;flex-wrap:wrap}
        .dashQuick .admin-btn{padding:10px 12px}
        .dashKpiGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:14px;margin-top:14px}
        .dashKpi{border:1px solid var(--admin-border);background:rgba(255,255,255,.9);border-radius:18px;padding:14px 16px;box-shadow:var(--admin-shadow-sm)}
        .dashKpi .t{color:var(--admin-text-secondary);font-weight:1000;font-size:.9rem;display:flex;gap:10px;align-items:center}
        .dashKpi .v{margin-top:8px;font-weight:1100;font-size:1.35rem;color:var(--admin-text-main)}
        .dashGrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px;margin-top:16px}
        .dashChart{border:1px solid var(--admin-border);background:rgba(255,255,255,.95);border-radius:18px;padding:14px 14px;box-shadow:var(--admin-shadow-sm)}
        .dashChart .h{display:flex;align-items:center;justify-content:space-between;gap:10px;margin-bottom:10px;font-weight:1100;color:var(--admin-text-main)}
        .dashChart canvas{width:100%!important;height:290px!important}
        .dashTables{display:grid;grid-template-columns:repeat(auto-fit,minmax(340px,1fr));gap:16px;margin-top:16px}
        .dashMiniTable{border:1px solid var(--admin-border);background:rgba(255,255,255,.95);border-radius:18px;padding:14px 14px;box-shadow:var(--admin-shadow-sm)}
        .dashMiniTable table{width:100%;border-collapse:separate;border-spacing:0}
        .dashMiniTable th,.dashMiniTable td{padding:10px 10px;border-bottom:1px solid var(--admin-border);text-align:right;font-weight:900}
        .dashMiniTable th{color:var(--admin-text-secondary);font-weight:1000;background:rgba(217,119,6,.06)}
        .dashMsg{margin-top:10px;color:var(--admin-text-secondary);font-weight:900}
        .recentSearch{width:260px;max-width:100%}
        @media (max-width: 520px){.dashChart canvas{height:240px!important}}
    </style>
</head>
<body>

    <?php include 'sidebar.php'; ?>

    <div class="main-content">
        <header class="top-bar">
            <div class="user-info">مرحباً، المدير</div>
            <div style="display:flex; gap:10px; align-items:center;">
                <?php echo langSwitcher(); ?>
                <a href="logout.php" class="logout-link"><i class="fas fa-sign-out-alt"></i> خروج</a>
            </div>
        </header>

        <main class="content-wrapper">
            
            <div class="admin-header">
                <h1><i class="fas fa-chart-line"></i> لوحة التحكم الرئيسية</h1>
                <div style="display:flex; align-items:center; gap:12px;">
                    <span style="color:var(--admin-text-secondary); font-weight:700; font-size:0.95rem;">
                        <i class="fas fa-calendar-alt"></i> <?php echo $today_date; ?>
                    </span>
                </div>
            </div>

            <div class="dashboard-grid">
                <div class="stat-box box-sales">
                    <div class="stat-icon"><i class="fas fa-money-bill-wave"></i></div>
                    <div class="stat-info">
                        <h3>مبيعات اليوم</h3>
                        <div class="number"><?php echo number_format($daily_sales, 2); ?> <small style="font-size:0.7em; -webkit-text-fill-color:var(--admin-text-secondary);">ر.س</small></div>
                    </div>
                </div>
                
                <div class="stat-box box-orders">
                    <div class="stat-icon"><i class="fas fa-shopping-bag"></i></div>
                    <div class="stat-info">
                        <h3>طلبات اليوم</h3>
                        <div class="number"><?php echo $daily_orders_count; ?> <small style="font-size:0.7em; -webkit-text-fill-color:var(--admin-text-secondary);">طلب</small></div>
                    </div>
                </div>
                
                <div class="stat-box box-clients">
                    <div class="stat-icon"><i class="fas fa-users"></i></div>
                    <div class="stat-info">
                        <h3>إجمالي العملاء</h3>
                        <div class="number"><?php echo $total_clients; ?> <small style="font-size:0.7em; -webkit-text-fill-color:var(--admin-text-secondary);">عميل</small></div>
                    </div>
                </div>
                
                <div class="stat-box" style="border-color:rgba(139, 92, 246, 0.2); background:linear-gradient(135deg, #ffffff 0%, #faf5ff 100%);">
                    <div class="stat-icon" style="color:#8b5cf6; background:linear-gradient(135deg, rgba(139, 92, 246, 0.2) 0%, rgba(139, 92, 246, 0.05) 100%); box-shadow:0 4px 12px rgba(139, 92, 246, 0.2);">
                        <i class="fas fa-hamburger"></i>
                    </div>
                    <div class="stat-info">
                        <h3>أصناف المنيو</h3>
                        <div class="number"><?php echo $total_meals; ?> <small style="font-size:0.7em; -webkit-text-fill-color:var(--admin-text-secondary);">صنف</small></div>
                    </div>
                </div>
            </div>

            <div class="admin-card">
                <div class="admin-card-header">
                    <h3><i class="fas fa-chart-pie"></i> تقارير تفاعلية</h3>
                    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                        <button type="button" class="admin-btn admin-btn-secondary admin-btn-sm" id="dashRefreshBtn">
                            <i class="fas fa-rotate"></i> تحديث
                        </button>
                        <a class="admin-btn admin-btn-secondary admin-btn-sm" id="dashExportBtn" href="admin_dashboard.php?action=dashboard_export&from=<?php echo htmlspecialchars($range_from); ?>&to=<?php echo htmlspecialchars($range_to); ?>">
                            <i class="fas fa-file-csv"></i> تصدير CSV
                        </a>
                    </div>
                </div>

                <div class="dashFilters">
                    <div class="dashField">
                        <label for="rangeFrom">من</label>
                        <input id="rangeFrom" type="date" value="<?php echo htmlspecialchars($range_from); ?>">
                    </div>
                    <div class="dashField">
                        <label for="rangeTo">إلى</label>
                        <input id="rangeTo" type="date" value="<?php echo htmlspecialchars($range_to); ?>">
                    </div>
                    <div class="dashField">
                        <label>فترة سريعة</label>
                        <div class="dashQuick">
                            <button type="button" class="admin-btn admin-btn-secondary admin-btn-sm" data-days="7">7 أيام</button>
                            <button type="button" class="admin-btn admin-btn-secondary admin-btn-sm" data-days="14">14 يوم</button>
                            <button type="button" class="admin-btn admin-btn-secondary admin-btn-sm" data-days="30">30 يوم</button>
                        </div>
                    </div>
                </div>

                <div class="dashKpiGrid">
                    <div class="dashKpi">
                        <div class="t"><i class="fas fa-sack-dollar"></i> مبيعات الفترة</div>
                        <div class="v" id="kpiSales"><?php echo number_format((float)($range_stats['kpis']['sales_total'] ?? 0), 2); ?> ر.س</div>
                    </div>
                    <div class="dashKpi">
                        <div class="t"><i class="fas fa-receipt"></i> عدد الطلبات</div>
                        <div class="v" id="kpiOrders"><?php echo (int)($range_stats['kpis']['orders_total'] ?? 0); ?></div>
                    </div>
                    <div class="dashKpi">
                        <div class="t"><i class="fas fa-chart-line"></i> متوسط الفاتورة</div>
                        <div class="v" id="kpiAvg"><?php echo number_format((float)($range_stats['kpis']['avg_order'] ?? 0), 2); ?> ر.س</div>
                    </div>
                    <div class="dashKpi">
                        <div class="t"><i class="fas fa-ban"></i> الملغي</div>
                        <div class="v" id="kpiCancelled"><?php echo (int)($range_stats['kpis']['cancelled_total'] ?? 0); ?></div>
                    </div>
                </div>

                <div class="dashGrid">
                    <div class="dashChart">
                        <div class="h"><span>مبيعات وطلبات يومية</span><span style="color:var(--admin-text-secondary);font-weight:1000;font-size:.9rem" id="rangeLabel"><?php echo htmlspecialchars($range_from); ?> → <?php echo htmlspecialchars($range_to); ?></span></div>
                        <canvas id="chartDaily"></canvas>
                    </div>
                    <div class="dashChart">
                        <div class="h"><span>توزيع حالات الطلبات</span></div>
                        <canvas id="chartStatus"></canvas>
                    </div>
                    <div class="dashChart">
                        <div class="h"><span>طرق الدفع</span></div>
                        <canvas id="chartPayment"></canvas>
                    </div>
                    <div class="dashChart">
                        <div class="h"><span>أكثر الأصناف (كمية)</span></div>
                        <canvas id="chartTopItems"></canvas>
                        <div class="dashMsg" id="topItemsMsg" style="display:none">لا توجد بيانات كافية للأصناف ضمن هذه الفترة.</div>
                    </div>
                </div>

                <div class="dashTables">
                    <div class="dashMiniTable">
                        <div class="h" style="margin-bottom:10px;font-weight:1100"><i class="fas fa-utensils" style="color:var(--restaurant-primary)"></i> أعلى الأصناف</div>
                        <div style="overflow:auto">
                            <table>
                                <thead>
                                    <tr><th>الصنف</th><th>الكمية</th><th>الإيراد</th></tr>
                                </thead>
                                <tbody id="topProductsTbody">
                                    <?php if (empty($range_stats['top_products'])): ?>
                                        <tr><td colspan="3" style="text-align:center;padding:16px;color:var(--admin-text-secondary)">لا توجد بيانات</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($range_stats['top_products'] as $p): ?>
                                            <tr>
                                                <td><?php echo htmlspecialchars((string)$p['name']); ?></td>
                                                <td><?php echo (int)$p['qty']; ?></td>
                                                <td><?php echo number_format((float)$p['revenue'], 2); ?> ر.س</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="dashMiniTable">
                        <div class="h" style="margin-bottom:10px;font-weight:1100"><i class="fas fa-user-group" style="color:var(--restaurant-primary)"></i> أعلى العملاء</div>
                        <div style="overflow:auto">
                            <table>
                                <thead>
                                    <tr><th>العميل</th><th>الطلبات</th><th>المبيعات</th></tr>
                                </thead>
                                <tbody id="topCustomersTbody">
                                    <?php if (empty($range_stats['top_customers'])): ?>
                                        <tr><td colspan="3" style="text-align:center;padding:16px;color:var(--admin-text-secondary)">لا توجد بيانات</td></tr>
                                    <?php else: ?>
                                        <?php foreach ($range_stats['top_customers'] as $c): ?>
                                            <tr>
                                                <td>
                                                    <?php echo htmlspecialchars((string)$c['name']); ?>
                                                    <?php if (!empty($c['phone'])): ?>
                                                        <div style="color:var(--admin-text-secondary);font-weight:900;font-size:.85rem;direction:ltr;text-align:right"><?php echo htmlspecialchars((string)$c['phone']); ?></div>
                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo (int)$c['orders']; ?></td>
                                                <td><?php echo number_format((float)$c['sales'], 2); ?> ر.س</td>
                                            </tr>
                                        <?php endforeach; ?>
                                    <?php endif; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>

                <div class="dashMsg" id="dashMsg"></div>
            </div>

            <div class="admin-card">
                <div class="admin-card-header">
                    <h3><i class="fas fa-clock"></i> آخر 10 طلبات واردة</h3>
                    <div style="display:flex; gap:10px; align-items:center; flex-wrap:wrap;">
                        <input class="recentSearch" id="recentSearch" type="search" placeholder="بحث سريع..." />
                        <a href="admin_orders.php" class="admin-btn admin-btn-secondary admin-btn-sm">
                            <i class="fas fa-external-link-alt"></i> عرض الكل
                        </a>
                    </div>
                </div>
                
                <div class="admin-table-wrapper">
                    <table class="admin-table recent-orders-table">
                        <thead>
                            <tr>
                                <th>رقم الطلب</th>
                                <th>العميل</th>
                                <th>المبلغ</th>
                                <th>طريقة الدفع</th>
                                <th>النوع</th>
                                <th>الحالة</th>
                                <th>التواريخ</th>
                                <th>إجراء</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if (empty($recent_orders)): ?>
                                <tr><td colspan="8" style="text-align:center; padding:30px;">لا توجد طلبات حتى الآن.</td></tr>
                            <?php else: ?>
                                <?php foreach ($recent_orders as $order): ?>
                                    <tr>
                                        <td><strong>#<?php echo $order['id']; ?></strong></td>
                                        <td>
                                            <?php echo htmlspecialchars($order['customer_name']); ?><br>
                                            <small style="color:#888;"><?php echo htmlspecialchars($order['customer_phone']); ?></small>
                                        </td>
                                        <td><strong><?php echo number_format($order['total_price'], 2); ?></strong></td>
                                        <td>
                                            <?php echo ($order['payment_method']=='cod') ? 'عند الاستلام' : $order['payment_method']; ?>
                                        </td>
                                        <td>
                                            <?php if($order['order_type'] == 'delivery'): ?>
                                                <span style="color:#e67e22;"><i class="fas fa-motorcycle"></i> توصيل</span>
                                            <?php else: ?>
                                                <span style="color:#2980b9;"><i class="fas fa-store"></i> استلام</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo get_status_badge($order['status']); ?></td>
                                        <td style="font-size:0.85rem; color:#666;">
                                            <?php echo date('H:i d/m', strtotime($order['created_at'])); ?>
                                        </td>
                                        <td>
                                            <a class="admin-btn admin-btn-secondary admin-btn-sm" href="admin_order_details.php?id=<?php echo (int)$order['id']; ?>">
                                                <i class="fas fa-eye"></i> تفاصيل
                                            </a>
                                        </td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>

        </main>
    </div>

    <script>
        const initialStats = <?php echo json_encode($range_stats, JSON_UNESCAPED_UNICODE); ?>;

        const elFrom = document.getElementById('rangeFrom');
        const elTo = document.getElementById('rangeTo');
        const elRangeLabel = document.getElementById('rangeLabel');
        const elMsg = document.getElementById('dashMsg');
        const elExport = document.getElementById('dashExportBtn');
        const elTopItemsMsg = document.getElementById('topItemsMsg');

        const fmtInt = new Intl.NumberFormat('ar-SA');
        const fmtMoney = new Intl.NumberFormat('ar-SA', { minimumFractionDigits: 2, maximumFractionDigits: 2 });

        function setMsg(t) {
            elMsg.textContent = t || '';
        }

        function applyKpis(k) {
            document.getElementById('kpiSales').textContent = fmtMoney.format(Number(k.sales_total || 0)) + ' ر.س';
            document.getElementById('kpiOrders').textContent = fmtInt.format(Number(k.orders_total || 0));
            document.getElementById('kpiAvg').textContent = fmtMoney.format(Number(k.avg_order || 0)) + ' ر.س';
            document.getElementById('kpiCancelled').textContent = fmtInt.format(Number(k.cancelled_total || 0));
        }

        function renderTopTable(tbodyId, rows, cols) {
            const tb = document.getElementById(tbodyId);
            tb.innerHTML = '';
            if (!rows || rows.length === 0) {
                const tr = document.createElement('tr');
                const td = document.createElement('td');
                td.colSpan = cols;
                td.style.textAlign = 'center';
                td.style.padding = '16px';
                td.style.color = 'var(--admin-text-secondary)';
                td.textContent = 'لا توجد بيانات';
                tr.appendChild(td);
                tb.appendChild(tr);
                return;
            }
            for (const r of rows) {
                const tr = document.createElement('tr');
                tr.innerHTML = r;
                tb.appendChild(tr);
            }
        }

        Chart.defaults.font.family = 'Tajawal, system-ui, -apple-system, Segoe UI, Arial';
        Chart.defaults.color = '#334155';

        let chartDaily, chartStatus, chartPayment, chartTop;

        function buildCharts(data) {
            const daily = data.daily || { labels: [], sales: [], orders: [] };
            const status = data.by_status || [];
            const pay = data.by_payment || [];
            const top = data.top_products || [];

            const dailyCtx = document.getElementById('chartDaily');
            const statusCtx = document.getElementById('chartStatus');
            const payCtx = document.getElementById('chartPayment');
            const topCtx = document.getElementById('chartTopItems');

            const dailyConfig = {
                type: 'line',
                data: {
                    labels: daily.labels,
                    datasets: [
                        {
                            label: 'المبيعات (ر.س)',
                            data: daily.sales,
                            borderColor: '#d97706',
                            backgroundColor: 'rgba(217, 119, 6, 0.14)',
                            tension: 0.28,
                            fill: true,
                            yAxisID: 'ySales'
                        },
                        {
                            label: 'الطلبات',
                            data: daily.orders,
                            borderColor: '#1d4ed8',
                            backgroundColor: 'rgba(29, 78, 216, 0.10)',
                            tension: 0.28,
                            fill: false,
                            yAxisID: 'yOrders'
                        }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    interaction: { mode: 'index', intersect: false },
                    plugins: {
                        legend: { position: 'top' },
                        tooltip: { rtl: true }
                    },
                    scales: {
                        ySales: { beginAtZero: true, position: 'right' },
                        yOrders: { beginAtZero: true, position: 'left', grid: { drawOnChartArea: false }, ticks: { precision: 0 } },
                        x: { ticks: { maxRotation: 0, autoSkip: true } }
                    }
                }
            };

            const statusConfig = {
                type: 'doughnut',
                data: {
                    labels: status.map(x => x.label),
                    datasets: [{
                        data: status.map(x => x.count),
                        backgroundColor: ['#f59e0b','#3b82f6','#8b5cf6','#16a34a','#ef4444','#0ea5e9','#64748b']
                    }]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'bottom' }, tooltip: { rtl: true } }
                }
            };

            const payConfig = {
                type: 'bar',
                data: {
                    labels: pay.map(x => x.label),
                    datasets: [
                        { label: 'عدد الطلبات', data: pay.map(x => x.count), backgroundColor: 'rgba(217, 119, 6, 0.25)', borderColor: '#d97706', borderWidth: 1 }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'top' }, tooltip: { rtl: true } },
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            };

            const topLabels = top.map(x => x.name);
            const topQty = top.map(x => x.qty);
            elTopItemsMsg.style.display = topLabels.length ? 'none' : 'block';
            const topConfig = {
                type: 'bar',
                data: {
                    labels: topLabels,
                    datasets: [
                        { label: 'الكمية', data: topQty, backgroundColor: 'rgba(29, 78, 216, 0.18)', borderColor: '#1d4ed8', borderWidth: 1 }
                    ]
                },
                options: {
                    responsive: true,
                    maintainAspectRatio: false,
                    plugins: { legend: { position: 'top' }, tooltip: { rtl: true } },
                    scales: { y: { beginAtZero: true, ticks: { precision: 0 } } }
                }
            };

            chartDaily = new Chart(dailyCtx, dailyConfig);
            chartStatus = new Chart(statusCtx, statusConfig);
            chartPayment = new Chart(payCtx, payConfig);
            chartTop = new Chart(topCtx, topConfig);
        }

        function updateCharts(data) {
            const daily = data.daily || { labels: [], sales: [], orders: [] };
            const status = data.by_status || [];
            const pay = data.by_payment || [];
            const top = data.top_products || [];

            chartDaily.data.labels = daily.labels;
            chartDaily.data.datasets[0].data = daily.sales;
            chartDaily.data.datasets[1].data = daily.orders;
            chartDaily.update();

            chartStatus.data.labels = status.map(x => x.label);
            chartStatus.data.datasets[0].data = status.map(x => x.count);
            chartStatus.update();

            chartPayment.data.labels = pay.map(x => x.label);
            chartPayment.data.datasets[0].data = pay.map(x => x.count);
            chartPayment.update();

            const topLabels = top.map(x => x.name);
            const topQty = top.map(x => x.qty);
            elTopItemsMsg.style.display = topLabels.length ? 'none' : 'block';
            chartTop.data.labels = topLabels;
            chartTop.data.datasets[0].data = topQty;
            chartTop.update();
        }

        function updateTables(data) {
            const topProducts = data.top_products || [];
            renderTopTable('topProductsTbody', topProducts.map(p => `
                <td>${escapeHtml(p.name || '')}</td>
                <td>${fmtInt.format(Number(p.qty || 0))}</td>
                <td>${fmtMoney.format(Number(p.revenue || 0))} ر.س</td>
            `), 3);

            const topCustomers = data.top_customers || [];
            renderTopTable('topCustomersTbody', topCustomers.map(c => `
                <td>
                    ${escapeHtml(c.name || '')}
                    ${c.phone ? `<div style="color:var(--admin-text-secondary);font-weight:900;font-size:.85rem;direction:ltr;text-align:right">${escapeHtml(c.phone)}</div>` : ''}
                </td>
                <td>${fmtInt.format(Number(c.orders || 0))}</td>
                <td>${fmtMoney.format(Number(c.sales || 0))} ر.س</td>
            `), 3);
        }

        function escapeHtml(s) {
            return String(s).replace(/[&<>"']/g, m => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
        }

        function setQuickDays(days) {
            const to = new Date(elTo.value);
            if (isNaN(to.getTime())) return;
            const from = new Date(to);
            from.setDate(from.getDate() - (days - 1));
            elFrom.value = from.toISOString().slice(0, 10);
        }

        async function refreshDashboard() {
            const from = elFrom.value;
            const to = elTo.value;
            if (!from || !to) return;
            setMsg('جاري تحديث التقارير...');

            const url = new URL(window.location.href);
            url.searchParams.set('action', 'dashboard_stats');
            url.searchParams.set('from', from);
            url.searchParams.set('to', to);

            try {
                const res = await fetch(url.toString(), { headers: { 'Accept': 'application/json' } });
                const json = await res.json();
                if (!json || !json.ok) throw new Error(json && json.message ? json.message : 'فشل');
                const data = json.data;

                elRangeLabel.textContent = `${data.range.from} → ${data.range.to}`;
                applyKpis(data.kpis || {});
                updateCharts(data);
                updateTables(data);

                const exportUrl = new URL(window.location.href);
                exportUrl.searchParams.set('action', 'dashboard_export');
                exportUrl.searchParams.set('from', from);
                exportUrl.searchParams.set('to', to);
                elExport.href = exportUrl.toString();

                setMsg('تم تحديث التقارير.');
            } catch (e) {
                setMsg('تعذر تحديث التقارير حالياً.');
            }
        }

        document.getElementById('dashRefreshBtn').addEventListener('click', refreshDashboard);
        document.querySelectorAll('[data-days]').forEach(btn => {
            btn.addEventListener('click', () => {
                const days = Number(btn.getAttribute('data-days') || '0');
                if (!days) return;
                setQuickDays(days);
                refreshDashboard();
            });
        });
        elFrom.addEventListener('change', refreshDashboard);
        elTo.addEventListener('change', refreshDashboard);

        buildCharts(initialStats);

        const recentSearch = document.getElementById('recentSearch');
        if (recentSearch) {
            const rows = Array.from(document.querySelectorAll('.recent-orders-table tbody tr'));
            recentSearch.addEventListener('input', () => {
                const q = recentSearch.value.trim().toLowerCase();
                for (const r of rows) {
                    const t = r.textContent ? r.textContent.toLowerCase() : '';
                    r.style.display = q === '' || t.includes(q) ? '' : 'none';
                }
            });
        }
    </script>
</body>
</html>
