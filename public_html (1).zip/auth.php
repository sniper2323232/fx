<?php
/**
 * auth.php - حماية الصفحات
 * يعتمد على includes/bootstrap.php لتوحيد إعداد الجلسة و CSRF
 */
if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

// التحقق من تسجيل الدخول
if (!isset($_SESSION['user_id'], $_SESSION['role'])) {
    header("Location: login.php?error=auth");
    exit;
}

/**
 * دالة للتحقق من الصلاحيات
 * @param array $allowedRoles
 */
function requireRole(array $allowedRoles)
{
    if (!in_array($_SESSION['role'], $allowedRoles, true)) {
        header("Location: login.php?error=auth");
        exit;
    }
}
?>
