<?php
// ملف: delete_product.php

// 1. الاتصال والحماية
require_once 'auth_admin.php'; 
require_once 'db_connect.php'; 

function table_exists(PDO $pdo, string $table): bool {
    try {
        $st = $pdo->prepare("SHOW TABLES LIKE ?");
        $st->execute([$table]);
        return $st->fetchColumn() !== false;
    } catch (Exception $e) {
        return false;
    }
}

// التحقق من وجود المعرف ID
if (isset($_GET['id']) && is_numeric($_GET['id'])) {
    
    $product_id = $_GET['id'];

    try {
        $stmt = $pdo->prepare("SELECT image FROM products WHERE id = ?");
        $stmt->execute([$product_id]);
        $product = $stmt->fetch();

        if ($product) {
            $hasOrders = 0;
            if (table_exists($pdo, 'order_items')) {
                $st = $pdo->prepare("SELECT COUNT(*) FROM order_items WHERE product_id = ?");
                $st->execute([$product_id]);
                $hasOrders = (int)$st->fetchColumn();
            }

            if ($hasOrders > 0) {
                header("Location: manage_products.php?status=cannot_delete_orders");
                exit;
            }

            $pdo->beginTransaction();
            if (table_exists($pdo, 'product_sizes')) {
                $pdo->prepare("DELETE FROM product_sizes WHERE product_id = ?")->execute([$product_id]);
            }
            if (table_exists($pdo, 'product_options')) {
                $pdo->prepare("DELETE FROM product_options WHERE product_id = ?")->execute([$product_id]);
            }

            $delete_stmt = $pdo->prepare("DELETE FROM products WHERE id = ?");
            $delete_stmt->execute([$product_id]);
            $pdo->commit();

            if (!empty($product['image'])) {
                $image_path = 'uploads/' . $product['image'];
                if (file_exists($image_path)) {
                    unlink($image_path);
                }
            }

            // العودة لصفحة الإدارة مع رسالة نجاح
            header("Location: manage_products.php?status=deleted");
            exit;
        } else {
            // المنتج غير موجود أصلاً
            header("Location: manage_products.php?status=error");
            exit;
        }

    } catch (PDOException $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        header("Location: manage_products.php?status=error");
        exit;
    }

} else {
    // إذا لم يتم تمرير ID
    header("Location: manage_products.php");
    exit;
}
?>
